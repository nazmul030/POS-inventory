﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS
{
    public partial class StocksUpdateForm : Form
    {
        public ProductsGateway productGateway = new ProductsGateway();

        public SupplierGateway supplierGateway = new SupplierGateway();

        public DataTable productTable = new DataTable();

        private string Excel03ConString =
            "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";

        private string Excel07ConString =
            "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";

        public UserInfo loggedInUserInfo = null;
        
        public StocksUpdateForm(UserInfo userInfo)
        {
            InitializeComponent();

            loggedInUserInfo = userInfo;
        }


        private void LoadCompanyNames()
        {
            List<string> suppliersCompanyNames = new List<string>();
            suppliersCompanyNames = supplierGateway.GetAllSuppliersCompanyName();

            suppliersComboBox.Items.Clear();
            foreach (string companyName in suppliersCompanyNames)
            {
                suppliersComboBox.Items.Add(companyName);
            }
        }


        private void StocksUpdateForm_Load(object sender, EventArgs e)
        {
            LoadCompanyNames();
        }


        private void loadInfoButton_Click(object sender, EventArgs e)
        {
            string productCode = productCodeTextBox.Text;
            if (productCode == "")
            {
                MessageBox.Show("First enter product code.");
            }
            else
            {
                Product product = productGateway.GetProductByProductCode(productCode);

                productNameTextBox.Text = product.ProductName;
                descriptionTextBox.Text = product.Description;
                categoryTextBox.Text = product.Category;
                subcategoryTextBox.Text = product.Subcategory;
                barcodeTextBox.Text = product.Barcode;
                costingTextBox.Text = product.Costing.ToString();
                retailPriceTextBox.Text = product.RetailPrice.ToString();
                wholesalePriceTextBox.Text = product.WholeSalePrice.ToString();
                currentStocksTextBox.Text = product.StocksInHand.ToString();
            }
        }


        private void quantityTextBox_TextChanged(object sender, EventArgs e)
        {
            int quantityToAdd;
            if (quantityTextBox.Text == "")
            {
                quantityToAdd = 0;
            }
            else
            {
                quantityToAdd = Convert.ToInt32(quantityTextBox.Text);
                int currentStockInHand = Convert.ToInt32(currentStocksTextBox.Text);
                int newTotalStock = 0;
                
                if (stockInRadioButton.Checked)
                {
                    newTotalStock = currentStockInHand + quantityToAdd;
                }
                else if(stockOutRadioButton.Checked)
                {
                    newTotalStock = currentStockInHand - quantityToAdd;
                }
                totalStocksTextBox.Text = newTotalStock.ToString();
            }
        }


        public void ClearAll()
        {
            productCodeTextBox.Text = null;
            productNameTextBox.Text = null;
            categoryTextBox.Text = null;
            subcategoryTextBox.Text = null;
            descriptionTextBox.Text = null;
            costingTextBox.Text = null;
            retailPriceTextBox.Text = null;
            wholesalePriceTextBox.Text = null;
            currentStocksTextBox.Text = null;
            quantityTextBox.Text = null;
            totalStocksTextBox.Text = null;

            LoadCompanyNames();
        }


        private void singleValueSaveButton_Click(object sender, EventArgs e)
        {
            string productCode = productCodeTextBox.Text;
            string productName = productNameTextBox.Text;
            string category = categoryTextBox.Text;
            string subcategory = subcategoryTextBox.Text;
            string description = descriptionTextBox.Text;
            string supplier = suppliersComboBox.SelectedText;
            string barcode = barcodeTextBox.Text;
            int costing = Convert.ToInt32(costingTextBox.Text);
            int retailPrice = Convert.ToInt32(retailPriceTextBox.Text);
            int wholesalePrice = Convert.ToInt32(wholesalePriceTextBox.Text);
            int quantityToAdd = Convert.ToInt32(quantityTextBox.Text);

            string result = "";

            if (quantityToAdd == 0)
            {
                MessageBox.Show("First enter quantity to add in the stock.");
            }
            else
            {
                DateTime dateTime = DateTime.UtcNow.Date;
                string date = dateTime.ToString("yy-MM-dd");
                date = date.Replace("-", "/");

                Product product = new Product(productCode, productName, category, subcategory, description, supplier, barcode, costing, retailPrice, wholesalePrice, quantityToAdd);

                if (stockInRadioButton.Checked)
                {
                    result = productGateway.SingleStockInUpdate(product, loggedInUserInfo, date);
                }
                else if (stockOutRadioButton.Checked)
                {
                    result = productGateway.SingleStockOutUpdate(product, loggedInUserInfo, date);
                }
                else
                {
                    result = "Select update type first.";
                }
                MessageBox.Show(result);

                ClearAll();    
            }
        }


        private void singleValueRefreshButton_Click(object sender, EventArgs e)
        {
            ClearAll();
        }


        private void singleValueCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void loadValueFromExcelFileButton_Click(object sender, EventArgs e)
        {
            excelValuesDataGridView.Visible = true;
            productTable.Clear();
            excelValuesDataGridView.DataSource = null;
            excelValuesDataGridView.Rows.Clear();

            openExcelFileDialog.ShowDialog();
        }


        private void openExcelFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            string filePath = openExcelFileDialog.FileName;
            string extension = Path.GetExtension(filePath);
            string header = "YES";
            string conStr, sheetName;

            conStr = string.Empty;
            switch (extension)
            {

                case ".xls": //Excel 97-03
                    conStr = string.Format(Excel03ConString, filePath, header);
                    break;

                case ".xlsx": //Excel 07
                    conStr = string.Format(Excel07ConString, filePath, header);
                    break;
                default:
                    MessageBox.Show("Select an excel file first.");
                    break;
            }

            using (OleDbConnection con = new OleDbConnection(conStr))
            {
                using (OleDbCommand cmd = new OleDbCommand())
                {
                    cmd.Connection = con;
                    con.Open();
                    DataTable dtExcelSchema = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                    con.Close();
                }
            }

            //Read Data from the First Sheet.
            using (OleDbConnection con = new OleDbConnection(conStr))
            {
                using (OleDbCommand cmd = new OleDbCommand())
                {
                    using (OleDbDataAdapter oda = new OleDbDataAdapter())
                    {
                        cmd.CommandText = "SELECT * From [" + sheetName + "]";
                        cmd.Connection = con;
                        con.Open();
                        oda.SelectCommand = cmd;
                        oda.Fill(productTable);
                        con.Close();
                        
                        //Populate DataGridView.
                        excelValuesDataGridView.DataSource = productTable;
                    }
                }
            }
        }

        private void stocksInSaveButton_Click(object sender, EventArgs e)
        {
            if (productTable == null)
            {
                MessageBox.Show("First select the excel file.");
            }
            else
            {
                DateTime dateTime = DateTime.UtcNow.Date;
                string date = dateTime.ToString("yy-MM-dd");
                date = date.Replace("-", "/");

                string result = "";
                if (stockInRadioButton.Checked)
                {
                    result = productGateway.MultipleStocksInUpdate(productTable, loggedInUserInfo, date);    
                }
                else if (stockOutRadioButton.Checked)
                {
                    result = productGateway.MultipleStocksOutUpdate(productTable, loggedInUserInfo, date);
                }
                else
                {
                    result = "Select update type first.";
                }
                MessageBox.Show(result);

                productTable.Clear();
                excelValuesDataGridView.DataSource = null;
                excelValuesDataGridView.Rows.Clear();
            }
        }


        private void refreshButton_Click(object sender, EventArgs e)
        {
            productTable.Clear();
            excelValuesDataGridView.DataSource = null;
            excelValuesDataGridView.Rows.Clear();
        }


        private void stocksInCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
