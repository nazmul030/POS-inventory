﻿namespace POSwithIMS
{
    partial class DeleteProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeleteProductForm));
            this.loadInfoButton = new System.Windows.Forms.Button();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.supplierTextBox = new System.Windows.Forms.TextBox();
            this.supplierLabel = new System.Windows.Forms.Label();
            this.subcategoryTextBox = new System.Windows.Forms.TextBox();
            this.categoryTextBox = new System.Windows.Forms.TextBox();
            this.wholesalePriceTextBox = new System.Windows.Forms.TextBox();
            this.wholesalePriceLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.refreshButton = new System.Windows.Forms.Button();
            this.addProductCancelButton = new System.Windows.Forms.Button();
            this.updateExistingProductSaveButton = new System.Windows.Forms.Button();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.retailPriceTextBox = new System.Windows.Forms.TextBox();
            this.retailPriceLabel = new System.Windows.Forms.Label();
            this.stocksInHandTextBox = new System.Windows.Forms.TextBox();
            this.categoryLabel = new System.Windows.Forms.Label();
            this.barcodeTextBox = new System.Windows.Forms.TextBox();
            this.barcodeLabel = new System.Windows.Forms.Label();
            this.productNameTextBox = new System.Windows.Forms.TextBox();
            this.productNameLabel = new System.Windows.Forms.Label();
            this.productCodeTextBox = new System.Windows.Forms.TextBox();
            this.productCodeLabel = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.updateLabel = new System.Windows.Forms.Label();
            this.GroupBox1.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // loadInfoButton
            // 
            this.loadInfoButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.loadInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loadInfoButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.loadInfoButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadInfoButton.Image = ((System.Drawing.Image)(resources.GetObject("loadInfoButton.Image")));
            this.loadInfoButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.loadInfoButton.Location = new System.Drawing.Point(371, 37);
            this.loadInfoButton.Name = "loadInfoButton";
            this.loadInfoButton.Size = new System.Drawing.Size(95, 22);
            this.loadInfoButton.TabIndex = 13;
            this.loadInfoButton.Text = "&Load Info ";
            this.loadInfoButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.loadInfoButton.UseVisualStyleBackColor = false;
            this.loadInfoButton.Click += new System.EventHandler(this.loadInfoButton_Click);
            // 
            // GroupBox1
            // 
            this.GroupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.GroupBox1.Controls.Add(this.supplierTextBox);
            this.GroupBox1.Controls.Add(this.supplierLabel);
            this.GroupBox1.Controls.Add(this.subcategoryTextBox);
            this.GroupBox1.Controls.Add(this.categoryTextBox);
            this.GroupBox1.Controls.Add(this.wholesalePriceTextBox);
            this.GroupBox1.Controls.Add(this.wholesalePriceLabel);
            this.GroupBox1.Controls.Add(this.label1);
            this.GroupBox1.Controls.Add(this.textBox1);
            this.GroupBox1.Controls.Add(this.label2);
            this.GroupBox1.Controls.Add(this.GroupBox2);
            this.GroupBox1.Controls.Add(this.descriptionTextBox);
            this.GroupBox1.Controls.Add(this.descriptionLabel);
            this.GroupBox1.Controls.Add(this.retailPriceTextBox);
            this.GroupBox1.Controls.Add(this.retailPriceLabel);
            this.GroupBox1.Controls.Add(this.stocksInHandTextBox);
            this.GroupBox1.Controls.Add(this.categoryLabel);
            this.GroupBox1.Controls.Add(this.barcodeTextBox);
            this.GroupBox1.Controls.Add(this.barcodeLabel);
            this.GroupBox1.Controls.Add(this.productNameTextBox);
            this.GroupBox1.Controls.Add(this.productNameLabel);
            this.GroupBox1.Controls.Add(this.loadInfoButton);
            this.GroupBox1.Controls.Add(this.productCodeTextBox);
            this.GroupBox1.Controls.Add(this.productCodeLabel);
            this.GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox1.Location = new System.Drawing.Point(13, 66);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(651, 425);
            this.GroupBox1.TabIndex = 6;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Product Information";
            // 
            // supplierTextBox
            // 
            this.supplierTextBox.BackColor = System.Drawing.Color.White;
            this.supplierTextBox.Location = new System.Drawing.Point(437, 203);
            this.supplierTextBox.Name = "supplierTextBox";
            this.supplierTextBox.Size = new System.Drawing.Size(165, 25);
            this.supplierTextBox.TabIndex = 25;
            // 
            // supplierLabel
            // 
            this.supplierLabel.AutoSize = true;
            this.supplierLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supplierLabel.Location = new System.Drawing.Point(368, 207);
            this.supplierLabel.Name = "supplierLabel";
            this.supplierLabel.Size = new System.Drawing.Size(63, 17);
            this.supplierLabel.TabIndex = 26;
            this.supplierLabel.Text = "Supplier :";
            // 
            // subcategoryTextBox
            // 
            this.subcategoryTextBox.BackColor = System.Drawing.Color.White;
            this.subcategoryTextBox.Location = new System.Drawing.Point(437, 172);
            this.subcategoryTextBox.Name = "subcategoryTextBox";
            this.subcategoryTextBox.Size = new System.Drawing.Size(165, 25);
            this.subcategoryTextBox.TabIndex = 36;
            // 
            // categoryTextBox
            // 
            this.categoryTextBox.BackColor = System.Drawing.Color.White;
            this.categoryTextBox.Location = new System.Drawing.Point(146, 172);
            this.categoryTextBox.Name = "categoryTextBox";
            this.categoryTextBox.Size = new System.Drawing.Size(165, 25);
            this.categoryTextBox.TabIndex = 35;
            // 
            // wholesalePriceTextBox
            // 
            this.wholesalePriceTextBox.BackColor = System.Drawing.Color.White;
            this.wholesalePriceTextBox.Location = new System.Drawing.Point(437, 234);
            this.wholesalePriceTextBox.Name = "wholesalePriceTextBox";
            this.wholesalePriceTextBox.Size = new System.Drawing.Size(165, 25);
            this.wholesalePriceTextBox.TabIndex = 34;
            // 
            // wholesalePriceLabel
            // 
            this.wholesalePriceLabel.AutoSize = true;
            this.wholesalePriceLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wholesalePriceLabel.Location = new System.Drawing.Point(329, 237);
            this.wholesalePriceLabel.Name = "wholesalePriceLabel";
            this.wholesalePriceLabel.Size = new System.Drawing.Size(107, 17);
            this.wholesalePriceLabel.TabIndex = 33;
            this.wholesalePriceLabel.Text = "Wholesale Price :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(343, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 31;
            this.label1.Text = "Subcategory :";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(146, 79);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(165, 25);
            this.textBox1.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 17);
            this.label2.TabIndex = 29;
            this.label2.Text = "Product Code :";
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.refreshButton);
            this.GroupBox2.Controls.Add(this.addProductCancelButton);
            this.GroupBox2.Controls.Add(this.updateExistingProductSaveButton);
            this.GroupBox2.Location = new System.Drawing.Point(45, 310);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(557, 90);
            this.GroupBox2.TabIndex = 27;
            this.GroupBox2.TabStop = false;
            // 
            // refreshButton
            // 
            this.refreshButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.refreshButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.refreshButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.refreshButton.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshButton.Image = ((System.Drawing.Image)(resources.GetObject("refreshButton.Image")));
            this.refreshButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.refreshButton.Location = new System.Drawing.Point(162, 34);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(90, 33);
            this.refreshButton.TabIndex = 2;
            this.refreshButton.Text = "&Refresh ";
            this.refreshButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.refreshButton.UseVisualStyleBackColor = false;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // addProductCancelButton
            // 
            this.addProductCancelButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.addProductCancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addProductCancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addProductCancelButton.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProductCancelButton.Image = ((System.Drawing.Image)(resources.GetObject("addProductCancelButton.Image")));
            this.addProductCancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addProductCancelButton.Location = new System.Drawing.Point(339, 34);
            this.addProductCancelButton.Name = "addProductCancelButton";
            this.addProductCancelButton.Size = new System.Drawing.Size(78, 33);
            this.addProductCancelButton.TabIndex = 1;
            this.addProductCancelButton.Text = "&Cancel";
            this.addProductCancelButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProductCancelButton.UseVisualStyleBackColor = false;
            // 
            // updateExistingProductSaveButton
            // 
            this.updateExistingProductSaveButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.updateExistingProductSaveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.updateExistingProductSaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.updateExistingProductSaveButton.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateExistingProductSaveButton.Image = ((System.Drawing.Image)(resources.GetObject("updateExistingProductSaveButton.Image")));
            this.updateExistingProductSaveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.updateExistingProductSaveButton.Location = new System.Drawing.Point(258, 34);
            this.updateExistingProductSaveButton.Name = "updateExistingProductSaveButton";
            this.updateExistingProductSaveButton.Size = new System.Drawing.Size(75, 33);
            this.updateExistingProductSaveButton.TabIndex = 0;
            this.updateExistingProductSaveButton.Text = "&Save ";
            this.updateExistingProductSaveButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.updateExistingProductSaveButton.UseVisualStyleBackColor = false;
            this.updateExistingProductSaveButton.Click += new System.EventHandler(this.updateExistingProductSaveButton_Click);
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.BackColor = System.Drawing.Color.White;
            this.descriptionTextBox.Location = new System.Drawing.Point(146, 139);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(456, 25);
            this.descriptionTextBox.TabIndex = 18;
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionLabel.Location = new System.Drawing.Point(59, 142);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(81, 17);
            this.descriptionLabel.TabIndex = 21;
            this.descriptionLabel.Text = "Description :";
            // 
            // retailPriceTextBox
            // 
            this.retailPriceTextBox.BackColor = System.Drawing.Color.White;
            this.retailPriceTextBox.Location = new System.Drawing.Point(146, 234);
            this.retailPriceTextBox.Name = "retailPriceTextBox";
            this.retailPriceTextBox.Size = new System.Drawing.Size(165, 25);
            this.retailPriceTextBox.TabIndex = 25;
            // 
            // retailPriceLabel
            // 
            this.retailPriceLabel.AutoSize = true;
            this.retailPriceLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.retailPriceLabel.Location = new System.Drawing.Point(61, 237);
            this.retailPriceLabel.Name = "retailPriceLabel";
            this.retailPriceLabel.Size = new System.Drawing.Size(79, 17);
            this.retailPriceLabel.TabIndex = 22;
            this.retailPriceLabel.Text = "Retail Price :";
            // 
            // stocksInHandTextBox
            // 
            this.stocksInHandTextBox.BackColor = System.Drawing.Color.White;
            this.stocksInHandTextBox.Location = new System.Drawing.Point(146, 266);
            this.stocksInHandTextBox.Name = "stocksInHandTextBox";
            this.stocksInHandTextBox.Size = new System.Drawing.Size(165, 25);
            this.stocksInHandTextBox.TabIndex = 26;
            // 
            // categoryLabel
            // 
            this.categoryLabel.AutoSize = true;
            this.categoryLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoryLabel.Location = new System.Drawing.Point(69, 175);
            this.categoryLabel.Name = "categoryLabel";
            this.categoryLabel.Size = new System.Drawing.Size(68, 17);
            this.categoryLabel.TabIndex = 23;
            this.categoryLabel.Text = "Category :";
            // 
            // barcodeTextBox
            // 
            this.barcodeTextBox.BackColor = System.Drawing.Color.White;
            this.barcodeTextBox.Location = new System.Drawing.Point(146, 203);
            this.barcodeTextBox.Name = "barcodeTextBox";
            this.barcodeTextBox.Size = new System.Drawing.Size(117, 25);
            this.barcodeTextBox.TabIndex = 19;
            // 
            // barcodeLabel
            // 
            this.barcodeLabel.AutoSize = true;
            this.barcodeLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.barcodeLabel.Location = new System.Drawing.Point(74, 207);
            this.barcodeLabel.Name = "barcodeLabel";
            this.barcodeLabel.Size = new System.Drawing.Size(63, 17);
            this.barcodeLabel.TabIndex = 24;
            this.barcodeLabel.Text = "Barcode :";
            // 
            // productNameTextBox
            // 
            this.productNameTextBox.BackColor = System.Drawing.Color.White;
            this.productNameTextBox.Location = new System.Drawing.Point(146, 108);
            this.productNameTextBox.Name = "productNameTextBox";
            this.productNameTextBox.Size = new System.Drawing.Size(456, 25);
            this.productNameTextBox.TabIndex = 17;
            // 
            // productNameLabel
            // 
            this.productNameLabel.AutoSize = true;
            this.productNameLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productNameLabel.Location = new System.Drawing.Point(42, 111);
            this.productNameLabel.Name = "productNameLabel";
            this.productNameLabel.Size = new System.Drawing.Size(99, 17);
            this.productNameLabel.TabIndex = 20;
            this.productNameLabel.Text = "Product Name :";
            // 
            // productCodeTextBox
            // 
            this.productCodeTextBox.BackColor = System.Drawing.Color.White;
            this.productCodeTextBox.Location = new System.Drawing.Point(256, 36);
            this.productCodeTextBox.Name = "productCodeTextBox";
            this.productCodeTextBox.Size = new System.Drawing.Size(109, 25);
            this.productCodeTextBox.TabIndex = 10;
            // 
            // productCodeLabel
            // 
            this.productCodeLabel.AutoSize = true;
            this.productCodeLabel.Location = new System.Drawing.Point(155, 39);
            this.productCodeLabel.Name = "productCodeLabel";
            this.productCodeLabel.Size = new System.Drawing.Size(95, 17);
            this.productCodeLabel.TabIndex = 3;
            this.productCodeLabel.Text = "Product Code :";
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel1.Controls.Add(this.updateLabel);
            this.Panel1.Location = new System.Drawing.Point(12, 12);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(652, 48);
            this.Panel1.TabIndex = 7;
            // 
            // updateLabel
            // 
            this.updateLabel.AutoSize = true;
            this.updateLabel.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateLabel.ForeColor = System.Drawing.Color.White;
            this.updateLabel.Location = new System.Drawing.Point(9, 0);
            this.updateLabel.Name = "updateLabel";
            this.updateLabel.Size = new System.Drawing.Size(302, 42);
            this.updateLabel.TabIndex = 1;
            this.updateLabel.Text = "Delete Existing Product";
            // 
            // DeleteProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(667, 506);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.Panel1);
            this.Name = "DeleteProductForm";
            this.Text = "Delete Product";
            this.Load += new System.EventHandler(this.DeleteProductForm_Load);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.GroupBox2.ResumeLayout(false);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button loadInfoButton;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.TextBox productCodeTextBox;
        internal System.Windows.Forms.Label productCodeLabel;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label updateLabel;
        internal System.Windows.Forms.TextBox wholesalePriceTextBox;
        internal System.Windows.Forms.Label wholesalePriceLabel;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox textBox1;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Button refreshButton;
        internal System.Windows.Forms.Button addProductCancelButton;
        internal System.Windows.Forms.Button updateExistingProductSaveButton;
        internal System.Windows.Forms.TextBox descriptionTextBox;
        internal System.Windows.Forms.Label descriptionLabel;
        internal System.Windows.Forms.TextBox retailPriceTextBox;
        internal System.Windows.Forms.Label retailPriceLabel;
        internal System.Windows.Forms.TextBox stocksInHandTextBox;
        internal System.Windows.Forms.Label categoryLabel;
        internal System.Windows.Forms.TextBox barcodeTextBox;
        internal System.Windows.Forms.Label barcodeLabel;
        internal System.Windows.Forms.TextBox productNameTextBox;
        internal System.Windows.Forms.Label productNameLabel;
        internal System.Windows.Forms.TextBox subcategoryTextBox;
        internal System.Windows.Forms.TextBox categoryTextBox;
        internal System.Windows.Forms.TextBox supplierTextBox;
        internal System.Windows.Forms.Label supplierLabel;
    }
}