﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS.UI
{
    public partial class AddNewSupplierForm : Form
    {
        public UserInfo loggedInUserInfo = null;

        SupplierGateway supplierGateway = new SupplierGateway();

        public AddNewSupplierForm(UserInfo userInfo)
        {
            InitializeComponent();

            loggedInUserInfo = userInfo;
        }


        private void AddNewSupplierForm_Load(object sender, EventArgs e)
        {
            balanceTextBox.Text = "0";
        }


        private void ClearAll()
        {
            supplierIdTextBox.Text = "";
            companyNameTextBox.Text = "";
            personOfContactTextBox.Text = "";
            addressTextBox.Text = "";
            contactNo1TextBox.Text = "";
            contactNo2TextBox.Text = "";
            emailTextBox.Text = "";
            balanceTextBox.Text = "0";
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            string supplierId = supplierIdTextBox.Text;
            string companyName = companyNameTextBox.Text;
            string personOfContact = personOfContactTextBox.Text;
            string address = addressTextBox.Text;
            string contactNo1 = contactNo1TextBox.Text;
            string contactNo2 = contactNo2TextBox.Text;
            string email = emailTextBox.Text;
            double balance = Convert.ToDouble(balanceTextBox.Text);

            Supplier newSupplier = new Supplier(supplierId, companyName, personOfContact, address, contactNo1, contactNo2, email, balance);

            bool checkIfSupplierExists = supplierGateway.CheckIfSupplierExistsBySupplierId(supplierId);
            if (checkIfSupplierExists == false)
            {
                string result = supplierGateway.AddNewSupplier(newSupplier);
                MessageBox.Show(result);
            }

            ClearAll();
        }


        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearAll();
        }


        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
