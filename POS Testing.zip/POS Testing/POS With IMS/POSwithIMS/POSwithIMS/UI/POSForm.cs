﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;
using POSwithIMS.UI;

namespace POSwithIMS
{
    public partial class POSForm : Form
    {
        private ProductsGateway productsGateway = new ProductsGateway();

        private CustomerGateway customersGateway = new CustomerGateway();

        
        public UserInfo loggedInUserInfo = null;

        public int totalAmmount = 0;
        public int stocksInHand = 0;

        public POSForm(UserInfo userInfo)
        {
            InitializeComponent();

            loggedInUserInfo = userInfo;
        }


        private void POSForm_Load(object sender, EventArgs e)
        {
            barcodeTextBox.Focus();
            
            sellerTextBox.Text = loggedInUserInfo.UserName;
            DateTime dateTime = DateTime.UtcNow.Date;
            sellingDateTextBox.Text = dateTime.ToString("yyyy-MM-dd");
            inVoiceNoTextBox.Text = (productsGateway.GetInvoiceNumber() + 1).ToString();

            List<string> categoryNames = productsGateway.LoadCategory();
            foreach (string category in categoryNames)
            {
                categoryComboBox.Items.Add(category);
            }

            LoadProducts();
        }


        private void categoryComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = categoryComboBox.SelectedItem.ToString();

            string selectedCategoryCode = productsGateway.GetCategoryCodeByCategoryName(selectedCategory);

            List<string> subcategoryNames = productsGateway.GetSubcategoriesByCategoryCode(selectedCategoryCode);

            subcategoryComboBox.Items.Clear();
            foreach (string subcategory in subcategoryNames)
            {
                subcategoryComboBox.Items.Add(subcategory);
            }

            LoadProductsBySelectedCategory(selectedCategory);
        }


        private void subcategoryComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = categoryComboBox.SelectedItem.ToString();
            string selectedSubcategory = subcategoryComboBox.SelectedItem.ToString();

            LoadProductsBySelectedCategorySubcategory(selectedCategory, selectedSubcategory);
        }
        

        private void productQuantityTextBox_TextChanged(object sender, EventArgs e)
        {
            int purchasedQuantity, price = 0, unitPrice = 0;
            if (productQuantityTextBox.Text == "")
            {
                totalTextBox.Text = null;
                price = 0;
            }
            else if (productPriceTextBox.Text == "" && productNameTextBox.Text == "")
            {
                MessageBox.Show("Select product first.");
            }
            else
            {
                try
                {
                    purchasedQuantity = Convert.ToInt32(productQuantityTextBox.Text);
                    unitPrice = Convert.ToInt32(productPriceTextBox.Text);
                    price = purchasedQuantity*unitPrice;
                }
                catch (Exception exception)
                {
                    MessageBox.Show("Enter numbers as quantity.");
                }
            }
            if (price > 0)
            {
                totalTextBox.Text = price.ToString();
            }
        }

        
        private void searchProductTextBox_TextChanged(object sender, EventArgs e)
        {
            productsListView.Items.Clear();
            string searchThisProduct = searchProductTextBox.Text;
            List<Product> productList = productsGateway.GetSpecificProduct(searchThisProduct);

            foreach (Product value in productList)
            {
                ListViewItem item = new ListViewItem(value.ProductName);
                item.SubItems.Add(value.RetailPrice.ToString());
                item.SubItems.Add(value.WholeSalePrice.ToString());
                item.SubItems.Add(value.StocksInHand.ToString());

                productsListView.Items.Add(item);
            }
        }


        public void LoadProducts()
        {
            productsListView.Items.Clear();
            List<Product> productList = productsGateway.GetAllProducts();

            foreach (Product value in productList)
            {
                ListViewItem item = new ListViewItem(value.ProductName);
                item.SubItems.Add(value.RetailPrice.ToString());
                item.SubItems.Add(value.WholeSalePrice.ToString());
                item.SubItems.Add(value.StocksInHand.ToString());

                productsListView.Items.Add(item);
            }
        }


        public void LoadProductsBySelectedCategory(string selectedCategory)
        {
            productsListView.Items.Clear();
            List<Product> productList = productsGateway.GetProductsByCategory(selectedCategory);

            foreach (Product value in productList)
            {
                ListViewItem item = new ListViewItem(value.ProductName);
                item.SubItems.Add(value.RetailPrice.ToString());
                item.SubItems.Add(value.WholeSalePrice.ToString());
                item.SubItems.Add(value.StocksInHand.ToString());

                productsListView.Items.Add(item);
            }
        }


        public void LoadProductsBySelectedCategorySubcategory(string selectedCategory, string selectedSubcategory)
        {
            productsListView.Items.Clear();
            List<Product> productList = productsGateway.GetProductsByCategorySubcategory(selectedCategory, selectedSubcategory);

            foreach (Product value in productList)
            {
                ListViewItem item = new ListViewItem(value.ProductName);
                item.SubItems.Add(value.RetailPrice.ToString());
                item.SubItems.Add(value.WholeSalePrice.ToString());
                item.SubItems.Add(value.StocksInHand.ToString());

                productsListView.Items.Add(item);
            }
        }


        public void ClearProductInfoes()
        {
            productCodeTextBox.Text = null;
            productNameTextBox.Text = null;
            productCategoryTextBox.Text = null;
            productSubcategoryTextBox.Text = null;
            productPriceTextBox.Text = null;
            productQuantityTextBox.Text = null;
            totalTextBox.Text = null;
        }


        public void ClearCustomerInfoes()
        {
            customerAddressTextBox.Text = null;
            customerMobileTextBox.Text = null;
            customerNameTextBox.Text = null;
        }


        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearProductInfoes();

            barcodeTextBox.Focus();
        }


        private void addToCartButton_Click(object sender, EventArgs e)
        {
            string productName = productNameTextBox.Text;
            string productUnitPrice = productPriceTextBox.Text;
            string purchasedQuantity = productQuantityTextBox.Text;
            string total = totalTextBox.Text;

            if (productName != "" && purchasedQuantity != "" && total != "")
            {
                int purchasedQuantityValue = Convert.ToInt32(productQuantityTextBox.Text);
                if (purchasedQuantityValue <= stocksInHand)
                {
                    purchasedProductsListDataGridView.Rows.Add(productName, productUnitPrice, purchasedQuantity, total);
                    ClearProductInfoes();
                }
                else
                {
                    MessageBox.Show("Sorry less stock in hand.");
                    ClearProductInfoes();
                }

            }
            else
            {
                if (purchasedQuantity == "")
                {
                    MessageBox.Show("Enter quantity first.");
                }
            }

            barcodeTextBox.Focus();
        }


        private void productsListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            string productName = "";
            if (productsListView.SelectedIndices.Count <= 0)
            {
                return;
            }

            int selectedindex = productsListView.SelectedIndices[0];

            if (selectedindex >= 0)
            {
                productName = productsListView.Items[selectedindex].Text;
            }

            Product selectedProduct = productsGateway.GetProductByProductName(productName);

            productCodeTextBox.Text = selectedProduct.ProductCode;
            productNameTextBox.Text = selectedProduct.ProductName;
            productCategoryTextBox.Text = selectedProduct.Category;
            stocksInHand = selectedProduct.StocksInHand;

            barcodeTextBox.Focus();
        }


        private void checkRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (checkRadioButton.Checked)
            {
                bankNamesComboBox.Enabled = true;
                List<string> bankList = productsGateway.GetAllBanks();
                foreach (string bank in bankList)
                {
                    bankNamesComboBox.Items.Add(bank);
                }

                checkNoTextBox.ReadOnly = false;
            }
            else
            {
                bankNamesComboBox.Enabled = false;
                checkNoTextBox.ReadOnly = true;
            }
        }


        private void loadProductInfoButton_Click(object sender, EventArgs e)
        {
            string productCode = productCodeTextBox.Text;
            Product productInfo = productsGateway.GetProductByProductCode(productCode);
            productNameTextBox.Text = productInfo.ProductName;
            productCategoryTextBox.Text = productInfo.Category;
            productSubcategoryTextBox.Text = productInfo.Subcategory;
            barcodeTextBox.Text = productInfo.Barcode;

            barcodeTextBox.Focus();
        }


        private void loadCustomerInfoButton_Click(object sender, EventArgs e)
        {
            string customerId = customerIdTextBox.Text;
            Customer customerInfo = customersGateway.GetCustomerInfoByCustomerId(customerId);
            customerNameTextBox.Text = customerInfo.CustomerName;
            customerAddressTextBox.Text = customerInfo.Address;
            customerMobileTextBox.Text = customerInfo.ContactNo1;
        }



        private void cashRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            bankNamesComboBox.Enabled = false;
            checkNoTextBox.ReadOnly = true;
        }

        

        private void purchasedProductsListDataGridView_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            totalAmmount = 0;
            foreach (DataGridViewRow row in purchasedProductsListDataGridView.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null)
                    {
                        int index = cell.ColumnIndex;
                        if (index == 3)
                        {
                            totalAmmount += Convert.ToInt32(cell.Value.ToString());
                        }
                    }
                }
            }
            totalAmmoutRichTextBox.Text = totalAmmount.ToString();

            if (totalAmmoutRichTextBox.Text != "" && ammountPaidRichTextBox.Text != "")
            {
                int ammountPaid = Convert.ToInt32(ammountPaidRichTextBox.Text);
                int returnAmmount = ammountPaid - totalAmmount;
                ammountToBeReturnedRichTextBox.Text = returnAmmount.ToString();
            }
        }


        private void purchasedProductsListDataGridView_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            totalAmmount = 0;
            foreach (DataGridViewRow row in purchasedProductsListDataGridView.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null)
                    {
                        int index = cell.ColumnIndex;
                        if (index == 3)
                        {
                            totalAmmount -= Convert.ToInt32(cell.Value.ToString());
                        }
                    }
                }
            }
            totalAmmoutRichTextBox.Text = totalAmmount.ToString();

            if (totalAmmoutRichTextBox.Text != "" && ammountPaidRichTextBox.Text != "")
            {
                int ammountPaid = Convert.ToInt32(ammountPaidRichTextBox.Text);
                int returnAmmount = ammountPaid - totalAmmount;
                ammountToBeReturnedRichTextBox.Text = returnAmmount.ToString();
            }
        }


        private void discountRichTextBox_TextChanged(object sender, EventArgs e)
        {
            if (discountRichTextBox.Text == "")
            {
                totalAmmoutRichTextBox.Text = totalAmmount.ToString();
            }
            else
            {
                double discount = Convert.ToDouble(discountRichTextBox.Text);
                int ammount = totalAmmount;
                double finalAmmount = ammount - discount;
                totalAmmoutRichTextBox.Text = finalAmmount.ToString();
            }
        }


        private void ammountPaidRichTextBox_TextChanged(object sender, EventArgs e)
        {
            double ammountPaid = 0;
            double ammount = 0;
            if (ammountPaidRichTextBox.Text != "")
            {
                ammountPaid = Convert.ToInt32(ammountPaidRichTextBox.Text);
            }
            if (totalAmmoutRichTextBox.Text != "")
            {
                ammount = Convert.ToDouble(totalAmmoutRichTextBox.Text);
            }
            if (ammountPaid >= ammount)
            {
                double returnAmmount = ammountPaid - ammount;
                ammountToBeReturnedRichTextBox.Text = returnAmmount.ToString();
                ammountDueRichTextBox.Text = "0";
            }
            if (ammountPaid <= ammount)
            {
                double due = ammount - ammountPaid;
                ammountDueRichTextBox.Text = due.ToString();
            }
        }


        private void saveButton_Click(object sender, EventArgs e)
        {
            string salesResult = "";
            string accountResult = "";

            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            if (checkRadioButton.Checked && checkNoTextBox.Text == "" && bankNamesComboBox.SelectedItem.ToString() == "")
            {
                MessageBox.Show("Enter check number and bank name first.");
            }
            else if(customerNameTextBox.Text != "")
            {
                List<PurchasedProduct> purchasedProductsList = new List<PurchasedProduct>();
                List<Sales> salesList = new List<Sales>();

                string inVoiceNo = inVoiceNoTextBox.Text;
                string date = sellingDateTextBox.Text;
                String.Format("yyyy-MM-dd", date);
                string seller = sellerTextBox.Text;
                string customerId = customerIdTextBox.Text;
                string customerName = customerNameTextBox.Text;
                string mobileNo = customerMobileTextBox.Text;
                string address = customerAddressTextBox.Text;
                string checkNo = checkNoTextBox.Text;
                string bankName = bankNamesComboBox.SelectedText;
                string discounts = "";
                string totalAmmount = "";
                string ammountPaid = "";
                string ammountToBeReturned = "";
                double ammountDue = 0;

                if (bankNamesComboBox.SelectedText == null)
                {
                    bankName = "";
                }
                if (discountRichTextBox.Text != "")
                {
                    discounts = discountRichTextBox.Text;
                }
                if (totalAmmoutRichTextBox.Text != "")
                {
                    totalAmmount = totalAmmoutRichTextBox.Text;
                }
                if (ammountPaidRichTextBox.Text != "")
                {
                    ammountPaid = ammountPaidRichTextBox.Text;
                }
                if (ammountToBeReturnedRichTextBox.Text != "")
                {
                    ammountToBeReturned = ammountToBeReturnedRichTextBox.Text;
                }
                if (ammountDueRichTextBox.Text != "")
                {
                    ammountDue = Convert.ToDouble(ammountDueRichTextBox.Text);
                }

                string ammountDueString = ammountDue.ToString();

                PurchaseInfo purchasedInfo = new PurchaseInfo(inVoiceNo, date, seller, customerName, mobileNo, address,
                    checkNo, bankName, discounts, totalAmmount, ammountPaid, ammountToBeReturned, ammountDueString);

                foreach (DataGridViewRow row in purchasedProductsListDataGridView.Rows)
                {
                    if (row.Cells[0].Value != null)
                    {
                        string productName = row.Cells[0].Value.ToString();
                        int unitPrice = Convert.ToInt32(row.Cells[1].Value.ToString());
                        int purchasedQuantity = Convert.ToInt32(row.Cells[2].Value.ToString());
                        int ammount = Convert.ToInt32(row.Cells[3].Value.ToString());
                        if (discountRichTextBox.Text != "")
                        {
                            int discount = Convert.ToInt32(discountRichTextBox.Text);
                            discount = (ammount*discount)/100;
                            ammount = ammount - discount;
                        }

                        PurchasedProduct purchasedProduct = new PurchasedProduct(productName, unitPrice.ToString(),
                            purchasedQuantity.ToString(), ammount.ToString());

                        purchasedProductsList.Add(purchasedProduct);

                        Sales sales = new Sales(inVoiceNo, date, seller, customerId, productName,
                                      unitPrice, purchasedQuantity, ammount, checkNo, bankName);

                        salesList.Add(sales);
                    }
                }

                DialogResult dr = MessageBox.Show("Do you want to sale these products?", "Confirm it.",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                if (dr == DialogResult.Yes)
                {
                    double ammountPaidValue = Convert.ToDouble(ammountPaid);
                    salesResult = productsGateway.AddSales(salesList);
                    
                    MessageBox.Show(salesResult);

                    foreach (Sales purchasedProduct in salesList)
                    {
                        ListViewItem item = new ListViewItem(purchasedProduct.ProductName);
                        item.SubItems.Add(purchasedProduct.UnitPrice.ToString());
                        item.SubItems.Add(purchasedProduct.PurchasedQuantity.ToString());
                        item.SubItems.Add(purchasedProduct.Ammount.ToString());
                    }

                    if (ammountDue > 0)
                    {
                        string customerProfileResult = customersGateway.UpdateCustomerAccountAddDue(customerId,ammountDue);
                        MessageBox.Show(customerProfileResult);
                    }
                }
            }

            totalAmmoutRichTextBox.Text = "";
            ammountPaidRichTextBox.Text = "";
            ammountToBeReturnedRichTextBox.Text = "";
            discountRichTextBox.Text = "";
            ammountDueRichTextBox.Text = "";

            if (salesResult == "Sales and inventory has been successfully updated.")
            {
                purchasedProductsListDataGridView.Rows.Clear();
                inVoiceNoTextBox.Text = (productsGateway.GetInvoiceNumber()).ToString();
                ClearProductInfoes();
                ClearCustomerInfoes();
                LoadProducts();
            }
        }


        private void reloadProductsButton_Click(object sender, EventArgs e)
        {
            LoadProducts();
        }


        private void barcodeTextBox_TextChanged(object sender, EventArgs e)
        {
            string barcode = barcodeTextBox.Text;
            Product product = productsGateway.GetProductByBarcode(barcode);
            productCodeTextBox.Text = product.ProductCode;
            productNameTextBox.Text = product.ProductName;
            productCategoryTextBox.Text = product.Category;
        }


        private void cancelButton_Click(object sender, EventArgs e)
        {
            totalAmmoutRichTextBox.Text = "";
            ammountPaidRichTextBox.Text = "";
            ammountToBeReturnedRichTextBox.Text = "";
            discountRichTextBox.Text = "";
            ammountDueRichTextBox.Text = "";
            ammountDueRichTextBox.Text = "";

            purchasedProductsListDataGridView.Rows.Clear();
            ClearProductInfoes();
            ClearCustomerInfoes();
            LoadProducts();
        }

        private void totalAmmoutRichTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        
        
    }

}
