﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS.UI
{
    public partial class CustomersListForm : Form
    {
        public UserInfo loggedInUserInfo = null;

        CustomerGateway customerGateway = new CustomerGateway();

        public CustomersListForm(UserInfo userInfo)
        {
            InitializeComponent();

            loggedInUserInfo = userInfo;
        }


        public void LoadCustomersList()
        {
            List<Customer> customersList = customerGateway.GetAllCustomers();

            customersListView.Items.Clear();

            foreach (Customer value in customersList)
            {
                ListViewItem item = new ListViewItem(value.CustomerId);
                item.SubItems.Add(value.CustomerName);
                item.SubItems.Add(value.Address);
                item.SubItems.Add(value.ContactNo1);
                item.SubItems.Add(value.ContactNo2);
                item.SubItems.Add(value.Email);
                item.SubItems.Add(value.DueAmmount.ToString());

                customersListView.Items.Add(item);
            }
        }


        private void CustomerListForm_Load(object sender, EventArgs e)
        {
            LoadCustomersList();
        }

        
        private void reloadToolStripButton_Click(object sender, EventArgs e)
        {
            LoadCustomersList();
        }


        private void searchToolStripTextBox_TextChanged(object sender, EventArgs e)
        {
            string searchSpecificCustomer = searchToolStripTextBox.Text;

            List<Customer> customersList = customerGateway.GetSpecificCustomers(searchSpecificCustomer);

            customersListView.Items.Clear();

            foreach (Customer value in customersList)
            {
                ListViewItem item = new ListViewItem(value.CustomerId);
                item.SubItems.Add(value.CustomerName);
                item.SubItems.Add(value.Address);
                item.SubItems.Add(value.ContactNo1);
                item.SubItems.Add(value.ContactNo2);
                item.SubItems.Add(value.Email);
                item.SubItems.Add(value.DueAmmount.ToString());

                customersListView.Items.Add(item);
            }
        } 
    }
}
