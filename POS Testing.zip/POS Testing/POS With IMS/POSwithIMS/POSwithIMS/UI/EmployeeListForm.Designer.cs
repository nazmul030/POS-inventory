﻿namespace POSwithIMS
{
    partial class EmployeeListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeListForm));
            this.employeesListView = new System.Windows.Forms.ListView();
            this.employeeIdColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.nameColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dobColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.genderColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.addressColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contactNoColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.emailColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.nidColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.userNameColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.roleColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.passwordColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.searchToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.searchToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.reloadToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lblSearch = new System.Windows.Forms.Label();
            this.ToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeesListView
            // 
            this.employeesListView.BackColor = System.Drawing.Color.White;
            this.employeesListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.employeeIdColumn,
            this.nameColumn,
            this.dobColumn,
            this.genderColumn,
            this.addressColumn,
            this.contactNoColumn,
            this.emailColumn,
            this.nidColumn,
            this.userNameColumn,
            this.roleColumn,
            this.passwordColumnHeader});
            this.employeesListView.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeesListView.FullRowSelect = true;
            this.employeesListView.GridLines = true;
            this.employeesListView.Location = new System.Drawing.Point(0, 43);
            this.employeesListView.Name = "employeesListView";
            this.employeesListView.Size = new System.Drawing.Size(1040, 436);
            this.employeesListView.TabIndex = 32;
            this.employeesListView.UseCompatibleStateImageBehavior = false;
            this.employeesListView.View = System.Windows.Forms.View.Details;
            // 
            // employeeIdColumn
            // 
            this.employeeIdColumn.Text = "Employee ID";
            this.employeeIdColumn.Width = 78;
            // 
            // nameColumn
            // 
            this.nameColumn.Text = "Name ";
            this.nameColumn.Width = 120;
            // 
            // dobColumn
            // 
            this.dobColumn.Text = "Date of Birth";
            this.dobColumn.Width = 85;
            // 
            // genderColumn
            // 
            this.genderColumn.Text = "Gender";
            this.genderColumn.Width = 55;
            // 
            // addressColumn
            // 
            this.addressColumn.Text = "Address";
            this.addressColumn.Width = 160;
            // 
            // contactNoColumn
            // 
            this.contactNoColumn.Text = "Contact No.";
            this.contactNoColumn.Width = 90;
            // 
            // emailColumn
            // 
            this.emailColumn.Text = "Email";
            this.emailColumn.Width = 90;
            // 
            // nidColumn
            // 
            this.nidColumn.Text = "NID";
            this.nidColumn.Width = 90;
            // 
            // userNameColumn
            // 
            this.userNameColumn.Text = "Username";
            this.userNameColumn.Width = 85;
            // 
            // roleColumn
            // 
            this.roleColumn.Text = "Role";
            this.roleColumn.Width = 89;
            // 
            // passwordColumnHeader
            // 
            this.passwordColumnHeader.Text = "Password";
            this.passwordColumnHeader.Width = 105;
            // 
            // ToolStrip1
            // 
            this.ToolStrip1.AutoSize = false;
            this.ToolStrip1.BackColor = System.Drawing.Color.SteelBlue;
            this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripLabel1,
            this.searchToolStripLabel,
            this.searchToolStripTextBox,
            this.reloadToolStripButton});
            this.ToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.ToolStrip1.Name = "ToolStrip1";
            this.ToolStrip1.Size = new System.Drawing.Size(1020, 40);
            this.ToolStrip1.TabIndex = 31;
            this.ToolStrip1.Text = "ToolStrip1";
            // 
            // ToolStripLabel1
            // 
            this.ToolStripLabel1.Name = "ToolStripLabel1";
            this.ToolStripLabel1.Size = new System.Drawing.Size(16, 37);
            this.ToolStripLabel1.Text = "   ";
            // 
            // searchToolStripLabel
            // 
            this.searchToolStripLabel.Name = "searchToolStripLabel";
            this.searchToolStripLabel.Size = new System.Drawing.Size(42, 37);
            this.searchToolStripLabel.Text = "&Search";
            // 
            // searchToolStripTextBox
            // 
            this.searchToolStripTextBox.Name = "searchToolStripTextBox";
            this.searchToolStripTextBox.Size = new System.Drawing.Size(100, 40);
            this.searchToolStripTextBox.TextChanged += new System.EventHandler(this.searchToolStripTextBox_TextChanged);
            // 
            // reloadToolStripButton
            // 
            this.reloadToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("reloadToolStripButton.Image")));
            this.reloadToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.reloadToolStripButton.Name = "reloadToolStripButton";
            this.reloadToolStripButton.Size = new System.Drawing.Size(63, 37);
            this.reloadToolStripButton.Text = "&Reload";
            this.reloadToolStripButton.Click += new System.EventHandler(this.reloadToolStripButton_Click);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(531, 9);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(41, 13);
            this.lblSearch.TabIndex = 33;
            this.lblSearch.Text = "Search";
            this.lblSearch.Visible = false;
            // 
            // EmployeeListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 477);
            this.Controls.Add(this.employeesListView);
            this.Controls.Add(this.ToolStrip1);
            this.Controls.Add(this.lblSearch);
            this.Name = "EmployeeListForm";
            this.Text = "Employee List";
            this.Load += new System.EventHandler(this.EmployeeListForm_Load);
            this.ToolStrip1.ResumeLayout(false);
            this.ToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.ListView employeesListView;
        internal System.Windows.Forms.ColumnHeader employeeIdColumn;
        internal System.Windows.Forms.ColumnHeader nameColumn;
        internal System.Windows.Forms.ColumnHeader contactNoColumn;
        internal System.Windows.Forms.ColumnHeader addressColumn;
        internal System.Windows.Forms.ColumnHeader userNameColumn;
        internal System.Windows.Forms.ColumnHeader roleColumn;
        internal System.Windows.Forms.ToolStrip ToolStrip1;
        internal System.Windows.Forms.ToolStripLabel ToolStripLabel1;
        internal System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.ColumnHeader dobColumn;
        private System.Windows.Forms.ColumnHeader genderColumn;
        private System.Windows.Forms.ColumnHeader emailColumn;
        private System.Windows.Forms.ColumnHeader nidColumn;
        private System.Windows.Forms.ColumnHeader passwordColumnHeader;
        private System.Windows.Forms.ToolStripLabel searchToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox searchToolStripTextBox;
        private System.Windows.Forms.ToolStripButton reloadToolStripButton;
    }
}