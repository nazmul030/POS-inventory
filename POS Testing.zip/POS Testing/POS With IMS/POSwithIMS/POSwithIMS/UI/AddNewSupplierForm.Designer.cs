﻿namespace POSwithIMS.UI
{
    partial class AddNewSupplierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewSupplierForm));
            this.Panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.supplierInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.personOfContactTextBox = new System.Windows.Forms.TextBox();
            this.personOfContactLabel = new System.Windows.Forms.Label();
            this.contactNo2TextBox = new System.Windows.Forms.TextBox();
            this.contactNo2Label = new System.Windows.Forms.Label();
            this.balanceTextBox = new System.Windows.Forms.TextBox();
            this.balanceLabel = new System.Windows.Forms.Label();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.supplierIdTextBox = new System.Windows.Forms.TextBox();
            this.supplierIdLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.cancelButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.addressLabel = new System.Windows.Forms.Label();
            this.contactNo1TextBox = new System.Windows.Forms.TextBox();
            this.contactNo1Label = new System.Windows.Forms.Label();
            this.companyNameTextBox = new System.Windows.Forms.TextBox();
            this.companyNameLabel = new System.Windows.Forms.Label();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.supplierInformationGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel1.Controls.Add(this.pictureBox2);
            this.Panel1.Controls.Add(this.lblTitle);
            this.Panel1.Location = new System.Drawing.Point(9, 12);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(558, 55);
            this.Panel1.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(28, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 42);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(71, 3);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(241, 42);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Add New Supplier";
            // 
            // supplierInformationGroupBox
            // 
            this.supplierInformationGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.supplierInformationGroupBox.Controls.Add(this.personOfContactTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.personOfContactLabel);
            this.supplierInformationGroupBox.Controls.Add(this.contactNo2TextBox);
            this.supplierInformationGroupBox.Controls.Add(this.contactNo2Label);
            this.supplierInformationGroupBox.Controls.Add(this.balanceTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.balanceLabel);
            this.supplierInformationGroupBox.Controls.Add(this.addressTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.supplierIdTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.supplierIdLabel);
            this.supplierInformationGroupBox.Controls.Add(this.clearButton);
            this.supplierInformationGroupBox.Controls.Add(this.emailTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.emailLabel);
            this.supplierInformationGroupBox.Controls.Add(this.cancelButton);
            this.supplierInformationGroupBox.Controls.Add(this.saveButton);
            this.supplierInformationGroupBox.Controls.Add(this.addressLabel);
            this.supplierInformationGroupBox.Controls.Add(this.contactNo1TextBox);
            this.supplierInformationGroupBox.Controls.Add(this.contactNo1Label);
            this.supplierInformationGroupBox.Controls.Add(this.companyNameTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.companyNameLabel);
            this.supplierInformationGroupBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supplierInformationGroupBox.Location = new System.Drawing.Point(9, 73);
            this.supplierInformationGroupBox.Name = "supplierInformationGroupBox";
            this.supplierInformationGroupBox.Size = new System.Drawing.Size(558, 372);
            this.supplierInformationGroupBox.TabIndex = 9;
            this.supplierInformationGroupBox.TabStop = false;
            this.supplierInformationGroupBox.Text = "Supplier Information";
            // 
            // personOfContactTextBox
            // 
            this.personOfContactTextBox.BackColor = System.Drawing.Color.White;
            this.personOfContactTextBox.Location = new System.Drawing.Point(168, 79);
            this.personOfContactTextBox.Name = "personOfContactTextBox";
            this.personOfContactTextBox.Size = new System.Drawing.Size(364, 25);
            this.personOfContactTextBox.TabIndex = 50;
            // 
            // personOfContactLabel
            // 
            this.personOfContactLabel.AutoSize = true;
            this.personOfContactLabel.Location = new System.Drawing.Point(43, 82);
            this.personOfContactLabel.Name = "personOfContactLabel";
            this.personOfContactLabel.Size = new System.Drawing.Size(119, 17);
            this.personOfContactLabel.TabIndex = 51;
            this.personOfContactLabel.Text = "Person of Contact :";
            // 
            // contactNo2TextBox
            // 
            this.contactNo2TextBox.BackColor = System.Drawing.Color.White;
            this.contactNo2TextBox.Location = new System.Drawing.Point(426, 186);
            this.contactNo2TextBox.Name = "contactNo2TextBox";
            this.contactNo2TextBox.Size = new System.Drawing.Size(106, 25);
            this.contactNo2TextBox.TabIndex = 49;
            // 
            // contactNo2Label
            // 
            this.contactNo2Label.AutoSize = true;
            this.contactNo2Label.Location = new System.Drawing.Point(325, 189);
            this.contactNo2Label.Name = "contactNo2Label";
            this.contactNo2Label.Size = new System.Drawing.Size(95, 17);
            this.contactNo2Label.TabIndex = 48;
            this.contactNo2Label.Text = "Contact No. 2 :";
            // 
            // balanceTextBox
            // 
            this.balanceTextBox.Location = new System.Drawing.Point(168, 263);
            this.balanceTextBox.Name = "balanceTextBox";
            this.balanceTextBox.Size = new System.Drawing.Size(141, 25);
            this.balanceTextBox.TabIndex = 47;
            // 
            // balanceLabel
            // 
            this.balanceLabel.AutoSize = true;
            this.balanceLabel.Location = new System.Drawing.Point(103, 266);
            this.balanceLabel.Name = "balanceLabel";
            this.balanceLabel.Size = new System.Drawing.Size(59, 17);
            this.balanceLabel.TabIndex = 45;
            this.balanceLabel.Text = "Balance :";
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(168, 119);
            this.addressTextBox.Multiline = true;
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(364, 51);
            this.addressTextBox.TabIndex = 42;
            // 
            // supplierIdTextBox
            // 
            this.supplierIdTextBox.Location = new System.Drawing.Point(168, 226);
            this.supplierIdTextBox.Name = "supplierIdTextBox";
            this.supplierIdTextBox.Size = new System.Drawing.Size(141, 25);
            this.supplierIdTextBox.TabIndex = 39;
            // 
            // supplierIdLabel
            // 
            this.supplierIdLabel.AutoSize = true;
            this.supplierIdLabel.Location = new System.Drawing.Point(83, 229);
            this.supplierIdLabel.Name = "supplierIdLabel";
            this.supplierIdLabel.Size = new System.Drawing.Size(79, 17);
            this.supplierIdLabel.TabIndex = 38;
            this.supplierIdLabel.Text = "Supplier ID :";
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.clearButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clearButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clearButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Image = ((System.Drawing.Image)(resources.GetObject("clearButton.Image")));
            this.clearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.clearButton.Location = new System.Drawing.Point(160, 319);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(71, 24);
            this.clearButton.TabIndex = 37;
            this.clearButton.Text = "&Clear";
            this.clearButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.clearButton.UseVisualStyleBackColor = false;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // emailTextBox
            // 
            this.emailTextBox.BackColor = System.Drawing.Color.White;
            this.emailTextBox.Location = new System.Drawing.Point(382, 226);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(150, 25);
            this.emailTextBox.TabIndex = 25;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(330, 229);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(46, 17);
            this.emailLabel.TabIndex = 24;
            this.emailLabel.Text = "Email :";
            // 
            // cancelButton
            // 
            this.cancelButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancelButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Image = ((System.Drawing.Image)(resources.GetObject("cancelButton.Image")));
            this.cancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancelButton.Location = new System.Drawing.Point(348, 319);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 24);
            this.cancelButton.TabIndex = 10;
            this.cancelButton.Text = "&Cancel";
            this.cancelButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancelButton.UseVisualStyleBackColor = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.saveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.saveButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.saveButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Image = ((System.Drawing.Image)(resources.GetObject("saveButton.Image")));
            this.saveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveButton.Location = new System.Drawing.Point(257, 319);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(68, 24);
            this.saveButton.TabIndex = 9;
            this.saveButton.Text = "&Save ";
            this.saveButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(99, 136);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(63, 17);
            this.addressLabel.TabIndex = 4;
            this.addressLabel.Text = "Address :";
            // 
            // contactNo1TextBox
            // 
            this.contactNo1TextBox.BackColor = System.Drawing.Color.White;
            this.contactNo1TextBox.Location = new System.Drawing.Point(168, 186);
            this.contactNo1TextBox.Name = "contactNo1TextBox";
            this.contactNo1TextBox.Size = new System.Drawing.Size(124, 25);
            this.contactNo1TextBox.TabIndex = 7;
            // 
            // contactNo1Label
            // 
            this.contactNo1Label.AutoSize = true;
            this.contactNo1Label.Location = new System.Drawing.Point(67, 189);
            this.contactNo1Label.Name = "contactNo1Label";
            this.contactNo1Label.Size = new System.Drawing.Size(95, 17);
            this.contactNo1Label.TabIndex = 4;
            this.contactNo1Label.Text = "Contact No. 1 :";
            // 
            // companyNameTextBox
            // 
            this.companyNameTextBox.BackColor = System.Drawing.Color.White;
            this.companyNameTextBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.companyNameTextBox.Location = new System.Drawing.Point(168, 44);
            this.companyNameTextBox.Name = "companyNameTextBox";
            this.companyNameTextBox.Size = new System.Drawing.Size(364, 25);
            this.companyNameTextBox.TabIndex = 0;
            // 
            // companyNameLabel
            // 
            this.companyNameLabel.AutoSize = true;
            this.companyNameLabel.Location = new System.Drawing.Point(53, 47);
            this.companyNameLabel.Name = "companyNameLabel";
            this.companyNameLabel.Size = new System.Drawing.Size(109, 17);
            this.companyNameLabel.TabIndex = 4;
            this.companyNameLabel.Text = "Company Name :";
            // 
            // AddNewSupplierForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(577, 456);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.supplierInformationGroupBox);
            this.Name = "AddNewSupplierForm";
            this.Text = "Add New Supplier";
            this.Load += new System.EventHandler(this.AddNewSupplierForm_Load);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.supplierInformationGroupBox.ResumeLayout(false);
            this.supplierInformationGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        internal System.Windows.Forms.Label lblTitle;
        internal System.Windows.Forms.GroupBox supplierInformationGroupBox;
        internal System.Windows.Forms.TextBox contactNo2TextBox;
        internal System.Windows.Forms.Label contactNo2Label;
        private System.Windows.Forms.TextBox balanceTextBox;
        private System.Windows.Forms.Label balanceLabel;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox supplierIdTextBox;
        private System.Windows.Forms.Label supplierIdLabel;
        private System.Windows.Forms.Button clearButton;
        internal System.Windows.Forms.TextBox emailTextBox;
        internal System.Windows.Forms.Label emailLabel;
        internal System.Windows.Forms.Button cancelButton;
        internal System.Windows.Forms.Button saveButton;
        internal System.Windows.Forms.Label addressLabel;
        internal System.Windows.Forms.TextBox contactNo1TextBox;
        internal System.Windows.Forms.Label contactNo1Label;
        internal System.Windows.Forms.TextBox companyNameTextBox;
        internal System.Windows.Forms.Label companyNameLabel;
        internal System.Windows.Forms.TextBox personOfContactTextBox;
        internal System.Windows.Forms.Label personOfContactLabel;
    }
}