﻿namespace POSwithIMS
{
    partial class CategoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addCategoryButton = new System.Windows.Forms.Button();
            this.removeCategoryButton = new System.Windows.Forms.Button();
            this.categoryNameTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.subcategoryGroupBox = new System.Windows.Forms.GroupBox();
            this.subcategoryNameTextBox = new System.Windows.Forms.TextBox();
            this.addSubcategoryButton = new System.Windows.Forms.Button();
            this.removeSubcategoryButton = new System.Windows.Forms.Button();
            this.treeView = new System.Windows.Forms.TreeView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.categoriesPanel = new System.Windows.Forms.Panel();
            this.categoriesLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.subcategoryGroupBox.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.categoriesPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // addCategoryButton
            // 
            this.addCategoryButton.Location = new System.Drawing.Point(22, 70);
            this.addCategoryButton.Name = "addCategoryButton";
            this.addCategoryButton.Size = new System.Drawing.Size(103, 33);
            this.addCategoryButton.TabIndex = 1;
            this.addCategoryButton.Text = "Add Category";
            this.addCategoryButton.UseVisualStyleBackColor = true;
            this.addCategoryButton.Click += new System.EventHandler(this.addCategoryButton_Click);
            // 
            // removeCategoryButton
            // 
            this.removeCategoryButton.Location = new System.Drawing.Point(31, 109);
            this.removeCategoryButton.Name = "removeCategoryButton";
            this.removeCategoryButton.Size = new System.Drawing.Size(84, 23);
            this.removeCategoryButton.TabIndex = 2;
            this.removeCategoryButton.Text = "Remove Category";
            this.removeCategoryButton.UseVisualStyleBackColor = true;
            this.removeCategoryButton.Click += new System.EventHandler(this.removeCategoryButton_Click);
            // 
            // categoryNameTextBox
            // 
            this.categoryNameTextBox.Location = new System.Drawing.Point(22, 42);
            this.categoryNameTextBox.Name = "categoryNameTextBox";
            this.categoryNameTextBox.Size = new System.Drawing.Size(103, 22);
            this.categoryNameTextBox.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox1.Controls.Add(this.subcategoryGroupBox);
            this.groupBox1.Controls.Add(this.treeView);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(11, 59);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(565, 402);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Categories";
            // 
            // subcategoryGroupBox
            // 
            this.subcategoryGroupBox.Controls.Add(this.subcategoryNameTextBox);
            this.subcategoryGroupBox.Controls.Add(this.addSubcategoryButton);
            this.subcategoryGroupBox.Controls.Add(this.removeSubcategoryButton);
            this.subcategoryGroupBox.Location = new System.Drawing.Point(358, 104);
            this.subcategoryGroupBox.Name = "subcategoryGroupBox";
            this.subcategoryGroupBox.Size = new System.Drawing.Size(164, 157);
            this.subcategoryGroupBox.TabIndex = 7;
            this.subcategoryGroupBox.TabStop = false;
            this.subcategoryGroupBox.Text = "Edit Subcategory List";
            // 
            // subcategoryNameTextBox
            // 
            this.subcategoryNameTextBox.Location = new System.Drawing.Point(32, 42);
            this.subcategoryNameTextBox.Name = "subcategoryNameTextBox";
            this.subcategoryNameTextBox.Size = new System.Drawing.Size(103, 22);
            this.subcategoryNameTextBox.TabIndex = 3;
            // 
            // addSubcategoryButton
            // 
            this.addSubcategoryButton.Location = new System.Drawing.Point(16, 70);
            this.addSubcategoryButton.Name = "addSubcategoryButton";
            this.addSubcategoryButton.Size = new System.Drawing.Size(129, 33);
            this.addSubcategoryButton.TabIndex = 1;
            this.addSubcategoryButton.Text = "Add Subcategory";
            this.addSubcategoryButton.UseVisualStyleBackColor = true;
            this.addSubcategoryButton.Click += new System.EventHandler(this.addSubcategoryButton_Click);
            // 
            // removeSubcategoryButton
            // 
            this.removeSubcategoryButton.Location = new System.Drawing.Point(47, 109);
            this.removeSubcategoryButton.Name = "removeSubcategoryButton";
            this.removeSubcategoryButton.Size = new System.Drawing.Size(72, 23);
            this.removeSubcategoryButton.TabIndex = 2;
            this.removeSubcategoryButton.Text = "Remove Subcategory";
            this.removeSubcategoryButton.UseVisualStyleBackColor = true;
            this.removeSubcategoryButton.Click += new System.EventHandler(this.removeSubcategoryButton_Click);
            // 
            // treeView
            // 
            this.treeView.Location = new System.Drawing.Point(38, 45);
            this.treeView.Name = "treeView";
            this.treeView.Size = new System.Drawing.Size(134, 327);
            this.treeView.TabIndex = 4;
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.categoryNameTextBox);
            this.groupBox2.Controls.Add(this.addCategoryButton);
            this.groupBox2.Controls.Add(this.removeCategoryButton);
            this.groupBox2.Location = new System.Drawing.Point(189, 104);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(147, 157);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Edit Category List";
            // 
            // categoriesPanel
            // 
            this.categoriesPanel.BackColor = System.Drawing.Color.SteelBlue;
            this.categoriesPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.categoriesPanel.Controls.Add(this.categoriesLabel);
            this.categoriesPanel.Location = new System.Drawing.Point(12, 12);
            this.categoriesPanel.Name = "categoriesPanel";
            this.categoriesPanel.Size = new System.Drawing.Size(564, 41);
            this.categoriesPanel.TabIndex = 6;
            // 
            // categoriesLabel
            // 
            this.categoriesLabel.AutoSize = true;
            this.categoriesLabel.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoriesLabel.ForeColor = System.Drawing.Color.White;
            this.categoriesLabel.Location = new System.Drawing.Point(13, -1);
            this.categoriesLabel.Name = "categoriesLabel";
            this.categoriesLabel.Size = new System.Drawing.Size(124, 36);
            this.categoriesLabel.TabIndex = 1;
            this.categoriesLabel.Text = "Categories";
            // 
            // CategoryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(589, 479);
            this.Controls.Add(this.categoriesPanel);
            this.Controls.Add(this.groupBox1);
            this.Name = "CategoryForm";
            this.Text = "Category";
            this.Load += new System.EventHandler(this.CategoryForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.subcategoryGroupBox.ResumeLayout(false);
            this.subcategoryGroupBox.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.categoriesPanel.ResumeLayout(false);
            this.categoriesPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button addCategoryButton;
        private System.Windows.Forms.Button removeCategoryButton;
        private System.Windows.Forms.TextBox categoryNameTextBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        internal System.Windows.Forms.Panel categoriesPanel;
        internal System.Windows.Forms.Label categoriesLabel;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.GroupBox subcategoryGroupBox;
        private System.Windows.Forms.TextBox subcategoryNameTextBox;
        private System.Windows.Forms.Button addSubcategoryButton;
        private System.Windows.Forms.Button removeSubcategoryButton;
    }
}