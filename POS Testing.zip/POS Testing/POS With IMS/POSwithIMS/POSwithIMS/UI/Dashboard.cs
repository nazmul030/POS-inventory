﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;

namespace POSwithIMS.UI
{
    public partial class Dashboard : Form
    {
        ProductsGateway Gateway=new ProductsGateway();
        public Dashboard()
        {
            InitializeComponent();
            fillChart();
            fillpieChart();
        }
        private void Dashboard_Load(object sender, EventArgs e)
        {
            fillChart();
        } 

        private void chart1_Click(object sender, EventArgs e)
        {

        }
        private void fillChart()
        {
           
            productColumn.DataSource = Gateway.TopSale();
            //set the member of the chart data source used to data bind to the X-values of the series  
            productColumn.Series["Product"].XValueMember = "ProductName";
            //set the member columns of the chart data source used to data bind to the X-values of the series  
            productColumn.Series["Product"].YValueMembers = "PurchasedQuantity";
            productColumn.Titles.Add("Top Product By Quantity");
           

        }
        private void fillpieChart()
        {

            topselllerproductChart.DataSource = Gateway.TopSale();
            //set the member of the chart data source used to data bind to the X-values of the series  
            topselllerproductChart.Series["Product"].XValueMember = "ProductName";
            //set the member columns of the chart data source used to data bind to the X-values of the series  
            topselllerproductChart.Series["Product"].YValueMembers = "Ammount";
            topselllerproductChart.Titles.Add("Top Product Sell By Ammount");
           



        }

        private void topselllerproductChart_Click(object sender, EventArgs e)
        {

        }   
    }
}
