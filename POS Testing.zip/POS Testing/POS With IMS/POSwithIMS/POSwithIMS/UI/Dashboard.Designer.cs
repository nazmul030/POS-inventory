﻿namespace POSwithIMS.UI
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.topselllerproductChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.productColumn = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.topselllerproductChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productColumn)).BeginInit();
            this.SuspendLayout();
            // 
            // topselllerproductChart
            // 
            this.topselllerproductChart.AllowDrop = true;
            this.topselllerproductChart.BackColor = System.Drawing.Color.Transparent;
            this.topselllerproductChart.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.topselllerproductChart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            chartArea1.AlignmentOrientation = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Vertical | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Horizontal)));
            chartArea1.AxisX.IsLabelAutoFit = false;
            chartArea1.BackColor = System.Drawing.Color.White;
            chartArea1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.LeftRight;
            chartArea1.IsSameFontSizeForAllAxes = true;
            chartArea1.Name = "ChartArea1";
            this.topselllerproductChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.topselllerproductChart.Legends.Add(legend1);
            this.topselllerproductChart.Location = new System.Drawing.Point(3, 3);
            this.topselllerproductChart.Name = "topselllerproductChart";
            this.topselllerproductChart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series1.IsValueShownAsLabel = true;
            series1.Legend = "Legend1";
            series1.Name = "Product";
            this.topselllerproductChart.Series.Add(series1);
            this.topselllerproductChart.Size = new System.Drawing.Size(424, 261);
            this.topselllerproductChart.TabIndex = 0;
            this.topselllerproductChart.Text = "Top 5 Product";
            this.topselllerproductChart.Click += new System.EventHandler(this.topselllerproductChart_Click);
            // 
            // productColumn
            // 
            chartArea2.Name = "ChartArea1";
            this.productColumn.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.productColumn.Legends.Add(legend2);
            this.productColumn.Location = new System.Drawing.Point(444, 3);
            this.productColumn.Name = "productColumn";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Product";
            this.productColumn.Series.Add(series2);
            this.productColumn.Size = new System.Drawing.Size(521, 261);
            this.productColumn.TabIndex = 1;
            this.productColumn.Text = "chart1";
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(963, 530);
            this.Controls.Add(this.productColumn);
            this.Controls.Add(this.topselllerproductChart);
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds;
            this.Text = "Dashboard";
            ((System.ComponentModel.ISupportInitialize)(this.topselllerproductChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productColumn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart topselllerproductChart;
        private System.Windows.Forms.DataVisualization.Charting.Chart productColumn;
    }
}