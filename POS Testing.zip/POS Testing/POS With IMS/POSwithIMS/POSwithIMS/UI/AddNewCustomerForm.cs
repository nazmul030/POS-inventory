﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS.UI
{
    public partial class AddNewCustomerForm : Form
    {
        public UserInfo loggedInUserInfo = null;

        CustomerGateway customerGateway = new CustomerGateway();

        public AddNewCustomerForm(UserInfo userInfo)
        {
            InitializeComponent();

            loggedInUserInfo = userInfo;
        }


        private void ClearAll()
        {
            customerIdTextBox.Text = "";
            customerNameTextBox.Text = "";
            addressTextBox.Text = "";
            contactNo1TextBox.Text = "";
            contactNo2TextBox.Text = "";
            emailTextBox.Text = "";
            balanceTextBox.Text = "";
        }


        private void AddNewCustomerForm_Load(object sender, EventArgs e)
        {
            balanceTextBox.Text = "0";
        }


        private void customerIdTextBox_MouseClick(object sender, MouseEventArgs e)
        {
            int noOfCustomers = customerGateway.GetNumbersOfCustomers() + 1;
            string customerName = customerNameTextBox.Text.Substring(0, 3).ToUpper();
            string customerId = customerName + "-" + noOfCustomers.ToString();
            customerIdTextBox.Text = customerId;
        }


        private void saveButton_Click(object sender, EventArgs e)
        {
            string customerId = customerIdTextBox.Text;
            string customerName = customerNameTextBox.Text;
            string address = addressTextBox.Text;
            string contactNo1 = contactNo1TextBox.Text;
            string contactNo2 = contactNo2TextBox.Text;
            string email = emailTextBox.Text;
            double balance = Convert.ToDouble(balanceTextBox.Text);

            Customer newCustomer = new Customer(customerId, customerName, address, contactNo1, contactNo2, email, balance);
            
            bool checkIfCustomerExists = customerGateway.CheckIfCustomerExistsByCustomerId(customerId);
            if (checkIfCustomerExists == false)
            {
                string result = customerGateway.AddNewCustomer(newCustomer);
                MessageBox.Show(result);
            }

            ClearAll();
        }


        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearAll();
        }


        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
