﻿namespace POSwithIMS
{
    partial class ProductsListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductsListForm));
            this.ToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.productsListView = new System.Windows.Forms.ListView();
            this.serialNoColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.productCodeColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.productNameColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.categoryColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.productDescriptionColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.supplierColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.costingColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.retailPriceColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.wholesalePriceColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.stocksInHandColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.searchProductToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSearchTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.reloadToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.subcategoryColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ToolStripLabel1
            // 
            this.ToolStripLabel1.Name = "ToolStripLabel1";
            this.ToolStripLabel1.Size = new System.Drawing.Size(16, 46);
            this.ToolStripLabel1.Text = "   ";
            // 
            // productsListView
            // 
            this.productsListView.BackColor = System.Drawing.Color.White;
            this.productsListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.serialNoColumnHeader,
            this.productCodeColumnHeader,
            this.productNameColumnHeader,
            this.categoryColumnHeader,
            this.subcategoryColumnHeader,
            this.productDescriptionColumnHeader,
            this.supplierColumnHeader,
            this.costingColumnHeader,
            this.retailPriceColumnHeader,
            this.wholesalePriceColumnHeader,
            this.stocksInHandColumnHeader});
            this.productsListView.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productsListView.FullRowSelect = true;
            this.productsListView.GridLines = true;
            this.productsListView.Location = new System.Drawing.Point(0, 53);
            this.productsListView.Margin = new System.Windows.Forms.Padding(4);
            this.productsListView.Name = "productsListView";
            this.productsListView.Size = new System.Drawing.Size(1258, 554);
            this.productsListView.TabIndex = 33;
            this.productsListView.UseCompatibleStateImageBehavior = false;
            this.productsListView.View = System.Windows.Forms.View.Details;
            // 
            // serialNoColumnHeader
            // 
            this.serialNoColumnHeader.Text = "# ";
            this.serialNoColumnHeader.Width = 50;
            // 
            // productCodeColumnHeader
            // 
            this.productCodeColumnHeader.Text = "Product Code";
            this.productCodeColumnHeader.Width = 95;
            // 
            // productNameColumnHeader
            // 
            this.productNameColumnHeader.Text = "Product Name";
            this.productNameColumnHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.productNameColumnHeader.Width = 150;
            // 
            // categoryColumnHeader
            // 
            this.categoryColumnHeader.Text = "Category";
            this.categoryColumnHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.categoryColumnHeader.Width = 95;
            // 
            // productDescriptionColumnHeader
            // 
            this.productDescriptionColumnHeader.Text = "Product Description";
            this.productDescriptionColumnHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.productDescriptionColumnHeader.Width = 265;
            // 
            // supplierColumnHeader
            // 
            this.supplierColumnHeader.Text = "Supplier";
            this.supplierColumnHeader.Width = 112;
            // 
            // costingColumnHeader
            // 
            this.costingColumnHeader.Text = "Costing";
            this.costingColumnHeader.Width = 90;
            // 
            // retailPriceColumnHeader
            // 
            this.retailPriceColumnHeader.Text = "Retail Price";
            this.retailPriceColumnHeader.Width = 90;
            // 
            // wholesalePriceColumnHeader
            // 
            this.wholesalePriceColumnHeader.Text = "Whole Sale Price";
            this.wholesalePriceColumnHeader.Width = 110;
            // 
            // stocksInHandColumnHeader
            // 
            this.stocksInHandColumnHeader.Text = "Stocks In Hand";
            this.stocksInHandColumnHeader.Width = 105;
            // 
            // ToolStrip1
            // 
            this.ToolStrip1.AutoSize = false;
            this.ToolStrip1.BackColor = System.Drawing.Color.SteelBlue;
            this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripLabel1,
            this.searchProductToolStripButton,
            this.toolStripSearchTextBox,
            this.reloadToolStripButton});
            this.ToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.ToolStrip1.Name = "ToolStrip1";
            this.ToolStrip1.Size = new System.Drawing.Size(1260, 49);
            this.ToolStrip1.TabIndex = 32;
            this.ToolStrip1.Text = "ToolStrip1";
            // 
            // searchProductToolStripButton
            // 
            this.searchProductToolStripButton.AutoSize = false;
            this.searchProductToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.searchProductToolStripButton.Name = "searchProductToolStripButton";
            this.searchProductToolStripButton.Size = new System.Drawing.Size(65, 40);
            this.searchProductToolStripButton.Text = "&Search";
            // 
            // toolStripSearchTextBox
            // 
            this.toolStripSearchTextBox.Name = "toolStripSearchTextBox";
            this.toolStripSearchTextBox.Size = new System.Drawing.Size(132, 49);
            this.toolStripSearchTextBox.TextChanged += new System.EventHandler(this.toolStripSearchTextBox_TextChanged);
            // 
            // reloadToolStripButton
            // 
            this.reloadToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("reloadToolStripButton.Image")));
            this.reloadToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.reloadToolStripButton.Name = "reloadToolStripButton";
            this.reloadToolStripButton.Size = new System.Drawing.Size(63, 46);
            this.reloadToolStripButton.Text = "&Reload";
            this.reloadToolStripButton.Click += new System.EventHandler(this.reloadToolStripButton_Click);
            // 
            // subcategoryColumnHeader
            // 
            this.subcategoryColumnHeader.Text = "Subcategory";
            this.subcategoryColumnHeader.Width = 90;
            // 
            // ProductsListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1260, 609);
            this.Controls.Add(this.productsListView);
            this.Controls.Add(this.ToolStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ProductsListForm";
            this.Text = "Products List";
            this.Load += new System.EventHandler(this.ProductsListForm_Load);
            this.ToolStrip1.ResumeLayout(false);
            this.ToolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.ToolStripLabel ToolStripLabel1;
        internal System.Windows.Forms.ColumnHeader serialNoColumnHeader;
        private System.Windows.Forms.ColumnHeader productNameColumnHeader;
        internal System.Windows.Forms.ColumnHeader categoryColumnHeader;
        internal System.Windows.Forms.ColumnHeader productDescriptionColumnHeader;
        internal System.Windows.Forms.ColumnHeader retailPriceColumnHeader;
        internal System.Windows.Forms.ColumnHeader stocksInHandColumnHeader;
        internal System.Windows.Forms.ToolStrip ToolStrip1;
        internal System.Windows.Forms.ToolStripButton searchProductToolStripButton;
        private System.Windows.Forms.ToolStripTextBox toolStripSearchTextBox;
        public System.Windows.Forms.ListView productsListView;
        private System.Windows.Forms.ColumnHeader supplierColumnHeader;
        private System.Windows.Forms.ToolStripButton reloadToolStripButton;
        private System.Windows.Forms.ColumnHeader costingColumnHeader;
        private System.Windows.Forms.ColumnHeader wholesalePriceColumnHeader;
        private System.Windows.Forms.ColumnHeader productCodeColumnHeader;
        private System.Windows.Forms.ColumnHeader subcategoryColumnHeader;
    }
}