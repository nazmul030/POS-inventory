﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS
{
    public partial class AddNewProductForm : Form
    {
        public UserInfo loggedInUserInfo = null;

        ProductsGateway productsGateway = new ProductsGateway();

        SupplierGateway supplierGateway = new SupplierGateway();

        public AddNewProductForm(UserInfo userInfo)
        {
            InitializeComponent();

            loggedInUserInfo = userInfo;
        }


        private void LoadCompanyNames()
        {
            List<string> suppliersCompanyNames = new List<string>();
            suppliersCompanyNames = supplierGateway.GetAllSuppliersCompanyName();

            suppliersComboBox.Items.Clear();
            foreach (string companyName in suppliersCompanyNames)
            {
                suppliersComboBox.Items.Add(companyName);
            }
        }


        private void AddNewProductForm_Load(object sender, EventArgs e)
        {
            List<string> categoryList = new List<string>();
            categoryList = productsGateway.LoadCategory();
            foreach (var name in categoryList)
            {
                categoryComboBox.Items.Add(name);
            }

            LoadCompanyNames();
        }


        private void addProductSaveButton_Click(object sender, EventArgs e)
        {
            string productCode = productCodeTextBox.Text;
            string productName = productNameTextBox.Text;
            string category = categoryComboBox.Text;
            string subcategory = subcategoryComboBox.Text;
            string description = descriptionTextBox.Text;
            string supplier = suppliersComboBox.Text;
            string barcode = barcodeTextBox.Text;
            int costingPrice = Convert.ToInt32(costingPriceTextBox.Text);
            int retailPrice = Convert.ToInt32(retailPriceTextBox.Text);
            int wholesalePrice = Convert.ToInt32(wholesalePriceTextBox.Text);
            int stocksInHand = Convert.ToInt32(stocksInHandTextBox.Text);

            if (subcategory == null)
            {
                subcategory = "";
            }

            if (barcode != "")
            {
                Product product = new Product(productCode, productName, category, subcategory, description, supplier, barcode, costingPrice, retailPrice, wholesalePrice, stocksInHand);

                string result = productsGateway.AddProduct(product);
                MessageBox.Show(result);
            }
            else
            {
                MessageBox.Show("Generate barcode first!");
            }
        }


        private void barcodeGeneratorButton_Click(object sender, EventArgs e)
        {
            string productCode = productCodeTextBox.Text;
            string category = "";
            if (categoryComboBox.SelectedItem != null)
            {
                category = categoryComboBox.SelectedItem.ToString();
            }
            if (category != "" && productCode != "")
            {
                string barcode = "";
                category = category.ToUpper();
                barcode = category[0].ToString() + category[1].ToString() + "-" + productCode;
                barcodeTextBox.Text = barcode;
            }
            else if (category != "" && productCode == "")
            {
                MessageBox.Show("Enter product code first.");
            }
            else if (category == "" && productCode != "")
            {
                MessageBox.Show("Select category first.");
            }
            else if (category == "" && productCode == "")
            {
                MessageBox.Show("Enter product code and select category first.");
            }
        }

        
        private void categoryComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = "";

            if (categoryComboBox.SelectedItem.ToString() != null)
            {
                selectedCategory = categoryComboBox.SelectedItem.ToString();
            }

            string selectedCategoryCode = productsGateway.GetCategoryCodeByCategoryName(selectedCategory);

            List<string> subcategoryNames = productsGateway.GetSubcategoriesByCategoryCode(selectedCategoryCode);

            subcategoryComboBox.Items.Clear();
            foreach (string subcategory in subcategoryNames)
            {
                subcategoryComboBox.Items.Add(subcategory);
            }
        }


        private void addProductCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            productCodeTextBox.Text = null;
            productNameTextBox.Text = null;
            categoryComboBox.Text = null;
            subcategoryComboBox.Text = null;
            descriptionTextBox.Text = null;
            suppliersComboBox.Text = null;
            barcodeTextBox.Text = null;
            costingPriceTextBox.Text = null;
            retailPriceTextBox.Text = null;
            wholesalePriceTextBox.Text = null;
            stocksInHandTextBox.Text = null;

            LoadCompanyNames();
        }
    }
}
