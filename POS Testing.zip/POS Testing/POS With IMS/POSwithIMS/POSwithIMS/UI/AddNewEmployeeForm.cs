﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS
{
    public partial class AddNewEmployeeForm : Form
    {
        public string imageName;

        EmployeeGateway userGateway = new EmployeeGateway();

        public UserInfo loggedInUserInfo = null;

        public AddNewEmployeeForm(UserInfo userInfo)
        {
            loggedInUserInfo = userInfo;

            InitializeComponent();
        }

        private void AddNewStaffForm_Load(object sender, EventArgs e)
        {
            string[] months = new[]
            {
                "January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
                "November", "December"
            };
            foreach (string value in months)
            {
                monthComboBox.Items.Add(value);
            }
            
            for (int year = 1950; year <= 2009; year++)
            {
                yearComboBox.Items.Add(year);
            }
            
            postRoleComboBox.Items.Add("Admin");
            postRoleComboBox.Items.Add("Seller");
            postRoleComboBox.Items.Add("Employee");
        }

        private void monthComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (monthComboBox.SelectedItem.ToString() == "January" || monthComboBox.SelectedItem.ToString() == "March" ||
                monthComboBox.SelectedItem.ToString() == "May" || monthComboBox.SelectedItem.ToString() == "July" ||
                monthComboBox.SelectedItem.ToString() == "August" || monthComboBox.SelectedItem.ToString() == "October" ||
                monthComboBox.SelectedItem.ToString() == "December")
            {
                dayComboBox.Items.Clear();
                for (int day = 1; day <= 31; day++)
                {
                    dayComboBox.Items.Add(day);
                }
            }
            else if (monthComboBox.SelectedItem.ToString() == "February")
            {
                dayComboBox.Items.Clear();
                for (int day = 1; day <= 29; day++)
                {
                    dayComboBox.Items.Add(day);
                }
            }
            else if (monthComboBox.SelectedItem.ToString() == "April" || monthComboBox.SelectedItem.ToString() == "June" ||
                     monthComboBox.SelectedItem.ToString() == "September" ||
                     monthComboBox.SelectedItem.ToString() == "November")
            {
                dayComboBox.Items.Clear();
                for (int day = 1; day <= 30; day++)
                {
                    dayComboBox.Items.Add(day);
                }
            }
            else
            {
                dayComboBox.Items.Clear();
            }
        }

        private void browseFolderButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Images|*.bmp;*.jpg;*.gif|All files|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                var image = Bitmap.FromFile(openFileDialog.FileName);
                var resizedImage = ScaleImage(image, 107, 142);
                pictureBox.Image = resizedImage;
                imageName = openFileDialog.FileName;
            }
        }

        public static Image ScaleImage(Image image, int maxWidth, int maxHeight)
        {
            var ratioX = (double)maxWidth / image.Width;
            var ratioY = (double)maxHeight / image.Height;
            var ratio = Math.Min(ratioX, ratioY);

            var newWidth = (int)(image.Width * ratio);
            var newHeight = (int)(image.Height * ratio);

            var newImage = new Bitmap(newWidth, newHeight);
            Graphics.FromImage(newImage).DrawImage(image, 0, 0, newWidth, newHeight);
            return newImage;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        
        private void saveButton_Click(object sender, EventArgs e)
        {
            int flag = 0;
            string path = "";

            string employeeId = employeeIdTextBox.Text;

            string firstName = "";
            if (firstNameTextBox.Text != "")
            {
                firstName = firstNameTextBox.Text;
            }
            else
            {
                flag = 1;
                MessageBox.Show("Enter first name first.");
            }

            string middleName = "";
            if (middleNameTextBox.Text != "")
            {
                middleName = middleNameTextBox.Text;
            }

            string lastName = "";
            if (lastNameTextBox.Text != "")
            {
                lastName = lastNameTextBox.Text;
            }

            string dateOfBirth = "";
            if (dayComboBox.SelectedItem != "" || monthComboBox.SelectedItem != "" || yearComboBox.SelectedItem != "")
            {
                dateOfBirth = dayComboBox.SelectedItem + "-" + monthComboBox.SelectedItem + "-" +
                                     yearComboBox.SelectedItem;
            }
            else
            {
                flag = 1;
                MessageBox.Show("Select date of birth first.");
            }

            string gender = "";
            if (maleRadioButton.Checked)
            {
                gender = "Male";
            }
            else if (femaleRadioButton.Checked)
            {
                gender = "Female";
            }
            else if(gender == "")
            {
                flag = 1;
                MessageBox.Show("Select gender first.");
            }

            string address = "";
            if (addressTextBox.Text != "")
            {
                address = addressTextBox.Text;
            }
            else
            {
                flag = 1;
                MessageBox.Show("Enter your address first.");
            }
            
            string contactNo = "";
            if (contractNoTextBox.Text != "")
            {
                contactNo = contractNoTextBox.Text;
            }
            else
            {
                flag = 1;
                MessageBox.Show("First enter contact number.");
            }

            string email = "";
            email = emailTextBox.Text;

            string nid = "";
            if (nidNoTextBox.Text != "")
            {
                nid = nidNoTextBox.Text;
            }
            else
            {
                flag = 1;
                MessageBox.Show("First enter NID number.");
            }
            
            string role = "";
            if (postRoleComboBox.SelectedText != "")
            {
                role = postRoleComboBox.SelectedText;
            }
            else
            {
                flag = 1;
                MessageBox.Show("First enter employee role.");
            }

            string joiningDate = "";
            if (joiningDateTextBox.Text != "")
            {
                joiningDate = joiningDateTextBox.Text;
            }
            else
            {
                flag = 1;
                MessageBox.Show("First enter the joining date of the employee.");
            }

            int salary = 0;
            if (salaryTextBox.Text != "")
            {
                salary = Convert.ToInt32(salaryTextBox.Text);
            }
            else
            {
                flag = 1;
                MessageBox.Show("First enter the salary of the employee.");
            }

            string userName = "";
            if (userNameTextBox.Text != "")
            {
                userName = userNameTextBox.Text;
                bool checkUserName = userGateway.CheckIfUserNameExists(userName);
                if (checkUserName == true)
                {
                    flag = 1;
                    MessageBox.Show("User name already exists.");
                }
            }
            
            string password = "";
            password = passwordTextBox.Text;
            
            string confirmPassword = "";
            confirmPassword = confirmPasswordTextBox.Text;
            
            //MessageBox.Show(fullName + "\n" + dateOfBirth);

            if (pictureBox.Image != null)
            {
                string folderPath = "E:\\Images";
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                path = Path.Combine(folderPath, Path.GetFileName(imageName));
                MessageBox.Show(path);
            }
            else
            {
                flag = 1;
                MessageBox.Show("Select image first.");
            }

            if (flag != 1)
            {
                if (password == confirmPassword)
                {
                    Employee employee = new Employee(employeeId, firstName, middleName, lastName, dateOfBirth, gender,
                        address, contactNo, path, email, nid, role, joiningDate, salary, userName, password);
                    string result = userGateway.CreateNewEmployee(employee);
                    if (result != "")
                    {
                        try
                        {
                            File.Copy(imageName, path);
                            MessageBox.Show("Image has been successfully copied.");
                        }
                        catch (Exception exception)
                        {
                            MessageBox.Show(exception.ToString());
                        }
                    }

                    MessageBox.Show(result);
                    ClearAll();
                }
                else
                {
                    MessageBox.Show("Password didn't matched. Confirm password.");
                }
            }
        }


        private void postRoleComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string userType = postRoleComboBox.SelectedItem.ToString();
            int noOfEmployee = userGateway.GetMaxEmployeeNoByUserType(userType);
            string employeeId = "";

            if (userType == "Admin")
            {
                noOfEmployee++;
                employeeId = "A-00" + noOfEmployee.ToString();
            }
            else if (userType == "Seller")
            {
                noOfEmployee++;
                employeeId = "B-00" + noOfEmployee.ToString();
            }

            employeeIdTextBox.Text = employeeId;
        }

        
        public void ClearAll()
        {
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            monthComboBox.SelectedIndex = 0;
            dayComboBox.SelectedIndex = 0;
            yearComboBox.SelectedIndex = 0;
            maleRadioButton.Checked = false;
            femaleRadioButton.Checked = false;
            addressTextBox.Text = "";
            contractNoTextBox.Text = "";
            emailTextBox.Text = "";
            nidNoTextBox.Text = "";
            postRoleComboBox.SelectedText = "";
            joiningDateTextBox.Text = "";
            salaryTextBox.Text = "";
            userNameTextBox.Text = "";
            passwordTextBox.Text = "";
            pictureBox.Image = null;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {

        }

        
    }
}
