﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;
using POSwithIMS.UI;

namespace POSwithIMS
{
    public partial class LogInForm : Form
    {
        
        EmployeeGateway userGateway = new EmployeeGateway();
        
        public LogInForm()
        {
            InitializeComponent();
        }

        private void logInButton_Click(object sender, EventArgs e)
        {
            string userName = userNameTextBox.Text;
            string password = passwordTextBox.Text;

            UserInfo loggedInUserInfo = userGateway.CheckIfUserExistsByUserNameAndPassword(userName, password);
            if (loggedInUserInfo != null)
            {
                if (loggedInUserInfo.UserType == "Admin")
                {
                    AdminMainHomeForm adminMainHomeForm = new AdminMainHomeForm(loggedInUserInfo);
                    adminMainHomeForm.Show();
                   // Dashboard dashboard=new Dashboard();
                    //dashboard.Show();
                    
                    this.Hide();
                }
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
