﻿namespace POSwithIMS
{
    partial class AddNewEmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewEmployeeForm));
            this.Panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.contractNoTextBox = new System.Windows.Forms.TextBox();
            this.contactNoLabel = new System.Windows.Forms.Label();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.employeeInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.salaryTextBox = new System.Windows.Forms.TextBox();
            this.joiningDateTextBox = new System.Windows.Forms.TextBox();
            this.salaryLabel = new System.Windows.Forms.Label();
            this.joiningDateLabel = new System.Windows.Forms.Label();
            this.postRoleComboBox = new System.Windows.Forms.ComboBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.confirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.confirmPasswordLabel = new System.Windows.Forms.Label();
            this.employeeIdTextBox = new System.Windows.Forms.TextBox();
            this.employeeIdLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.userNameTextBox = new System.Windows.Forms.TextBox();
            this.userNameLabel = new System.Windows.Forms.Label();
            this.postRoleLabel = new System.Windows.Forms.Label();
            this.femaleRadioButton = new System.Windows.Forms.RadioButton();
            this.maleRadioButton = new System.Windows.Forms.RadioButton();
            this.genderLabel = new System.Windows.Forms.Label();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.yearLabel = new System.Windows.Forms.Label();
            this.yearComboBox = new System.Windows.Forms.ComboBox();
            this.monthLabel = new System.Windows.Forms.Label();
            this.monthComboBox = new System.Windows.Forms.ComboBox();
            this.dayLabel = new System.Windows.Forms.Label();
            this.dayComboBox = new System.Windows.Forms.ComboBox();
            this.dateOfBirthLabel = new System.Windows.Forms.Label();
            this.browseFolderButton = new System.Windows.Forms.Button();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.nidNoTextBox = new System.Windows.Forms.TextBox();
            this.nidNoLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.employeeInformationGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel1.Controls.Add(this.pictureBox2);
            this.Panel1.Controls.Add(this.lblTitle);
            this.Panel1.Location = new System.Drawing.Point(12, 12);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(685, 55);
            this.Panel1.TabIndex = 8;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(28, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 42);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(84, 3);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(257, 42);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Add New Employee";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameLabel.Location = new System.Drawing.Point(398, 50);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(59, 12);
            this.lastNameLabel.TabIndex = 8;
            this.lastNameLabel.Text = "Last Name";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameLabel.Location = new System.Drawing.Point(111, 50);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(60, 12);
            this.firstNameLabel.TabIndex = 8;
            this.firstNameLabel.Text = "First Name";
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(39, 163);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(63, 17);
            this.addressLabel.TabIndex = 4;
            this.addressLabel.Text = "Address :";
            // 
            // contractNoTextBox
            // 
            this.contractNoTextBox.BackColor = System.Drawing.Color.White;
            this.contractNoTextBox.Location = new System.Drawing.Point(113, 204);
            this.contractNoTextBox.Name = "contractNoTextBox";
            this.contractNoTextBox.Size = new System.Drawing.Size(137, 25);
            this.contractNoTextBox.TabIndex = 7;
            // 
            // contactNoLabel
            // 
            this.contactNoLabel.AutoSize = true;
            this.contactNoLabel.Location = new System.Drawing.Point(20, 207);
            this.contactNoLabel.Name = "contactNoLabel";
            this.contactNoLabel.Size = new System.Drawing.Size(84, 17);
            this.contactNoLabel.TabIndex = 4;
            this.contactNoLabel.Text = "Contact No. :";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.BackColor = System.Drawing.Color.White;
            this.lastNameTextBox.Location = new System.Drawing.Point(400, 65);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(137, 25);
            this.lastNameTextBox.TabIndex = 1;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(52, 68);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(50, 17);
            this.nameLabel.TabIndex = 4;
            this.nameLabel.Text = "Name :";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.BackColor = System.Drawing.Color.White;
            this.firstNameTextBox.Location = new System.Drawing.Point(113, 65);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(127, 25);
            this.firstNameTextBox.TabIndex = 0;
            // 
            // employeeInformationGroupBox
            // 
            this.employeeInformationGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.employeeInformationGroupBox.Controls.Add(this.salaryTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.joiningDateTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.salaryLabel);
            this.employeeInformationGroupBox.Controls.Add(this.joiningDateLabel);
            this.employeeInformationGroupBox.Controls.Add(this.postRoleComboBox);
            this.employeeInformationGroupBox.Controls.Add(this.addressTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.confirmPasswordTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.confirmPasswordLabel);
            this.employeeInformationGroupBox.Controls.Add(this.employeeIdTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.employeeIdLabel);
            this.employeeInformationGroupBox.Controls.Add(this.clearButton);
            this.employeeInformationGroupBox.Controls.Add(this.passwordTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.passwordLabel);
            this.employeeInformationGroupBox.Controls.Add(this.userNameTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.userNameLabel);
            this.employeeInformationGroupBox.Controls.Add(this.postRoleLabel);
            this.employeeInformationGroupBox.Controls.Add(this.femaleRadioButton);
            this.employeeInformationGroupBox.Controls.Add(this.maleRadioButton);
            this.employeeInformationGroupBox.Controls.Add(this.genderLabel);
            this.employeeInformationGroupBox.Controls.Add(this.emailTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.emailLabel);
            this.employeeInformationGroupBox.Controls.Add(this.yearLabel);
            this.employeeInformationGroupBox.Controls.Add(this.yearComboBox);
            this.employeeInformationGroupBox.Controls.Add(this.monthLabel);
            this.employeeInformationGroupBox.Controls.Add(this.monthComboBox);
            this.employeeInformationGroupBox.Controls.Add(this.dayLabel);
            this.employeeInformationGroupBox.Controls.Add(this.dayComboBox);
            this.employeeInformationGroupBox.Controls.Add(this.dateOfBirthLabel);
            this.employeeInformationGroupBox.Controls.Add(this.browseFolderButton);
            this.employeeInformationGroupBox.Controls.Add(this.pictureBox);
            this.employeeInformationGroupBox.Controls.Add(this.nidNoTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.nidNoLabel);
            this.employeeInformationGroupBox.Controls.Add(this.middleNameLabel);
            this.employeeInformationGroupBox.Controls.Add(this.middleNameTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.cancelButton);
            this.employeeInformationGroupBox.Controls.Add(this.saveButton);
            this.employeeInformationGroupBox.Controls.Add(this.lastNameLabel);
            this.employeeInformationGroupBox.Controls.Add(this.firstNameLabel);
            this.employeeInformationGroupBox.Controls.Add(this.addressLabel);
            this.employeeInformationGroupBox.Controls.Add(this.contractNoTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.contactNoLabel);
            this.employeeInformationGroupBox.Controls.Add(this.lastNameTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.firstNameTextBox);
            this.employeeInformationGroupBox.Controls.Add(this.nameLabel);
            this.employeeInformationGroupBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeInformationGroupBox.Location = new System.Drawing.Point(12, 73);
            this.employeeInformationGroupBox.Name = "employeeInformationGroupBox";
            this.employeeInformationGroupBox.Size = new System.Drawing.Size(685, 483);
            this.employeeInformationGroupBox.TabIndex = 6;
            this.employeeInformationGroupBox.TabStop = false;
            this.employeeInformationGroupBox.Text = "Employee Information";
            // 
            // salaryTextBox
            // 
            this.salaryTextBox.Location = new System.Drawing.Point(398, 273);
            this.salaryTextBox.Name = "salaryTextBox";
            this.salaryTextBox.Size = new System.Drawing.Size(139, 25);
            this.salaryTextBox.TabIndex = 47;
            // 
            // joiningDateTextBox
            // 
            this.joiningDateTextBox.Location = new System.Drawing.Point(113, 274);
            this.joiningDateTextBox.Name = "joiningDateTextBox";
            this.joiningDateTextBox.Size = new System.Drawing.Size(137, 25);
            this.joiningDateTextBox.TabIndex = 46;
            // 
            // salaryLabel
            // 
            this.salaryLabel.AutoSize = true;
            this.salaryLabel.Location = new System.Drawing.Point(342, 276);
            this.salaryLabel.Name = "salaryLabel";
            this.salaryLabel.Size = new System.Drawing.Size(50, 17);
            this.salaryLabel.TabIndex = 45;
            this.salaryLabel.Text = "Salary :";
            // 
            // joiningDateLabel
            // 
            this.joiningDateLabel.AutoSize = true;
            this.joiningDateLabel.Location = new System.Drawing.Point(18, 277);
            this.joiningDateLabel.Name = "joiningDateLabel";
            this.joiningDateLabel.Size = new System.Drawing.Size(87, 17);
            this.joiningDateLabel.TabIndex = 44;
            this.joiningDateLabel.Text = "Joining Date :";
            // 
            // postRoleComboBox
            // 
            this.postRoleComboBox.FormattingEnabled = true;
            this.postRoleComboBox.Location = new System.Drawing.Point(398, 242);
            this.postRoleComboBox.Name = "postRoleComboBox";
            this.postRoleComboBox.Size = new System.Drawing.Size(139, 25);
            this.postRoleComboBox.TabIndex = 43;
            this.postRoleComboBox.SelectedIndexChanged += new System.EventHandler(this.postRoleComboBox_SelectedIndexChanged);
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(113, 160);
            this.addressTextBox.Multiline = true;
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(402, 34);
            this.addressTextBox.TabIndex = 42;
            // 
            // confirmPasswordTextBox
            // 
            this.confirmPasswordTextBox.BackColor = System.Drawing.Color.White;
            this.confirmPasswordTextBox.Location = new System.Drawing.Point(398, 345);
            this.confirmPasswordTextBox.Name = "confirmPasswordTextBox";
            this.confirmPasswordTextBox.Size = new System.Drawing.Size(139, 25);
            this.confirmPasswordTextBox.TabIndex = 41;
            // 
            // confirmPasswordLabel
            // 
            this.confirmPasswordLabel.AutoSize = true;
            this.confirmPasswordLabel.Location = new System.Drawing.Point(271, 348);
            this.confirmPasswordLabel.Name = "confirmPasswordLabel";
            this.confirmPasswordLabel.Size = new System.Drawing.Size(121, 17);
            this.confirmPasswordLabel.TabIndex = 40;
            this.confirmPasswordLabel.Text = "Confirm Password :";
            // 
            // employeeIdTextBox
            // 
            this.employeeIdTextBox.Location = new System.Drawing.Point(113, 309);
            this.employeeIdTextBox.Name = "employeeIdTextBox";
            this.employeeIdTextBox.ReadOnly = true;
            this.employeeIdTextBox.Size = new System.Drawing.Size(137, 25);
            this.employeeIdTextBox.TabIndex = 39;
            // 
            // employeeIdLabel
            // 
            this.employeeIdLabel.AutoSize = true;
            this.employeeIdLabel.Location = new System.Drawing.Point(18, 312);
            this.employeeIdLabel.Name = "employeeIdLabel";
            this.employeeIdLabel.Size = new System.Drawing.Size(88, 17);
            this.employeeIdLabel.TabIndex = 38;
            this.employeeIdLabel.Text = "Employee ID :";
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.clearButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clearButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clearButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Image = ((System.Drawing.Image)(resources.GetObject("clearButton.Image")));
            this.clearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.clearButton.Location = new System.Drawing.Point(230, 418);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(71, 24);
            this.clearButton.TabIndex = 37;
            this.clearButton.Text = "&Clear";
            this.clearButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.clearButton.UseVisualStyleBackColor = false;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.BackColor = System.Drawing.Color.White;
            this.passwordTextBox.Location = new System.Drawing.Point(113, 345);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(137, 25);
            this.passwordTextBox.TabIndex = 36;
            // 
            // passwordLabel
            // 
            this.passwordLabel.AutoSize = true;
            this.passwordLabel.Location = new System.Drawing.Point(33, 348);
            this.passwordLabel.Name = "passwordLabel";
            this.passwordLabel.Size = new System.Drawing.Size(71, 17);
            this.passwordLabel.TabIndex = 35;
            this.passwordLabel.Text = "Password :";
            // 
            // userNameTextBox
            // 
            this.userNameTextBox.BackColor = System.Drawing.Color.White;
            this.userNameTextBox.Location = new System.Drawing.Point(398, 309);
            this.userNameTextBox.Name = "userNameTextBox";
            this.userNameTextBox.Size = new System.Drawing.Size(139, 25);
            this.userNameTextBox.TabIndex = 34;
            // 
            // userNameLabel
            // 
            this.userNameLabel.AutoSize = true;
            this.userNameLabel.Location = new System.Drawing.Point(311, 312);
            this.userNameLabel.Name = "userNameLabel";
            this.userNameLabel.Size = new System.Drawing.Size(81, 17);
            this.userNameLabel.TabIndex = 33;
            this.userNameLabel.Text = "User Name :";
            // 
            // postRoleLabel
            // 
            this.postRoleLabel.AutoSize = true;
            this.postRoleLabel.Location = new System.Drawing.Point(321, 245);
            this.postRoleLabel.Name = "postRoleLabel";
            this.postRoleLabel.Size = new System.Drawing.Size(71, 17);
            this.postRoleLabel.TabIndex = 31;
            this.postRoleLabel.Text = "Post/Role :";
            // 
            // femaleRadioButton
            // 
            this.femaleRadioButton.AutoSize = true;
            this.femaleRadioButton.Location = new System.Drawing.Point(470, 116);
            this.femaleRadioButton.Name = "femaleRadioButton";
            this.femaleRadioButton.Size = new System.Drawing.Size(67, 21);
            this.femaleRadioButton.TabIndex = 28;
            this.femaleRadioButton.TabStop = true;
            this.femaleRadioButton.Text = "Female";
            this.femaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // maleRadioButton
            // 
            this.maleRadioButton.AutoSize = true;
            this.maleRadioButton.Location = new System.Drawing.Point(409, 115);
            this.maleRadioButton.Name = "maleRadioButton";
            this.maleRadioButton.Size = new System.Drawing.Size(55, 21);
            this.maleRadioButton.TabIndex = 27;
            this.maleRadioButton.TabStop = true;
            this.maleRadioButton.Text = "Male";
            this.maleRadioButton.UseVisualStyleBackColor = true;
            // 
            // genderLabel
            // 
            this.genderLabel.AutoSize = true;
            this.genderLabel.Location = new System.Drawing.Point(345, 117);
            this.genderLabel.Name = "genderLabel";
            this.genderLabel.Size = new System.Drawing.Size(58, 17);
            this.genderLabel.TabIndex = 26;
            this.genderLabel.Text = "Gender :";
            // 
            // emailTextBox
            // 
            this.emailTextBox.BackColor = System.Drawing.Color.White;
            this.emailTextBox.Location = new System.Drawing.Point(376, 204);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(161, 25);
            this.emailTextBox.TabIndex = 25;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(328, 207);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(46, 17);
            this.emailLabel.TabIndex = 24;
            this.emailLabel.Text = "Email :";
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearLabel.Location = new System.Drawing.Point(254, 100);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(27, 12);
            this.yearLabel.TabIndex = 23;
            this.yearLabel.Text = "Year";
            // 
            // yearComboBox
            // 
            this.yearComboBox.FormattingEnabled = true;
            this.yearComboBox.Location = new System.Drawing.Point(256, 117);
            this.yearComboBox.Name = "yearComboBox";
            this.yearComboBox.Size = new System.Drawing.Size(58, 25);
            this.yearComboBox.TabIndex = 22;
            // 
            // monthLabel
            // 
            this.monthLabel.AutoSize = true;
            this.monthLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monthLabel.Location = new System.Drawing.Point(111, 100);
            this.monthLabel.Name = "monthLabel";
            this.monthLabel.Size = new System.Drawing.Size(36, 12);
            this.monthLabel.TabIndex = 21;
            this.monthLabel.Text = "Month";
            // 
            // monthComboBox
            // 
            this.monthComboBox.FormattingEnabled = true;
            this.monthComboBox.Location = new System.Drawing.Point(113, 117);
            this.monthComboBox.Name = "monthComboBox";
            this.monthComboBox.Size = new System.Drawing.Size(75, 25);
            this.monthComboBox.TabIndex = 20;
            this.monthComboBox.SelectedIndexChanged += new System.EventHandler(this.monthComboBox_SelectedIndexChanged);
            // 
            // dayLabel
            // 
            this.dayLabel.AutoSize = true;
            this.dayLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dayLabel.Location = new System.Drawing.Point(192, 102);
            this.dayLabel.Name = "dayLabel";
            this.dayLabel.Size = new System.Drawing.Size(25, 12);
            this.dayLabel.TabIndex = 19;
            this.dayLabel.Text = "Day";
            // 
            // dayComboBox
            // 
            this.dayComboBox.FormattingEnabled = true;
            this.dayComboBox.Location = new System.Drawing.Point(194, 117);
            this.dayComboBox.Name = "dayComboBox";
            this.dayComboBox.Size = new System.Drawing.Size(56, 25);
            this.dayComboBox.TabIndex = 18;
            // 
            // dateOfBirthLabel
            // 
            this.dateOfBirthLabel.AutoSize = true;
            this.dateOfBirthLabel.Location = new System.Drawing.Point(17, 118);
            this.dateOfBirthLabel.Name = "dateOfBirthLabel";
            this.dateOfBirthLabel.Size = new System.Drawing.Size(88, 17);
            this.dateOfBirthLabel.TabIndex = 17;
            this.dateOfBirthLabel.Text = "Date of Birth :";
            // 
            // browseFolderButton
            // 
            this.browseFolderButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.browseFolderButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.browseFolderButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.browseFolderButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.browseFolderButton.Image = ((System.Drawing.Image)(resources.GetObject("browseFolderButton.Image")));
            this.browseFolderButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.browseFolderButton.Location = new System.Drawing.Point(566, 213);
            this.browseFolderButton.Name = "browseFolderButton";
            this.browseFolderButton.Size = new System.Drawing.Size(80, 24);
            this.browseFolderButton.TabIndex = 16;
            this.browseFolderButton.Text = "&Browse";
            this.browseFolderButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.browseFolderButton.UseVisualStyleBackColor = false;
            this.browseFolderButton.Click += new System.EventHandler(this.browseFolderButton_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox.Location = new System.Drawing.Point(556, 65);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(107, 142);
            this.pictureBox.TabIndex = 15;
            this.pictureBox.TabStop = false;
            this.pictureBox.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // nidNoTextBox
            // 
            this.nidNoTextBox.BackColor = System.Drawing.Color.White;
            this.nidNoTextBox.Location = new System.Drawing.Point(113, 242);
            this.nidNoTextBox.Name = "nidNoTextBox";
            this.nidNoTextBox.Size = new System.Drawing.Size(137, 25);
            this.nidNoTextBox.TabIndex = 14;
            // 
            // nidNoLabel
            // 
            this.nidNoLabel.AutoSize = true;
            this.nidNoLabel.Location = new System.Drawing.Point(42, 245);
            this.nidNoLabel.Name = "nidNoLabel";
            this.nidNoLabel.Size = new System.Drawing.Size(62, 17);
            this.nidNoLabel.TabIndex = 13;
            this.nidNoLabel.Text = "NID No. :";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middleNameLabel.Location = new System.Drawing.Point(254, 50);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(70, 12);
            this.middleNameLabel.TabIndex = 12;
            this.middleNameLabel.Text = "Middle Name";
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.BackColor = System.Drawing.Color.White;
            this.middleNameTextBox.Location = new System.Drawing.Point(256, 65);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(127, 25);
            this.middleNameTextBox.TabIndex = 11;
            // 
            // cancelButton
            // 
            this.cancelButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancelButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Image = ((System.Drawing.Image)(resources.GetObject("cancelButton.Image")));
            this.cancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancelButton.Location = new System.Drawing.Point(413, 418);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 24);
            this.cancelButton.TabIndex = 10;
            this.cancelButton.Text = "&Cancel";
            this.cancelButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancelButton.UseVisualStyleBackColor = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.saveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.saveButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.saveButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Image = ((System.Drawing.Image)(resources.GetObject("saveButton.Image")));
            this.saveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveButton.Location = new System.Drawing.Point(324, 418);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(68, 24);
            this.saveButton.TabIndex = 9;
            this.saveButton.Text = "&Save ";
            this.saveButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // AddNewEmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(709, 568);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.employeeInformationGroupBox);
            this.Name = "AddNewEmployeeForm";
            this.Text = "Add New Employee";
            this.Load += new System.EventHandler(this.AddNewStaffForm_Load);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.employeeInformationGroupBox.ResumeLayout(false);
            this.employeeInformationGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label lblTitle;
        internal System.Windows.Forms.Label lastNameLabel;
        internal System.Windows.Forms.Label firstNameLabel;
        internal System.Windows.Forms.Label addressLabel;
        internal System.Windows.Forms.TextBox contractNoTextBox;
        internal System.Windows.Forms.Label contactNoLabel;
        internal System.Windows.Forms.TextBox lastNameTextBox;
        internal System.Windows.Forms.Label nameLabel;
        internal System.Windows.Forms.TextBox firstNameTextBox;
        internal System.Windows.Forms.GroupBox employeeInformationGroupBox;
        internal System.Windows.Forms.Button cancelButton;
        internal System.Windows.Forms.Button saveButton;
        internal System.Windows.Forms.Label middleNameLabel;
        internal System.Windows.Forms.TextBox middleNameTextBox;
        internal System.Windows.Forms.TextBox nidNoTextBox;
        internal System.Windows.Forms.Label nidNoLabel;
        private System.Windows.Forms.PictureBox pictureBox;
        internal System.Windows.Forms.Button browseFolderButton;
        internal System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.ComboBox yearComboBox;
        internal System.Windows.Forms.Label monthLabel;
        private System.Windows.Forms.ComboBox monthComboBox;
        internal System.Windows.Forms.Label dayLabel;
        private System.Windows.Forms.ComboBox dayComboBox;
        internal System.Windows.Forms.Label dateOfBirthLabel;
        internal System.Windows.Forms.TextBox emailTextBox;
        internal System.Windows.Forms.Label emailLabel;
        internal System.Windows.Forms.Label genderLabel;
        private System.Windows.Forms.RadioButton femaleRadioButton;
        private System.Windows.Forms.RadioButton maleRadioButton;
        internal System.Windows.Forms.Label postRoleLabel;
        internal System.Windows.Forms.TextBox passwordTextBox;
        internal System.Windows.Forms.Label passwordLabel;
        internal System.Windows.Forms.TextBox userNameTextBox;
        internal System.Windows.Forms.Label userNameLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label employeeIdLabel;
        private System.Windows.Forms.TextBox employeeIdTextBox;
        internal System.Windows.Forms.TextBox confirmPasswordTextBox;
        internal System.Windows.Forms.Label confirmPasswordLabel;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox salaryTextBox;
        private System.Windows.Forms.TextBox joiningDateTextBox;
        private System.Windows.Forms.Label salaryLabel;
        private System.Windows.Forms.Label joiningDateLabel;
        private System.Windows.Forms.ComboBox postRoleComboBox;
    }
}