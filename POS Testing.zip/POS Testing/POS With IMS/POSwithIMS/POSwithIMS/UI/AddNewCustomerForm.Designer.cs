﻿namespace POSwithIMS.UI
{
    partial class AddNewCustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewCustomerForm));
            this.Panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.supplierInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.contactNo2TextBox = new System.Windows.Forms.TextBox();
            this.contactNo2Label = new System.Windows.Forms.Label();
            this.balanceTextBox = new System.Windows.Forms.TextBox();
            this.balanceLabel = new System.Windows.Forms.Label();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.customerIdTextBox = new System.Windows.Forms.TextBox();
            this.customerIdLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.cancelButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.addressLabel = new System.Windows.Forms.Label();
            this.contactNo1TextBox = new System.Windows.Forms.TextBox();
            this.contactNo11Label = new System.Windows.Forms.Label();
            this.customerNameTextBox = new System.Windows.Forms.TextBox();
            this.customerNameLabel = new System.Windows.Forms.Label();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.supplierInformationGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel1.Controls.Add(this.pictureBox2);
            this.Panel1.Controls.Add(this.lblTitle);
            this.Panel1.Location = new System.Drawing.Point(12, 12);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(615, 55);
            this.Panel1.TabIndex = 12;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(28, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 42);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(71, 3);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(257, 42);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Add New Customer";
            // 
            // supplierInformationGroupBox
            // 
            this.supplierInformationGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.supplierInformationGroupBox.Controls.Add(this.contactNo2TextBox);
            this.supplierInformationGroupBox.Controls.Add(this.contactNo2Label);
            this.supplierInformationGroupBox.Controls.Add(this.balanceTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.balanceLabel);
            this.supplierInformationGroupBox.Controls.Add(this.addressTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.customerIdTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.customerIdLabel);
            this.supplierInformationGroupBox.Controls.Add(this.clearButton);
            this.supplierInformationGroupBox.Controls.Add(this.emailTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.emailLabel);
            this.supplierInformationGroupBox.Controls.Add(this.cancelButton);
            this.supplierInformationGroupBox.Controls.Add(this.saveButton);
            this.supplierInformationGroupBox.Controls.Add(this.addressLabel);
            this.supplierInformationGroupBox.Controls.Add(this.contactNo1TextBox);
            this.supplierInformationGroupBox.Controls.Add(this.contactNo11Label);
            this.supplierInformationGroupBox.Controls.Add(this.customerNameTextBox);
            this.supplierInformationGroupBox.Controls.Add(this.customerNameLabel);
            this.supplierInformationGroupBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supplierInformationGroupBox.Location = new System.Drawing.Point(12, 73);
            this.supplierInformationGroupBox.Name = "supplierInformationGroupBox";
            this.supplierInformationGroupBox.Size = new System.Drawing.Size(615, 347);
            this.supplierInformationGroupBox.TabIndex = 11;
            this.supplierInformationGroupBox.TabStop = false;
            this.supplierInformationGroupBox.Text = "Customer Information";
            // 
            // contactNo2TextBox
            // 
            this.contactNo2TextBox.BackColor = System.Drawing.Color.White;
            this.contactNo2TextBox.Location = new System.Drawing.Point(436, 140);
            this.contactNo2TextBox.Name = "contactNo2TextBox";
            this.contactNo2TextBox.Size = new System.Drawing.Size(141, 25);
            this.contactNo2TextBox.TabIndex = 49;
            // 
            // contactNo2Label
            // 
            this.contactNo2Label.AutoSize = true;
            this.contactNo2Label.Location = new System.Drawing.Point(335, 140);
            this.contactNo2Label.Name = "contactNo2Label";
            this.contactNo2Label.Size = new System.Drawing.Size(95, 17);
            this.contactNo2Label.TabIndex = 48;
            this.contactNo2Label.Text = "Contact No. 2 :";
            // 
            // balanceTextBox
            // 
            this.balanceTextBox.Location = new System.Drawing.Point(158, 214);
            this.balanceTextBox.Name = "balanceTextBox";
            this.balanceTextBox.Size = new System.Drawing.Size(141, 25);
            this.balanceTextBox.TabIndex = 47;
            // 
            // balanceLabel
            // 
            this.balanceLabel.AutoSize = true;
            this.balanceLabel.Location = new System.Drawing.Point(93, 217);
            this.balanceLabel.Name = "balanceLabel";
            this.balanceLabel.Size = new System.Drawing.Size(59, 17);
            this.balanceLabel.TabIndex = 45;
            this.balanceLabel.Text = "Balance :";
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(158, 96);
            this.addressTextBox.Multiline = true;
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(419, 25);
            this.addressTextBox.TabIndex = 42;
            // 
            // customerIdTextBox
            // 
            this.customerIdTextBox.Location = new System.Drawing.Point(158, 177);
            this.customerIdTextBox.Name = "customerIdTextBox";
            this.customerIdTextBox.ReadOnly = true;
            this.customerIdTextBox.Size = new System.Drawing.Size(141, 25);
            this.customerIdTextBox.TabIndex = 39;
            this.customerIdTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.customerIdTextBox_MouseClick);
            // 
            // customerIdLabel
            // 
            this.customerIdLabel.AutoSize = true;
            this.customerIdLabel.Location = new System.Drawing.Point(65, 180);
            this.customerIdLabel.Name = "customerIdLabel";
            this.customerIdLabel.Size = new System.Drawing.Size(87, 17);
            this.customerIdLabel.TabIndex = 38;
            this.customerIdLabel.Text = "Customer ID :";
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.clearButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clearButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clearButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Image = ((System.Drawing.Image)(resources.GetObject("clearButton.Image")));
            this.clearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.clearButton.Location = new System.Drawing.Point(189, 274);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(71, 24);
            this.clearButton.TabIndex = 37;
            this.clearButton.Text = "&Clear";
            this.clearButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.clearButton.UseVisualStyleBackColor = false;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // emailTextBox
            // 
            this.emailTextBox.BackColor = System.Drawing.Color.White;
            this.emailTextBox.Location = new System.Drawing.Point(427, 180);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(150, 25);
            this.emailTextBox.TabIndex = 25;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(375, 183);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(46, 17);
            this.emailLabel.TabIndex = 24;
            this.emailLabel.Text = "Email :";
            // 
            // cancelButton
            // 
            this.cancelButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancelButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Image = ((System.Drawing.Image)(resources.GetObject("cancelButton.Image")));
            this.cancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancelButton.Location = new System.Drawing.Point(377, 274);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 24);
            this.cancelButton.TabIndex = 10;
            this.cancelButton.Text = "&Cancel";
            this.cancelButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancelButton.UseVisualStyleBackColor = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.saveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.saveButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.saveButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Image = ((System.Drawing.Image)(resources.GetObject("saveButton.Image")));
            this.saveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveButton.Location = new System.Drawing.Point(286, 274);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(68, 24);
            this.saveButton.TabIndex = 9;
            this.saveButton.Text = "&Save ";
            this.saveButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(90, 99);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(63, 17);
            this.addressLabel.TabIndex = 4;
            this.addressLabel.Text = "Address :";
            // 
            // contactNo1TextBox
            // 
            this.contactNo1TextBox.BackColor = System.Drawing.Color.White;
            this.contactNo1TextBox.Location = new System.Drawing.Point(158, 137);
            this.contactNo1TextBox.Name = "contactNo1TextBox";
            this.contactNo1TextBox.Size = new System.Drawing.Size(141, 25);
            this.contactNo1TextBox.TabIndex = 7;
            // 
            // contactNo11Label
            // 
            this.contactNo11Label.AutoSize = true;
            this.contactNo11Label.Location = new System.Drawing.Point(57, 140);
            this.contactNo11Label.Name = "contactNo11Label";
            this.contactNo11Label.Size = new System.Drawing.Size(95, 17);
            this.contactNo11Label.TabIndex = 4;
            this.contactNo11Label.Text = "Contact No. 1 :";
            // 
            // customerNameTextBox
            // 
            this.customerNameTextBox.BackColor = System.Drawing.Color.White;
            this.customerNameTextBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerNameTextBox.Location = new System.Drawing.Point(158, 56);
            this.customerNameTextBox.Name = "customerNameTextBox";
            this.customerNameTextBox.Size = new System.Drawing.Size(419, 25);
            this.customerNameTextBox.TabIndex = 0;
            // 
            // customerNameLabel
            // 
            this.customerNameLabel.AutoSize = true;
            this.customerNameLabel.Location = new System.Drawing.Point(43, 59);
            this.customerNameLabel.Name = "customerNameLabel";
            this.customerNameLabel.Size = new System.Drawing.Size(110, 17);
            this.customerNameLabel.TabIndex = 4;
            this.customerNameLabel.Text = "Customer Name :";
            // 
            // AddNewCustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(639, 432);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.supplierInformationGroupBox);
            this.Name = "AddNewCustomerForm";
            this.Text = "Add New Customer";
            this.Load += new System.EventHandler(this.AddNewCustomerForm_Load);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.supplierInformationGroupBox.ResumeLayout(false);
            this.supplierInformationGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        internal System.Windows.Forms.Label lblTitle;
        internal System.Windows.Forms.GroupBox supplierInformationGroupBox;
        internal System.Windows.Forms.TextBox contactNo2TextBox;
        internal System.Windows.Forms.Label contactNo2Label;
        private System.Windows.Forms.TextBox balanceTextBox;
        private System.Windows.Forms.Label balanceLabel;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox customerIdTextBox;
        private System.Windows.Forms.Label customerIdLabel;
        private System.Windows.Forms.Button clearButton;
        internal System.Windows.Forms.TextBox emailTextBox;
        internal System.Windows.Forms.Label emailLabel;
        internal System.Windows.Forms.Button cancelButton;
        internal System.Windows.Forms.Button saveButton;
        internal System.Windows.Forms.Label addressLabel;
        internal System.Windows.Forms.TextBox contactNo1TextBox;
        internal System.Windows.Forms.Label contactNo11Label;
        internal System.Windows.Forms.TextBox customerNameTextBox;
        internal System.Windows.Forms.Label customerNameLabel;
    }
}