﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS
{
    public partial class DeleteProductForm : Form
    {
        public ProductsGateway productsGateway = new ProductsGateway();

        public UserInfo loggedInUserInfo = null;

        public Product product = null;

        public DeleteProductForm(Product aProduct, UserInfo userInfo)
        {
            InitializeComponent();

            product = aProduct;
            loggedInUserInfo = userInfo;
        }

        private void DeleteProductForm_Load(object sender, EventArgs e)
        {
            if (product != null)
            {
                productCodeTextBox.Text = product.ProductCode;
                productNameTextBox.Text = product.ProductName;
                categoryTextBox.Text = product.Category;
                subcategoryTextBox.Text = product.Subcategory;
                descriptionTextBox.Text = product.Description;
                supplierTextBox.Text = product.Supplier;
                retailPriceTextBox.Text = product.RetailPrice.ToString();
                wholesalePriceTextBox.Text = product.WholeSalePrice.ToString();
                stocksInHandTextBox.Text = product.StocksInHand.ToString();
            }
        }

        private void loadInfoButton_Click(object sender, EventArgs e)
        {
            string productCode = productCodeTextBox.Text;

            if (productCode == "")
            {
                MessageBox.Show("Enter product code first.");
            }
            else
            {
                Product product = productsGateway.GetProductByProductCode(productCode);
                productNameTextBox.Text = product.ProductName;
                categoryTextBox.Text = product.Category;
                subcategoryTextBox.Text = product.Subcategory;
                descriptionTextBox.Text = product.Description;
                supplierTextBox.Text = product.Supplier;
                retailPriceTextBox.Text = product.RetailPrice.ToString();
                wholesalePriceTextBox.Text = product.WholeSalePrice.ToString();
                stocksInHandTextBox.Text = product.StocksInHand.ToString();
            }
        }

        
        public void ClearAll()
        {
            productCodeTextBox.Text = null;
            productNameTextBox.Text = null;
            categoryTextBox.Text = null;
            subcategoryTextBox.Text = null;
            descriptionTextBox.Text = null;
            supplierTextBox.Text = null;
            barcodeTextBox.Text = null;
            retailPriceTextBox.Text = null;
            wholesalePriceTextBox.Text = null;
            stocksInHandTextBox.Text = null;
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void updateExistingProductSaveButton_Click(object sender, EventArgs e)
        {
            string productCode = productCodeTextBox.Text;
            string result = productsGateway.DeleteExistingProduct(productCode);
            MessageBox.Show(result);

            ClearAll();
        }

    }
}
