﻿namespace POSwithIMS.UI
{
    partial class CustomersListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomersListForm));
            this.customersListView = new System.Windows.Forms.ListView();
            this.customerIdColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.nameColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.addressColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contactNo1Column = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contactNo2Column = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.emailColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dueAmmountColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.searchToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.searchToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.reloadToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.ToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // customersListView
            // 
            this.customersListView.BackColor = System.Drawing.Color.White;
            this.customersListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.customerIdColumn,
            this.nameColumn,
            this.addressColumn,
            this.contactNo1Column,
            this.contactNo2Column,
            this.emailColumn,
            this.dueAmmountColumn});
            this.customersListView.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customersListView.FullRowSelect = true;
            this.customersListView.GridLines = true;
            this.customersListView.Location = new System.Drawing.Point(0, 40);
            this.customersListView.Name = "customersListView";
            this.customersListView.Size = new System.Drawing.Size(831, 500);
            this.customersListView.TabIndex = 34;
            this.customersListView.UseCompatibleStateImageBehavior = false;
            this.customersListView.View = System.Windows.Forms.View.Details;
            // 
            // customerIdColumn
            // 
            this.customerIdColumn.Text = "Customer ID";
            this.customerIdColumn.Width = 85;
            // 
            // nameColumn
            // 
            this.nameColumn.Text = "Name ";
            this.nameColumn.Width = 150;
            // 
            // addressColumn
            // 
            this.addressColumn.Text = "Address";
            this.addressColumn.Width = 190;
            // 
            // contactNo1Column
            // 
            this.contactNo1Column.Text = "Contact No. 1";
            this.contactNo1Column.Width = 105;
            // 
            // contactNo2Column
            // 
            this.contactNo2Column.DisplayIndex = 5;
            this.contactNo2Column.Text = "Contact No. 2";
            this.contactNo2Column.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.contactNo2Column.Width = 105;
            // 
            // emailColumn
            // 
            this.emailColumn.DisplayIndex = 4;
            this.emailColumn.Text = "Email";
            this.emailColumn.Width = 100;
            // 
            // dueAmmountColumn
            // 
            this.dueAmmountColumn.Text = "DueAmmount Ammount";
            this.dueAmmountColumn.Width = 90;
            // 
            // ToolStrip1
            // 
            this.ToolStrip1.AutoSize = false;
            this.ToolStrip1.BackColor = System.Drawing.Color.SteelBlue;
            this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripLabel1,
            this.searchToolStripLabel,
            this.searchToolStripTextBox,
            this.reloadToolStripButton});
            this.ToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.ToolStrip1.Name = "ToolStrip1";
            this.ToolStrip1.Size = new System.Drawing.Size(835, 40);
            this.ToolStrip1.TabIndex = 33;
            this.ToolStrip1.Text = "ToolStrip1";
            // 
            // ToolStripLabel1
            // 
            this.ToolStripLabel1.Name = "ToolStripLabel1";
            this.ToolStripLabel1.Size = new System.Drawing.Size(16, 37);
            this.ToolStripLabel1.Text = "   ";
            // 
            // searchToolStripLabel
            // 
            this.searchToolStripLabel.Name = "searchToolStripLabel";
            this.searchToolStripLabel.Size = new System.Drawing.Size(42, 37);
            this.searchToolStripLabel.Text = "&Search";
            // 
            // searchToolStripTextBox
            // 
            this.searchToolStripTextBox.Name = "searchToolStripTextBox";
            this.searchToolStripTextBox.Size = new System.Drawing.Size(100, 40);
            this.searchToolStripTextBox.TextChanged += new System.EventHandler(this.searchToolStripTextBox_TextChanged);
            // 
            // reloadToolStripButton
            // 
            this.reloadToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("reloadToolStripButton.Image")));
            this.reloadToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.reloadToolStripButton.Name = "reloadToolStripButton";
            this.reloadToolStripButton.Size = new System.Drawing.Size(63, 37);
            this.reloadToolStripButton.Text = "&Reload";
            this.reloadToolStripButton.Click += new System.EventHandler(this.reloadToolStripButton_Click);
            // 
            // CustomersListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(835, 539);
            this.Controls.Add(this.customersListView);
            this.Controls.Add(this.ToolStrip1);
            this.Name = "CustomersListForm";
            this.Text = "Customer\'s List";
            this.Load += new System.EventHandler(this.CustomerListForm_Load);
            this.ToolStrip1.ResumeLayout(false);
            this.ToolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.ListView customersListView;
        internal System.Windows.Forms.ColumnHeader customerIdColumn;
        internal System.Windows.Forms.ColumnHeader nameColumn;
        internal System.Windows.Forms.ColumnHeader addressColumn;
        internal System.Windows.Forms.ColumnHeader contactNo1Column;
        private System.Windows.Forms.ColumnHeader contactNo2Column;
        private System.Windows.Forms.ColumnHeader emailColumn;
        internal System.Windows.Forms.ColumnHeader dueAmmountColumn;
        internal System.Windows.Forms.ToolStrip ToolStrip1;
        internal System.Windows.Forms.ToolStripLabel ToolStripLabel1;
        private System.Windows.Forms.ToolStripLabel searchToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox searchToolStripTextBox;
        private System.Windows.Forms.ToolStripButton reloadToolStripButton;
    }
}