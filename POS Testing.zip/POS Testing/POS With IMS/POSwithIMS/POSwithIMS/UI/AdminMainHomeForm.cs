﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;
using POSwithIMS.UI;

namespace POSwithIMS
{
    public partial class AdminMainHomeForm : Form
    {
        public UserInfo loggedInUserInfo = null;
        
        public AdminMainHomeForm(UserInfo userInfo)
        {
            InitializeComponent();

            loggedInUserInfo = userInfo;
        }

        private void MainHomeForm_Load(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.UtcNow.Date;
            timeLabel.Text = DateTime.Now.ToString("h:mm:ss tt");
            dateLabel.Text = dateTime.ToString("dd/MM/yyyy");
            loggedInUserLabel.Text = loggedInUserInfo.UserName;
        }

        private void AddNewTab(Form form)
        {
            TabPage tab = new TabPage(form.Text);

            form.TopLevel = false;

            form.Parent = tab;

            form.Visible = true;

            tabControl.TabPages.Add(tab);

            //form.Location = new Point((tab.Width - form.Width)/2, (tab.Height - form.Height)/2);

            form.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

            tabControl.SelectedTab = tab;

            tabControl.Padding = new Point(12, 4);
        }

        private void tabControl_DrawItem(object sender, DrawItemEventArgs e)
        {
            //This code will render a "x" mark at the end of the Tab caption. 
            e.Graphics.DrawString("x", e.Font, Brushes.Black, e.Bounds.Right - 10, e.Bounds.Top + 4);
            e.Graphics.DrawString(this.tabControl.TabPages[e.Index].Text, e.Font, Brushes.Black, e.Bounds.Left + 5, e.Bounds.Top + 4);
            e.DrawFocusRectangle();
        }

        private void tabControl_MouseDown(object sender, MouseEventArgs e)
        {
            //Looping through the controls.
            for (int i = 0; i < this.tabControl.TabPages.Count; i++)
            {
                Rectangle r = tabControl.GetTabRect(i);
                //Getting the position of the "x" mark.
                Rectangle closeButton = new Rectangle(r.Right - 13, r.Top + 6, 11, 9);
                if (closeButton.Contains(e.Location))
                {
                    if (MessageBox.Show("Would you like to Close this Tab?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        this.tabControl.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
        }

        public void SetScrollBar()
        {
            this.AutoScroll = true;
            this.AutoScrollMargin = new System.Drawing.Size(15, 15);
            this.AutoScrollMinSize = new System.Drawing.Size(1000, 1000);
        }

        private void staffToolStripButton_Click(object sender, EventArgs e)
        {
            EmployeeListForm staffsList = new EmployeeListForm(loggedInUserInfo);
            AddNewTab(staffsList);

            SetScrollBar();
        }

        private void categoryToolStripButton_Click(object sender, EventArgs e)
        {
            CategoryForm categoryForm = new CategoryForm(loggedInUserInfo);
            AddNewTab(categoryForm);

            SetScrollBar();
        }

        private void productToolStripButton_Click(object sender, EventArgs e)
        {
            ProductsListForm productList = new ProductsListForm(loggedInUserInfo);
            AddNewTab(productList);

            SetScrollBar();
        }

        
        private void stocksInToolStripButton_Click(object sender, EventArgs e)
        {
            StocksUpdateForm stocksUpdate = new StocksUpdateForm(loggedInUserInfo);
            AddNewTab(stocksUpdate);
            
            SetScrollBar();
        }

        private void productListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductsListForm productList = new ProductsListForm(loggedInUserInfo);
            AddNewTab(productList);

            SetScrollBar();
        }

        
        private void posToolStripButton_Click(object sender, EventArgs e)
        {
            POSForm posForm = new POSForm(loggedInUserInfo);
            AddNewTab(posForm);

            SetScrollBar();
        }

        
        private void addNewProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewProductForm addNewProduct = new AddNewProductForm(loggedInUserInfo);

            AddNewTab(addNewProduct);

            SetScrollBar();
        }

        private void usersPasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditPasswordForm editPassword = new EditPasswordForm(loggedInUserInfo);

            AddNewTab(editPassword);

            SetScrollBar();
        }

        private void stocksUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StocksUpdateForm stocksUpdate = new StocksUpdateForm(loggedInUserInfo);
            AddNewTab(stocksUpdate);

            SetScrollBar();
        }

        
        private void addNewSuppliersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewSupplierForm addNewSupplier = new AddNewSupplierForm(loggedInUserInfo);
            AddNewTab(addNewSupplier);

            SetScrollBar();
        }


        private void addNewCustomerToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            AddNewCustomerForm addNewCustomer = new AddNewCustomerForm(loggedInUserInfo);
            AddNewTab(addNewCustomer);

            SetScrollBar();
        }


        private void addNewEmployeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewEmployeeForm addNewEmployee = new AddNewEmployeeForm(loggedInUserInfo);
            AddNewTab(addNewEmployee);

            SetScrollBar();
        }


        private void employeeListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EmployeeListForm employeeList = new EmployeeListForm(loggedInUserInfo);
            AddNewTab(employeeList);

            SetScrollBar();
        }


        
        private void backUpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var folderDialog = new FolderBrowserDialog())
            {
                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    DateTime dateTime = DateTime.UtcNow.Date;
                    string date = dateTime.ToString("d");
                    string path = folderDialog.SelectedPath;
                    DBGateWay dbGateWay = new DBGateWay();
                    string result = dbGateWay.BackUpDB(path, date);
                    MessageBox.Show(result);
                }
            }
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
    }
}
