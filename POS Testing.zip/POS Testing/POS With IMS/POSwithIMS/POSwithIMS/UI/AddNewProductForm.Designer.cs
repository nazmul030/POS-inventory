﻿namespace POSwithIMS
{
    partial class AddNewProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewProductForm));
            this.addProductLabel = new System.Windows.Forms.Label();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.refreshButton = new System.Windows.Forms.Button();
            this.addProductCancelButton = new System.Windows.Forms.Button();
            this.addProductSaveButton = new System.Windows.Forms.Button();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.retailPriceTextBox = new System.Windows.Forms.TextBox();
            this.retailPriceLabel = new System.Windows.Forms.Label();
            this.stocksInHandTextBox = new System.Windows.Forms.TextBox();
            this.stocksInHandLabel = new System.Windows.Forms.Label();
            this.categoryLabel = new System.Windows.Forms.Label();
            this.barcodeTextBox = new System.Windows.Forms.TextBox();
            this.barcodeLabel = new System.Windows.Forms.Label();
            this.productNameTextBox = new System.Windows.Forms.TextBox();
            this.productNameLabel = new System.Windows.Forms.Label();
            this.productInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.suppliersComboBox = new System.Windows.Forms.ComboBox();
            this.supplierLabel = new System.Windows.Forms.Label();
            this.costingPriceTextBox = new System.Windows.Forms.TextBox();
            this.costingPriceLabel = new System.Windows.Forms.Label();
            this.wholesalePriceTextBox = new System.Windows.Forms.TextBox();
            this.wholesalePriceLabel = new System.Windows.Forms.Label();
            this.subcategoryComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.barcodeGeneratorButton = new System.Windows.Forms.Button();
            this.productCodeTextBox = new System.Windows.Forms.TextBox();
            this.productCodeLabel = new System.Windows.Forms.Label();
            this.categoryComboBox = new System.Windows.Forms.ComboBox();
            this.GroupBox2.SuspendLayout();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.productInformationGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // addProductLabel
            // 
            this.addProductLabel.AutoSize = true;
            this.addProductLabel.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProductLabel.ForeColor = System.Drawing.Color.White;
            this.addProductLabel.Location = new System.Drawing.Point(71, 8);
            this.addProductLabel.Name = "addProductLabel";
            this.addProductLabel.Size = new System.Drawing.Size(238, 42);
            this.addProductLabel.TabIndex = 1;
            this.addProductLabel.Text = "Add New Product";
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.refreshButton);
            this.GroupBox2.Controls.Add(this.addProductCancelButton);
            this.GroupBox2.Controls.Add(this.addProductSaveButton);
            this.GroupBox2.Location = new System.Drawing.Point(19, 272);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(579, 90);
            this.GroupBox2.TabIndex = 8;
            this.GroupBox2.TabStop = false;
            // 
            // refreshButton
            // 
            this.refreshButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.refreshButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.refreshButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.refreshButton.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshButton.Image = ((System.Drawing.Image)(resources.GetObject("refreshButton.Image")));
            this.refreshButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.refreshButton.Location = new System.Drawing.Point(197, 33);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(90, 33);
            this.refreshButton.TabIndex = 2;
            this.refreshButton.Text = "&Refresh ";
            this.refreshButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.refreshButton.UseVisualStyleBackColor = false;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // addProductCancelButton
            // 
            this.addProductCancelButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.addProductCancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addProductCancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addProductCancelButton.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProductCancelButton.Image = ((System.Drawing.Image)(resources.GetObject("addProductCancelButton.Image")));
            this.addProductCancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addProductCancelButton.Location = new System.Drawing.Point(374, 33);
            this.addProductCancelButton.Name = "addProductCancelButton";
            this.addProductCancelButton.Size = new System.Drawing.Size(75, 33);
            this.addProductCancelButton.TabIndex = 1;
            this.addProductCancelButton.Text = "&Cancel";
            this.addProductCancelButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProductCancelButton.UseVisualStyleBackColor = false;
            this.addProductCancelButton.Click += new System.EventHandler(this.addProductCancelButton_Click);
            // 
            // addProductSaveButton
            // 
            this.addProductSaveButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.addProductSaveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addProductSaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addProductSaveButton.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProductSaveButton.Image = ((System.Drawing.Image)(resources.GetObject("addProductSaveButton.Image")));
            this.addProductSaveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addProductSaveButton.Location = new System.Drawing.Point(293, 33);
            this.addProductSaveButton.Name = "addProductSaveButton";
            this.addProductSaveButton.Size = new System.Drawing.Size(75, 33);
            this.addProductSaveButton.TabIndex = 0;
            this.addProductSaveButton.Text = "&Save ";
            this.addProductSaveButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProductSaveButton.UseVisualStyleBackColor = false;
            this.addProductSaveButton.Click += new System.EventHandler(this.addProductSaveButton_Click);
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel1.Controls.Add(this.pictureBox2);
            this.Panel1.Controls.Add(this.addProductLabel);
            this.Panel1.Location = new System.Drawing.Point(14, 3);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(620, 57);
            this.Panel1.TabIndex = 5;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(29, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 42);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.BackColor = System.Drawing.Color.White;
            this.descriptionTextBox.Location = new System.Drawing.Point(142, 101);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(456, 25);
            this.descriptionTextBox.TabIndex = 1;
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionLabel.Location = new System.Drawing.Point(55, 104);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(81, 17);
            this.descriptionLabel.TabIndex = 4;
            this.descriptionLabel.Text = "Description :";
            // 
            // retailPriceTextBox
            // 
            this.retailPriceTextBox.BackColor = System.Drawing.Color.White;
            this.retailPriceTextBox.Location = new System.Drawing.Point(142, 196);
            this.retailPriceTextBox.Name = "retailPriceTextBox";
            this.retailPriceTextBox.Size = new System.Drawing.Size(165, 25);
            this.retailPriceTextBox.TabIndex = 5;
            // 
            // retailPriceLabel
            // 
            this.retailPriceLabel.AutoSize = true;
            this.retailPriceLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.retailPriceLabel.Location = new System.Drawing.Point(57, 199);
            this.retailPriceLabel.Name = "retailPriceLabel";
            this.retailPriceLabel.Size = new System.Drawing.Size(79, 17);
            this.retailPriceLabel.TabIndex = 4;
            this.retailPriceLabel.Text = "Retail Price :";
            // 
            // stocksInHandTextBox
            // 
            this.stocksInHandTextBox.BackColor = System.Drawing.Color.White;
            this.stocksInHandTextBox.Location = new System.Drawing.Point(142, 228);
            this.stocksInHandTextBox.Name = "stocksInHandTextBox";
            this.stocksInHandTextBox.Size = new System.Drawing.Size(165, 25);
            this.stocksInHandTextBox.TabIndex = 6;
            // 
            // stocksInHandLabel
            // 
            this.stocksInHandLabel.AutoSize = true;
            this.stocksInHandLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stocksInHandLabel.Location = new System.Drawing.Point(35, 231);
            this.stocksInHandLabel.Name = "stocksInHandLabel";
            this.stocksInHandLabel.Size = new System.Drawing.Size(101, 17);
            this.stocksInHandLabel.TabIndex = 4;
            this.stocksInHandLabel.Text = "Stocks in Hand :";
            // 
            // categoryLabel
            // 
            this.categoryLabel.AutoSize = true;
            this.categoryLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoryLabel.Location = new System.Drawing.Point(65, 137);
            this.categoryLabel.Name = "categoryLabel";
            this.categoryLabel.Size = new System.Drawing.Size(68, 17);
            this.categoryLabel.TabIndex = 4;
            this.categoryLabel.Text = "Category :";
            // 
            // barcodeTextBox
            // 
            this.barcodeTextBox.BackColor = System.Drawing.Color.White;
            this.barcodeTextBox.Location = new System.Drawing.Point(142, 165);
            this.barcodeTextBox.Name = "barcodeTextBox";
            this.barcodeTextBox.Size = new System.Drawing.Size(117, 25);
            this.barcodeTextBox.TabIndex = 2;
            // 
            // barcodeLabel
            // 
            this.barcodeLabel.AutoSize = true;
            this.barcodeLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.barcodeLabel.Location = new System.Drawing.Point(70, 169);
            this.barcodeLabel.Name = "barcodeLabel";
            this.barcodeLabel.Size = new System.Drawing.Size(63, 17);
            this.barcodeLabel.TabIndex = 4;
            this.barcodeLabel.Text = "Barcode :";
            // 
            // productNameTextBox
            // 
            this.productNameTextBox.BackColor = System.Drawing.Color.White;
            this.productNameTextBox.Location = new System.Drawing.Point(142, 70);
            this.productNameTextBox.Name = "productNameTextBox";
            this.productNameTextBox.Size = new System.Drawing.Size(456, 25);
            this.productNameTextBox.TabIndex = 0;
            // 
            // productNameLabel
            // 
            this.productNameLabel.AutoSize = true;
            this.productNameLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productNameLabel.Location = new System.Drawing.Point(38, 73);
            this.productNameLabel.Name = "productNameLabel";
            this.productNameLabel.Size = new System.Drawing.Size(99, 17);
            this.productNameLabel.TabIndex = 3;
            this.productNameLabel.Text = "Product Name :";
            // 
            // productInformationGroupBox
            // 
            this.productInformationGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.productInformationGroupBox.Controls.Add(this.suppliersComboBox);
            this.productInformationGroupBox.Controls.Add(this.supplierLabel);
            this.productInformationGroupBox.Controls.Add(this.costingPriceTextBox);
            this.productInformationGroupBox.Controls.Add(this.costingPriceLabel);
            this.productInformationGroupBox.Controls.Add(this.wholesalePriceTextBox);
            this.productInformationGroupBox.Controls.Add(this.wholesalePriceLabel);
            this.productInformationGroupBox.Controls.Add(this.subcategoryComboBox);
            this.productInformationGroupBox.Controls.Add(this.label1);
            this.productInformationGroupBox.Controls.Add(this.barcodeGeneratorButton);
            this.productInformationGroupBox.Controls.Add(this.productCodeTextBox);
            this.productInformationGroupBox.Controls.Add(this.productCodeLabel);
            this.productInformationGroupBox.Controls.Add(this.categoryComboBox);
            this.productInformationGroupBox.Controls.Add(this.GroupBox2);
            this.productInformationGroupBox.Controls.Add(this.descriptionTextBox);
            this.productInformationGroupBox.Controls.Add(this.descriptionLabel);
            this.productInformationGroupBox.Controls.Add(this.retailPriceTextBox);
            this.productInformationGroupBox.Controls.Add(this.retailPriceLabel);
            this.productInformationGroupBox.Controls.Add(this.stocksInHandTextBox);
            this.productInformationGroupBox.Controls.Add(this.stocksInHandLabel);
            this.productInformationGroupBox.Controls.Add(this.categoryLabel);
            this.productInformationGroupBox.Controls.Add(this.barcodeTextBox);
            this.productInformationGroupBox.Controls.Add(this.barcodeLabel);
            this.productInformationGroupBox.Controls.Add(this.productNameTextBox);
            this.productInformationGroupBox.Controls.Add(this.productNameLabel);
            this.productInformationGroupBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productInformationGroupBox.Location = new System.Drawing.Point(14, 66);
            this.productInformationGroupBox.Name = "productInformationGroupBox";
            this.productInformationGroupBox.Size = new System.Drawing.Size(620, 387);
            this.productInformationGroupBox.TabIndex = 4;
            this.productInformationGroupBox.TabStop = false;
            this.productInformationGroupBox.Text = "Product Information";
            // 
            // suppliersComboBox
            // 
            this.suppliersComboBox.FormattingEnabled = true;
            this.suppliersComboBox.Location = new System.Drawing.Point(433, 233);
            this.suppliersComboBox.Name = "suppliersComboBox";
            this.suppliersComboBox.Size = new System.Drawing.Size(165, 25);
            this.suppliersComboBox.TabIndex = 22;
            // 
            // supplierLabel
            // 
            this.supplierLabel.AutoSize = true;
            this.supplierLabel.Location = new System.Drawing.Point(365, 236);
            this.supplierLabel.Name = "supplierLabel";
            this.supplierLabel.Size = new System.Drawing.Size(67, 17);
            this.supplierLabel.TabIndex = 21;
            this.supplierLabel.Text = "Supplier  :";
            // 
            // costingPriceTextBox
            // 
            this.costingPriceTextBox.BackColor = System.Drawing.Color.White;
            this.costingPriceTextBox.Location = new System.Drawing.Point(433, 166);
            this.costingPriceTextBox.Name = "costingPriceTextBox";
            this.costingPriceTextBox.Size = new System.Drawing.Size(165, 25);
            this.costingPriceTextBox.TabIndex = 18;
            // 
            // costingPriceLabel
            // 
            this.costingPriceLabel.AutoSize = true;
            this.costingPriceLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costingPriceLabel.Location = new System.Drawing.Point(369, 169);
            this.costingPriceLabel.Name = "costingPriceLabel";
            this.costingPriceLabel.Size = new System.Drawing.Size(67, 17);
            this.costingPriceLabel.TabIndex = 17;
            this.costingPriceLabel.Text = " Costing : ";
            // 
            // wholesalePriceTextBox
            // 
            this.wholesalePriceTextBox.BackColor = System.Drawing.Color.White;
            this.wholesalePriceTextBox.Location = new System.Drawing.Point(433, 196);
            this.wholesalePriceTextBox.Name = "wholesalePriceTextBox";
            this.wholesalePriceTextBox.Size = new System.Drawing.Size(165, 25);
            this.wholesalePriceTextBox.TabIndex = 16;
            // 
            // wholesalePriceLabel
            // 
            this.wholesalePriceLabel.AutoSize = true;
            this.wholesalePriceLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wholesalePriceLabel.Location = new System.Drawing.Point(325, 199);
            this.wholesalePriceLabel.Name = "wholesalePriceLabel";
            this.wholesalePriceLabel.Size = new System.Drawing.Size(107, 17);
            this.wholesalePriceLabel.TabIndex = 15;
            this.wholesalePriceLabel.Text = "Wholesale Price :";
            // 
            // subcategoryComboBox
            // 
            this.subcategoryComboBox.FormattingEnabled = true;
            this.subcategoryComboBox.Location = new System.Drawing.Point(433, 134);
            this.subcategoryComboBox.Name = "subcategoryComboBox";
            this.subcategoryComboBox.Size = new System.Drawing.Size(165, 25);
            this.subcategoryComboBox.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(344, 137);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 13;
            this.label1.Text = "Subcategory :";
            // 
            // barcodeGeneratorButton
            // 
            this.barcodeGeneratorButton.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.barcodeGeneratorButton.Location = new System.Drawing.Point(265, 164);
            this.barcodeGeneratorButton.Name = "barcodeGeneratorButton";
            this.barcodeGeneratorButton.Size = new System.Drawing.Size(75, 26);
            this.barcodeGeneratorButton.TabIndex = 12;
            this.barcodeGeneratorButton.Text = "Generate";
            this.barcodeGeneratorButton.UseVisualStyleBackColor = true;
            this.barcodeGeneratorButton.Click += new System.EventHandler(this.barcodeGeneratorButton_Click);
            // 
            // productCodeTextBox
            // 
            this.productCodeTextBox.BackColor = System.Drawing.Color.White;
            this.productCodeTextBox.Location = new System.Drawing.Point(142, 41);
            this.productCodeTextBox.Name = "productCodeTextBox";
            this.productCodeTextBox.Size = new System.Drawing.Size(165, 25);
            this.productCodeTextBox.TabIndex = 11;
            // 
            // productCodeLabel
            // 
            this.productCodeLabel.AutoSize = true;
            this.productCodeLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productCodeLabel.Location = new System.Drawing.Point(42, 44);
            this.productCodeLabel.Name = "productCodeLabel";
            this.productCodeLabel.Size = new System.Drawing.Size(95, 17);
            this.productCodeLabel.TabIndex = 10;
            this.productCodeLabel.Text = "Product Code :";
            // 
            // categoryComboBox
            // 
            this.categoryComboBox.FormattingEnabled = true;
            this.categoryComboBox.Location = new System.Drawing.Point(142, 134);
            this.categoryComboBox.Name = "categoryComboBox";
            this.categoryComboBox.Size = new System.Drawing.Size(165, 25);
            this.categoryComboBox.TabIndex = 9;
            this.categoryComboBox.SelectedIndexChanged += new System.EventHandler(this.categoryComboBox_SelectedIndexChanged);
            // 
            // AddNewProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(646, 473);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.productInformationGroupBox);
            this.Name = "AddNewProductForm";
            this.Text = "Add New Product";
            this.Load += new System.EventHandler(this.AddNewProductForm_Load);
            this.GroupBox2.ResumeLayout(false);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.productInformationGroupBox.ResumeLayout(false);
            this.productInformationGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label addProductLabel;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Button addProductCancelButton;
        internal System.Windows.Forms.Button addProductSaveButton;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.TextBox descriptionTextBox;
        internal System.Windows.Forms.Label descriptionLabel;
        internal System.Windows.Forms.TextBox retailPriceTextBox;
        internal System.Windows.Forms.Label retailPriceLabel;
        internal System.Windows.Forms.TextBox stocksInHandTextBox;
        internal System.Windows.Forms.Label stocksInHandLabel;
        internal System.Windows.Forms.Label categoryLabel;
        internal System.Windows.Forms.TextBox barcodeTextBox;
        internal System.Windows.Forms.Label barcodeLabel;
        internal System.Windows.Forms.TextBox productNameTextBox;
        internal System.Windows.Forms.Label productNameLabel;
        internal System.Windows.Forms.GroupBox productInformationGroupBox;
        private System.Windows.Forms.ComboBox categoryComboBox;
        internal System.Windows.Forms.Label productCodeLabel;
        internal System.Windows.Forms.TextBox productCodeTextBox;
        internal System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.Button barcodeGeneratorButton;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ComboBox subcategoryComboBox;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox wholesalePriceTextBox;
        internal System.Windows.Forms.Label wholesalePriceLabel;
        internal System.Windows.Forms.TextBox costingPriceTextBox;
        internal System.Windows.Forms.Label costingPriceLabel;
        private System.Windows.Forms.ComboBox suppliersComboBox;
        private System.Windows.Forms.Label supplierLabel;
    }
}