﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS
{
    public partial class ProductsListForm : Form
    {
        ProductsGateway productsGateway = new ProductsGateway();

        public UserInfo loggedInUserInfo = null;

        public ProductsListForm(UserInfo userInfo)
        {
            loggedInUserInfo = userInfo;

            InitializeComponent();
        }

        public void LoadProducts()
        {
            productsListView.Items.Clear();

            List<Product> productList = productsGateway.GetAllProducts();
            int i = 1;
            foreach (Product value in productList)
            {
                string serial = i.ToString();
                ListViewItem item = new ListViewItem(serial);
                item.SubItems.Add(value.ProductCode);
                item.SubItems.Add(value.ProductName);
                item.SubItems.Add(value.Category);
                item.SubItems.Add(value.Subcategory);
                item.SubItems.Add(value.Description);
                item.SubItems.Add(value.Supplier);
                item.SubItems.Add(value.Costing.ToString());
                item.SubItems.Add(value.RetailPrice.ToString());
                item.SubItems.Add(value.WholeSalePrice.ToString());
                item.SubItems.Add(value.StocksInHand.ToString());

                productsListView.Items.Add(item);
                i++;
            }
        }

        private void ProductsListForm_Load(object sender, EventArgs e)
        {
            LoadProducts();
        }


        private void toolStripSearchTextBox_TextChanged(object sender, EventArgs e)
        {
            productsListView.Items.Clear();
            
            string searchThisProduct = toolStripSearchTextBox.Text;
            List<Product> productList = productsGateway.GetSpecificProduct(searchThisProduct);
            int i = 1;
            foreach (Product value in productList)
            {
                string serial = i.ToString();
                ListViewItem item = new ListViewItem(serial);
                item.SubItems.Add(value.ProductCode);
                item.SubItems.Add(value.ProductName);
                item.SubItems.Add(value.Category);
                item.SubItems.Add(value.Subcategory);
                item.SubItems.Add(value.Description);
                item.SubItems.Add(value.Costing.ToString());
                item.SubItems.Add(value.RetailPrice.ToString());
                item.SubItems.Add(value.WholeSalePrice.ToString());
                item.SubItems.Add(value.StocksInHand.ToString());

                productsListView.Items.Add(item);
                i++;
            }
        }


        private void reloadToolStripButton_Click(object sender, EventArgs e)
        {
            LoadProducts();
        }

        
        //private void addNewProductToolStripButton_Click(object sender, EventArgs e)
        //{
        //    AddNewProductForm addNewProduct = new AddNewProductForm(loggedInUserInfo);
        //    addNewProduct.Show();
        //    this.Hide();
        //}

        //private void updateProductToolStripButton_Click(object sender, EventArgs e)
        //{
        //    ListViewItem item = productsListView.SelectedItems[0];
        //    string productCode = item.SubItems[1].Text;
        //    string productName = item.SubItems[2].Text;
        //    string category = item.SubItems[3].Text;
        //    string subcategory = item.SubItems[4].Text;
        //    string description = item.SubItems[4].Text;
        //    string barcode = item.SubItems[5].Text;
        //    int unitPrice = Convert.ToInt32(item.SubItems[6].Text);
        //    int stocksInHand = Convert.ToInt32(item.SubItems[7].Text);

        //    if (item == null)
        //    {
        //        MessageBox.Show("Select a product first.");
        //    }
        //    else
        //    {
        //        Product product = new Product(productCode, productName, category, subcategory, description, barcode, unitPrice, stocksInHand);
        //        UpdateExistingProductForm updateProduct = new UpdateExistingProductForm(product, loggedInUserInfo);
        //        updateProduct.Show();
        //        this.Hide();
        //    }
        //}

        //private void stocksInToolStripButton_Click(object sender, EventArgs e)
        //{
        //    //string productCode = "";
        //    //if (productsListView.SelectedItems.Count == 1)
        //    //{
        //    //    ListViewItem item = productsListView.SelectedItems[0];
        //    //    productCode = item.SubItems[1].Text;
        //    //}

        //    StocksUpdateForm stocksIn = new StocksUpdateForm(loggedInUserInfo);
        //    stocksIn.Show();
        //    this.Hide();
        //}
        
        
        //private void deleteProductsToolStripButton_Click(object sender, EventArgs e)
        //{
        //    ListViewItem item = productsListView.SelectedItems[0];
        //    string productCode = item.SubItems[1].Text;
        //    string productName = item.SubItems[2].Text;
        //    string category = item.SubItems[3].Text;
        //    string subcategory = item.SubItems[4].Text;
        //    string description = item.SubItems[4].Text;
        //    string barcode = item.SubItems[5].Text;
        //    int unitPrice = Convert.ToInt32(item.SubItems[6].Text);
        //    int stocksInHand = Convert.ToInt32(item.SubItems[7].Text);

        //    if (item == null)
        //    {
        //        MessageBox.Show("Select a product first.");
        //    }
        //    else
        //    {
        //        Product product = new Product(productCode, productName, category, subcategory, description, barcode, unitPrice, stocksInHand);

        //        DeleteProductForm deleteProduct = new DeleteProductForm(product, loggedInUserInfo);
        //        deleteProduct.Show();
        //        this.Close();
        //    }
        //}

        
    }
}
