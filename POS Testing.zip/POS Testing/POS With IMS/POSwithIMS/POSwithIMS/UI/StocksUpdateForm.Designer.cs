﻿namespace POSwithIMS
{
    partial class StocksUpdateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StocksUpdateForm));
            this.stocksInExcelFileValuesGroupBox = new System.Windows.Forms.GroupBox();
            this.refreshButton = new System.Windows.Forms.Button();
            this.stocksInSaveButton = new System.Windows.Forms.Button();
            this.stocksInCancelButton = new System.Windows.Forms.Button();
            this.loadValueFromExcelFileButton = new System.Windows.Forms.Button();
            this.excelValuesDataGridView = new System.Windows.Forms.DataGridView();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.totalStocksTextBox = new System.Windows.Forms.Label();
            this.totalStocksLabel = new System.Windows.Forms.Label();
            this.currentStocksTextBox = new System.Windows.Forms.Label();
            this.currentStocksLabel = new System.Windows.Forms.Label();
            this.retailPriceTextBox = new System.Windows.Forms.Label();
            this.quantityLabel = new System.Windows.Forms.Label();
            this.retailPriceLabel = new System.Windows.Forms.Label();
            this.descriptionTextBox = new System.Windows.Forms.Label();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.productCodeLabel = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.stocksUpdateInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.suppliersComboBox = new System.Windows.Forms.ComboBox();
            this.supplierLabel = new System.Windows.Forms.Label();
            this.costingTextBox = new System.Windows.Forms.Label();
            this.costingLabel = new System.Windows.Forms.Label();
            this.wholesalePriceTextBox = new System.Windows.Forms.Label();
            this.wholesalePriceLabel = new System.Windows.Forms.Label();
            this.subcategoryTextBox = new System.Windows.Forms.Label();
            this.subcategoryLabel = new System.Windows.Forms.Label();
            this.barcodeTextBox = new System.Windows.Forms.Label();
            this.barcodeLabel = new System.Windows.Forms.Label();
            this.categoryTextBox = new System.Windows.Forms.Label();
            this.categoryLabel = new System.Windows.Forms.Label();
            this.singleValueRefreshButton = new System.Windows.Forms.Button();
            this.singleValueCancelButton = new System.Windows.Forms.Button();
            this.singleStockInSaveButton = new System.Windows.Forms.Button();
            this.productCodeTextBox = new System.Windows.Forms.TextBox();
            this.loadInfoButton = new System.Windows.Forms.Button();
            this.productNameTextBox = new System.Windows.Forms.Label();
            this.productNameLabel = new System.Windows.Forms.Label();
            this.stocksUpdatePanel = new System.Windows.Forms.Panel();
            this.openExcelFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.updateTypeGroupBox = new System.Windows.Forms.GroupBox();
            this.stockOutRadioButton = new System.Windows.Forms.RadioButton();
            this.stockInRadioButton = new System.Windows.Forms.RadioButton();
            this.stocksInExcelFileValuesGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.excelValuesDataGridView)).BeginInit();
            this.stocksUpdateInfoGroupBox.SuspendLayout();
            this.stocksUpdatePanel.SuspendLayout();
            this.updateTypeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // stocksInExcelFileValuesGroupBox
            // 
            this.stocksInExcelFileValuesGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.stocksInExcelFileValuesGroupBox.Controls.Add(this.refreshButton);
            this.stocksInExcelFileValuesGroupBox.Controls.Add(this.stocksInSaveButton);
            this.stocksInExcelFileValuesGroupBox.Controls.Add(this.stocksInCancelButton);
            this.stocksInExcelFileValuesGroupBox.Controls.Add(this.loadValueFromExcelFileButton);
            this.stocksInExcelFileValuesGroupBox.Controls.Add(this.excelValuesDataGridView);
            this.stocksInExcelFileValuesGroupBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stocksInExcelFileValuesGroupBox.Location = new System.Drawing.Point(34, 439);
            this.stocksInExcelFileValuesGroupBox.Name = "stocksInExcelFileValuesGroupBox";
            this.stocksInExcelFileValuesGroupBox.Size = new System.Drawing.Size(687, 301);
            this.stocksInExcelFileValuesGroupBox.TabIndex = 4;
            this.stocksInExcelFileValuesGroupBox.TabStop = false;
            this.stocksInExcelFileValuesGroupBox.Text = "Load Info From Excel File";
            // 
            // refreshButton
            // 
            this.refreshButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.refreshButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.refreshButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.refreshButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshButton.Image = ((System.Drawing.Image)(resources.GetObject("refreshButton.Image")));
            this.refreshButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.refreshButton.Location = new System.Drawing.Point(215, 271);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(82, 24);
            this.refreshButton.TabIndex = 6;
            this.refreshButton.Text = "&Refresh ";
            this.refreshButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.refreshButton.UseVisualStyleBackColor = false;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // stocksInSaveButton
            // 
            this.stocksInSaveButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.stocksInSaveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.stocksInSaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stocksInSaveButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stocksInSaveButton.Image = ((System.Drawing.Image)(resources.GetObject("stocksInSaveButton.Image")));
            this.stocksInSaveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stocksInSaveButton.Location = new System.Drawing.Point(303, 271);
            this.stocksInSaveButton.Name = "stocksInSaveButton";
            this.stocksInSaveButton.Size = new System.Drawing.Size(75, 24);
            this.stocksInSaveButton.TabIndex = 4;
            this.stocksInSaveButton.Text = "&Save ";
            this.stocksInSaveButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.stocksInSaveButton.UseVisualStyleBackColor = false;
            this.stocksInSaveButton.Click += new System.EventHandler(this.stocksInSaveButton_Click);
            // 
            // stocksInCancelButton
            // 
            this.stocksInCancelButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.stocksInCancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.stocksInCancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.stocksInCancelButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stocksInCancelButton.Image = ((System.Drawing.Image)(resources.GetObject("stocksInCancelButton.Image")));
            this.stocksInCancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stocksInCancelButton.Location = new System.Drawing.Point(384, 271);
            this.stocksInCancelButton.Name = "stocksInCancelButton";
            this.stocksInCancelButton.Size = new System.Drawing.Size(75, 24);
            this.stocksInCancelButton.TabIndex = 5;
            this.stocksInCancelButton.Text = "&Cancel";
            this.stocksInCancelButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.stocksInCancelButton.UseVisualStyleBackColor = false;
            this.stocksInCancelButton.Click += new System.EventHandler(this.stocksInCancelButton_Click);
            // 
            // loadValueFromExcelFileButton
            // 
            this.loadValueFromExcelFileButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.loadValueFromExcelFileButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loadValueFromExcelFileButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.loadValueFromExcelFileButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadValueFromExcelFileButton.Image = ((System.Drawing.Image)(resources.GetObject("loadValueFromExcelFileButton.Image")));
            this.loadValueFromExcelFileButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.loadValueFromExcelFileButton.Location = new System.Drawing.Point(312, 22);
            this.loadValueFromExcelFileButton.Name = "loadValueFromExcelFileButton";
            this.loadValueFromExcelFileButton.Size = new System.Drawing.Size(95, 22);
            this.loadValueFromExcelFileButton.TabIndex = 3;
            this.loadValueFromExcelFileButton.Text = "&Load Info ";
            this.loadValueFromExcelFileButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.loadValueFromExcelFileButton.UseVisualStyleBackColor = false;
            this.loadValueFromExcelFileButton.Click += new System.EventHandler(this.loadValueFromExcelFileButton_Click);
            // 
            // excelValuesDataGridView
            // 
            this.excelValuesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.excelValuesDataGridView.Location = new System.Drawing.Point(21, 50);
            this.excelValuesDataGridView.Name = "excelValuesDataGridView";
            this.excelValuesDataGridView.Size = new System.Drawing.Size(644, 213);
            this.excelValuesDataGridView.TabIndex = 0;
            this.excelValuesDataGridView.Visible = false;
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.Location = new System.Drawing.Point(145, 256);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(153, 23);
            this.quantityTextBox.TabIndex = 0;
            this.quantityTextBox.TextChanged += new System.EventHandler(this.quantityTextBox_TextChanged);
            // 
            // totalStocksTextBox
            // 
            this.totalStocksTextBox.BackColor = System.Drawing.Color.White;
            this.totalStocksTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalStocksTextBox.Enabled = false;
            this.totalStocksTextBox.Location = new System.Drawing.Point(433, 258);
            this.totalStocksTextBox.Name = "totalStocksTextBox";
            this.totalStocksTextBox.Size = new System.Drawing.Size(122, 22);
            this.totalStocksTextBox.TabIndex = 3;
            this.totalStocksTextBox.Text = " ";
            // 
            // totalStocksLabel
            // 
            this.totalStocksLabel.AutoSize = true;
            this.totalStocksLabel.Location = new System.Drawing.Point(354, 259);
            this.totalStocksLabel.Name = "totalStocksLabel";
            this.totalStocksLabel.Size = new System.Drawing.Size(76, 15);
            this.totalStocksLabel.TabIndex = 0;
            this.totalStocksLabel.Text = "Total Stocks :";
            // 
            // currentStocksTextBox
            // 
            this.currentStocksTextBox.BackColor = System.Drawing.Color.White;
            this.currentStocksTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.currentStocksTextBox.Enabled = false;
            this.currentStocksTextBox.Location = new System.Drawing.Point(144, 228);
            this.currentStocksTextBox.Name = "currentStocksTextBox";
            this.currentStocksTextBox.Size = new System.Drawing.Size(154, 22);
            this.currentStocksTextBox.TabIndex = 3;
            this.currentStocksTextBox.Text = " ";
            // 
            // currentStocksLabel
            // 
            this.currentStocksLabel.AutoSize = true;
            this.currentStocksLabel.Location = new System.Drawing.Point(48, 229);
            this.currentStocksLabel.Name = "currentStocksLabel";
            this.currentStocksLabel.Size = new System.Drawing.Size(90, 15);
            this.currentStocksLabel.TabIndex = 0;
            this.currentStocksLabel.Text = "Current Stocks :";
            // 
            // retailPriceTextBox
            // 
            this.retailPriceTextBox.BackColor = System.Drawing.Color.White;
            this.retailPriceTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.retailPriceTextBox.Location = new System.Drawing.Point(145, 197);
            this.retailPriceTextBox.Name = "retailPriceTextBox";
            this.retailPriceTextBox.Size = new System.Drawing.Size(153, 22);
            this.retailPriceTextBox.TabIndex = 3;
            this.retailPriceTextBox.Text = " ";
            // 
            // quantityLabel
            // 
            this.quantityLabel.AutoSize = true;
            this.quantityLabel.Location = new System.Drawing.Point(49, 259);
            this.quantityLabel.Name = "quantityLabel";
            this.quantityLabel.Size = new System.Drawing.Size(89, 15);
            this.quantityLabel.TabIndex = 0;
            this.quantityLabel.Text = "Enter Quantity :";
            // 
            // retailPriceLabel
            // 
            this.retailPriceLabel.AutoSize = true;
            this.retailPriceLabel.Location = new System.Drawing.Point(68, 199);
            this.retailPriceLabel.Name = "retailPriceLabel";
            this.retailPriceLabel.Size = new System.Drawing.Size(71, 15);
            this.retailPriceLabel.TabIndex = 0;
            this.retailPriceLabel.Text = "Retail Price :";
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.BackColor = System.Drawing.Color.White;
            this.descriptionTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.descriptionTextBox.Location = new System.Drawing.Point(145, 95);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(410, 22);
            this.descriptionTextBox.TabIndex = 3;
            this.descriptionTextBox.Text = " ";
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Location = new System.Drawing.Point(66, 96);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(73, 15);
            this.descriptionLabel.TabIndex = 0;
            this.descriptionLabel.Text = "Description :";
            // 
            // productCodeLabel
            // 
            this.productCodeLabel.AutoSize = true;
            this.productCodeLabel.Location = new System.Drawing.Point(53, 37);
            this.productCodeLabel.Name = "productCodeLabel";
            this.productCodeLabel.Size = new System.Drawing.Size(86, 15);
            this.productCodeLabel.TabIndex = 0;
            this.productCodeLabel.Text = "Product Code :";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(15, 3);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(167, 36);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Stocks Update";
            // 
            // stocksUpdateInfoGroupBox
            // 
            this.stocksUpdateInfoGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.stocksUpdateInfoGroupBox.Controls.Add(this.suppliersComboBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.supplierLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.costingTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.costingLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.wholesalePriceTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.wholesalePriceLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.subcategoryTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.subcategoryLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.barcodeTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.barcodeLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.categoryTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.categoryLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.singleValueRefreshButton);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.singleValueCancelButton);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.singleStockInSaveButton);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.productCodeTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.loadInfoButton);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.productNameTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.productNameLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.quantityTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.totalStocksTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.totalStocksLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.currentStocksTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.currentStocksLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.retailPriceTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.quantityLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.retailPriceLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.descriptionTextBox);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.descriptionLabel);
            this.stocksUpdateInfoGroupBox.Controls.Add(this.productCodeLabel);
            this.stocksUpdateInfoGroupBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stocksUpdateInfoGroupBox.Location = new System.Drawing.Point(74, 106);
            this.stocksUpdateInfoGroupBox.Name = "stocksUpdateInfoGroupBox";
            this.stocksUpdateInfoGroupBox.Size = new System.Drawing.Size(601, 321);
            this.stocksUpdateInfoGroupBox.TabIndex = 3;
            this.stocksUpdateInfoGroupBox.TabStop = false;
            this.stocksUpdateInfoGroupBox.Text = "Stock Update Information";
            // 
            // suppliersComboBox
            // 
            this.suppliersComboBox.FormattingEnabled = true;
            this.suppliersComboBox.Location = new System.Drawing.Point(433, 228);
            this.suppliersComboBox.Name = "suppliersComboBox";
            this.suppliersComboBox.Size = new System.Drawing.Size(122, 23);
            this.suppliersComboBox.TabIndex = 20;
            // 
            // supplierLabel
            // 
            this.supplierLabel.AutoSize = true;
            this.supplierLabel.Location = new System.Drawing.Point(371, 231);
            this.supplierLabel.Name = "supplierLabel";
            this.supplierLabel.Size = new System.Drawing.Size(59, 15);
            this.supplierLabel.TabIndex = 19;
            this.supplierLabel.Text = "Supplier  :";
            // 
            // costingTextBox
            // 
            this.costingTextBox.BackColor = System.Drawing.Color.White;
            this.costingTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.costingTextBox.Location = new System.Drawing.Point(433, 163);
            this.costingTextBox.Name = "costingTextBox";
            this.costingTextBox.Size = new System.Drawing.Size(122, 22);
            this.costingTextBox.TabIndex = 18;
            this.costingTextBox.Text = " ";
            // 
            // costingLabel
            // 
            this.costingLabel.AutoSize = true;
            this.costingLabel.Location = new System.Drawing.Point(373, 164);
            this.costingLabel.Name = "costingLabel";
            this.costingLabel.Size = new System.Drawing.Size(54, 15);
            this.costingLabel.TabIndex = 17;
            this.costingLabel.Text = "Costing :";
            // 
            // wholesalePriceTextBox
            // 
            this.wholesalePriceTextBox.BackColor = System.Drawing.Color.White;
            this.wholesalePriceTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.wholesalePriceTextBox.Location = new System.Drawing.Point(433, 197);
            this.wholesalePriceTextBox.Name = "wholesalePriceTextBox";
            this.wholesalePriceTextBox.Size = new System.Drawing.Size(122, 22);
            this.wholesalePriceTextBox.TabIndex = 16;
            this.wholesalePriceTextBox.Text = " ";
            // 
            // wholesalePriceLabel
            // 
            this.wholesalePriceLabel.AutoSize = true;
            this.wholesalePriceLabel.Location = new System.Drawing.Point(333, 199);
            this.wholesalePriceLabel.Name = "wholesalePriceLabel";
            this.wholesalePriceLabel.Size = new System.Drawing.Size(96, 15);
            this.wholesalePriceLabel.TabIndex = 15;
            this.wholesalePriceLabel.Text = "Wholesale Price :";
            // 
            // subcategoryTextBox
            // 
            this.subcategoryTextBox.BackColor = System.Drawing.Color.White;
            this.subcategoryTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.subcategoryTextBox.Location = new System.Drawing.Point(433, 127);
            this.subcategoryTextBox.Name = "subcategoryTextBox";
            this.subcategoryTextBox.Size = new System.Drawing.Size(122, 22);
            this.subcategoryTextBox.TabIndex = 14;
            this.subcategoryTextBox.Text = " ";
            // 
            // subcategoryLabel
            // 
            this.subcategoryLabel.AutoSize = true;
            this.subcategoryLabel.Location = new System.Drawing.Point(348, 129);
            this.subcategoryLabel.Name = "subcategoryLabel";
            this.subcategoryLabel.Size = new System.Drawing.Size(79, 15);
            this.subcategoryLabel.TabIndex = 13;
            this.subcategoryLabel.Text = "Subcategory :";
            // 
            // barcodeTextBox
            // 
            this.barcodeTextBox.BackColor = System.Drawing.Color.White;
            this.barcodeTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.barcodeTextBox.Location = new System.Drawing.Point(145, 163);
            this.barcodeTextBox.Name = "barcodeTextBox";
            this.barcodeTextBox.Size = new System.Drawing.Size(153, 22);
            this.barcodeTextBox.TabIndex = 12;
            this.barcodeTextBox.Text = " ";
            // 
            // barcodeLabel
            // 
            this.barcodeLabel.AutoSize = true;
            this.barcodeLabel.Location = new System.Drawing.Point(83, 163);
            this.barcodeLabel.Name = "barcodeLabel";
            this.barcodeLabel.Size = new System.Drawing.Size(56, 15);
            this.barcodeLabel.TabIndex = 11;
            this.barcodeLabel.Text = "Barcode :";
            // 
            // categoryTextBox
            // 
            this.categoryTextBox.BackColor = System.Drawing.Color.White;
            this.categoryTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.categoryTextBox.Location = new System.Drawing.Point(145, 127);
            this.categoryTextBox.Name = "categoryTextBox";
            this.categoryTextBox.Size = new System.Drawing.Size(153, 22);
            this.categoryTextBox.TabIndex = 10;
            this.categoryTextBox.Text = " ";
            // 
            // categoryLabel
            // 
            this.categoryLabel.AutoSize = true;
            this.categoryLabel.Location = new System.Drawing.Point(78, 129);
            this.categoryLabel.Name = "categoryLabel";
            this.categoryLabel.Size = new System.Drawing.Size(61, 15);
            this.categoryLabel.TabIndex = 9;
            this.categoryLabel.Text = "Category :";
            // 
            // singleValueRefreshButton
            // 
            this.singleValueRefreshButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.singleValueRefreshButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.singleValueRefreshButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.singleValueRefreshButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.singleValueRefreshButton.Image = ((System.Drawing.Image)(resources.GetObject("singleValueRefreshButton.Image")));
            this.singleValueRefreshButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.singleValueRefreshButton.Location = new System.Drawing.Point(179, 288);
            this.singleValueRefreshButton.Name = "singleValueRefreshButton";
            this.singleValueRefreshButton.Size = new System.Drawing.Size(82, 27);
            this.singleValueRefreshButton.TabIndex = 8;
            this.singleValueRefreshButton.Text = "&Refresh ";
            this.singleValueRefreshButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.singleValueRefreshButton.UseVisualStyleBackColor = false;
            this.singleValueRefreshButton.Click += new System.EventHandler(this.singleValueRefreshButton_Click);
            // 
            // singleValueCancelButton
            // 
            this.singleValueCancelButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.singleValueCancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.singleValueCancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.singleValueCancelButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.singleValueCancelButton.Image = ((System.Drawing.Image)(resources.GetObject("singleValueCancelButton.Image")));
            this.singleValueCancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.singleValueCancelButton.Location = new System.Drawing.Point(351, 288);
            this.singleValueCancelButton.Name = "singleValueCancelButton";
            this.singleValueCancelButton.Size = new System.Drawing.Size(75, 27);
            this.singleValueCancelButton.TabIndex = 7;
            this.singleValueCancelButton.Text = "&Cancel";
            this.singleValueCancelButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.singleValueCancelButton.UseVisualStyleBackColor = false;
            this.singleValueCancelButton.Click += new System.EventHandler(this.singleValueCancelButton_Click);
            // 
            // singleStockInSaveButton
            // 
            this.singleStockInSaveButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.singleStockInSaveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.singleStockInSaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.singleStockInSaveButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.singleStockInSaveButton.Image = ((System.Drawing.Image)(resources.GetObject("singleStockInSaveButton.Image")));
            this.singleStockInSaveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.singleStockInSaveButton.Location = new System.Drawing.Point(271, 288);
            this.singleStockInSaveButton.Name = "singleStockInSaveButton";
            this.singleStockInSaveButton.Size = new System.Drawing.Size(67, 27);
            this.singleStockInSaveButton.TabIndex = 4;
            this.singleStockInSaveButton.Text = "&Save ";
            this.singleStockInSaveButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.singleStockInSaveButton.UseVisualStyleBackColor = false;
            this.singleStockInSaveButton.Click += new System.EventHandler(this.singleValueSaveButton_Click);
            // 
            // productCodeTextBox
            // 
            this.productCodeTextBox.Location = new System.Drawing.Point(145, 34);
            this.productCodeTextBox.Name = "productCodeTextBox";
            this.productCodeTextBox.Size = new System.Drawing.Size(170, 23);
            this.productCodeTextBox.TabIndex = 6;
            // 
            // loadInfoButton
            // 
            this.loadInfoButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.loadInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loadInfoButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.loadInfoButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadInfoButton.Image = ((System.Drawing.Image)(resources.GetObject("loadInfoButton.Image")));
            this.loadInfoButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.loadInfoButton.Location = new System.Drawing.Point(336, 34);
            this.loadInfoButton.Name = "loadInfoButton";
            this.loadInfoButton.Size = new System.Drawing.Size(99, 22);
            this.loadInfoButton.TabIndex = 2;
            this.loadInfoButton.Text = "&Load Info ";
            this.loadInfoButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.loadInfoButton.UseVisualStyleBackColor = false;
            this.loadInfoButton.Click += new System.EventHandler(this.loadInfoButton_Click);
            // 
            // productNameTextBox
            // 
            this.productNameTextBox.BackColor = System.Drawing.Color.White;
            this.productNameTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.productNameTextBox.Location = new System.Drawing.Point(145, 65);
            this.productNameTextBox.Name = "productNameTextBox";
            this.productNameTextBox.Size = new System.Drawing.Size(410, 22);
            this.productNameTextBox.TabIndex = 5;
            this.productNameTextBox.Text = " ";
            // 
            // productNameLabel
            // 
            this.productNameLabel.AutoSize = true;
            this.productNameLabel.Location = new System.Drawing.Point(49, 65);
            this.productNameLabel.Name = "productNameLabel";
            this.productNameLabel.Size = new System.Drawing.Size(90, 15);
            this.productNameLabel.TabIndex = 4;
            this.productNameLabel.Text = "Product Name :";
            // 
            // stocksUpdatePanel
            // 
            this.stocksUpdatePanel.BackColor = System.Drawing.Color.SteelBlue;
            this.stocksUpdatePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stocksUpdatePanel.Controls.Add(this.lblTitle);
            this.stocksUpdatePanel.Location = new System.Drawing.Point(12, 12);
            this.stocksUpdatePanel.Name = "stocksUpdatePanel";
            this.stocksUpdatePanel.Size = new System.Drawing.Size(735, 41);
            this.stocksUpdatePanel.TabIndex = 5;
            // 
            // openExcelFileDialog
            // 
            this.openExcelFileDialog.FileName = "openExcelFileDialog";
            this.openExcelFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.openExcelFileDialog_FileOk);
            // 
            // updateTypeGroupBox
            // 
            this.updateTypeGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.updateTypeGroupBox.Controls.Add(this.stockOutRadioButton);
            this.updateTypeGroupBox.Controls.Add(this.stockInRadioButton);
            this.updateTypeGroupBox.Location = new System.Drawing.Point(259, 59);
            this.updateTypeGroupBox.Name = "updateTypeGroupBox";
            this.updateTypeGroupBox.Size = new System.Drawing.Size(206, 41);
            this.updateTypeGroupBox.TabIndex = 6;
            this.updateTypeGroupBox.TabStop = false;
            this.updateTypeGroupBox.Text = "Update Type";
            // 
            // stockOutRadioButton
            // 
            this.stockOutRadioButton.AutoSize = true;
            this.stockOutRadioButton.Location = new System.Drawing.Point(109, 19);
            this.stockOutRadioButton.Name = "stockOutRadioButton";
            this.stockOutRadioButton.Size = new System.Drawing.Size(73, 17);
            this.stockOutRadioButton.TabIndex = 8;
            this.stockOutRadioButton.TabStop = true;
            this.stockOutRadioButton.Text = "Stock Out";
            this.stockOutRadioButton.UseVisualStyleBackColor = true;
            // 
            // stockInRadioButton
            // 
            this.stockInRadioButton.AutoSize = true;
            this.stockInRadioButton.Location = new System.Drawing.Point(38, 19);
            this.stockInRadioButton.Name = "stockInRadioButton";
            this.stockInRadioButton.Size = new System.Drawing.Size(65, 17);
            this.stockInRadioButton.TabIndex = 7;
            this.stockInRadioButton.TabStop = true;
            this.stockInRadioButton.Text = "Stock In";
            this.stockInRadioButton.UseVisualStyleBackColor = true;
            // 
            // StocksUpdateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(759, 741);
            this.Controls.Add(this.updateTypeGroupBox);
            this.Controls.Add(this.stocksInExcelFileValuesGroupBox);
            this.Controls.Add(this.stocksUpdateInfoGroupBox);
            this.Controls.Add(this.stocksUpdatePanel);
            this.Name = "StocksUpdateForm";
            this.Text = "Stocks Update";
            this.Load += new System.EventHandler(this.StocksUpdateForm_Load);
            this.stocksInExcelFileValuesGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.excelValuesDataGridView)).EndInit();
            this.stocksUpdateInfoGroupBox.ResumeLayout(false);
            this.stocksUpdateInfoGroupBox.PerformLayout();
            this.stocksUpdatePanel.ResumeLayout(false);
            this.stocksUpdatePanel.PerformLayout();
            this.updateTypeGroupBox.ResumeLayout(false);
            this.updateTypeGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.GroupBox stocksInExcelFileValuesGroupBox;
        internal System.Windows.Forms.TextBox quantityTextBox;
        internal System.Windows.Forms.Label totalStocksTextBox;
        internal System.Windows.Forms.Label totalStocksLabel;
        internal System.Windows.Forms.Label currentStocksTextBox;
        internal System.Windows.Forms.Label currentStocksLabel;
        internal System.Windows.Forms.Label retailPriceTextBox;
        internal System.Windows.Forms.Label quantityLabel;
        internal System.Windows.Forms.Label retailPriceLabel;
        internal System.Windows.Forms.Label descriptionTextBox;
        internal System.Windows.Forms.Label descriptionLabel;
        internal System.Windows.Forms.Label productCodeLabel;
        internal System.Windows.Forms.Label lblTitle;
        internal System.Windows.Forms.GroupBox stocksUpdateInfoGroupBox;
        internal System.Windows.Forms.Panel stocksUpdatePanel;
        internal System.Windows.Forms.Label productNameTextBox;
        internal System.Windows.Forms.Label productNameLabel;
        internal System.Windows.Forms.Button loadInfoButton;
        internal System.Windows.Forms.TextBox productCodeTextBox;
        private System.Windows.Forms.DataGridView excelValuesDataGridView;
        internal System.Windows.Forms.Button loadValueFromExcelFileButton;
        internal System.Windows.Forms.Button singleStockInSaveButton;
        internal System.Windows.Forms.Button refreshButton;
        internal System.Windows.Forms.Button stocksInSaveButton;
        internal System.Windows.Forms.Button stocksInCancelButton;
        internal System.Windows.Forms.Button singleValueRefreshButton;
        internal System.Windows.Forms.Button singleValueCancelButton;
        private System.Windows.Forms.OpenFileDialog openExcelFileDialog;
        internal System.Windows.Forms.Label categoryTextBox;
        internal System.Windows.Forms.Label categoryLabel;
        internal System.Windows.Forms.Label barcodeLabel;
        internal System.Windows.Forms.Label barcodeTextBox;
        private System.Windows.Forms.GroupBox updateTypeGroupBox;
        private System.Windows.Forms.RadioButton stockOutRadioButton;
        private System.Windows.Forms.RadioButton stockInRadioButton;
        internal System.Windows.Forms.Label subcategoryTextBox;
        internal System.Windows.Forms.Label subcategoryLabel;
        internal System.Windows.Forms.Label wholesalePriceTextBox;
        internal System.Windows.Forms.Label wholesalePriceLabel;
        internal System.Windows.Forms.Label costingTextBox;
        internal System.Windows.Forms.Label costingLabel;
        private System.Windows.Forms.Label supplierLabel;
        private System.Windows.Forms.ComboBox suppliersComboBox;
    }
}