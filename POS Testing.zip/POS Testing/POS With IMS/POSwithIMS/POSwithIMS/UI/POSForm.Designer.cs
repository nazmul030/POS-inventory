﻿namespace POSwithIMS
{
    partial class POSForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(POSForm));
            this.productQuantityLabel = new System.Windows.Forms.Label();
            this.productQuantityTextBox = new System.Windows.Forms.TextBox();
            this.purchasedProductsListDataGridView = new System.Windows.Forms.DataGridView();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerAddressTextBox = new System.Windows.Forms.TextBox();
            this.customerMobileTextBox = new System.Windows.Forms.TextBox();
            this.customerMobileLabel = new System.Windows.Forms.Label();
            this.customerNameTextBox = new System.Windows.Forms.TextBox();
            this.customerAddressLabel = new System.Windows.Forms.Label();
            this.customerNameLabel = new System.Windows.Forms.Label();
            this.productNameLabel = new System.Windows.Forms.Label();
            this.productCategoryLabel = new System.Windows.Forms.Label();
            this.productCodeLabel = new System.Windows.Forms.Label();
            this.productCategoryTextBox = new System.Windows.Forms.TextBox();
            this.productNameTextBox = new System.Windows.Forms.TextBox();
            this.productCodeTextBox = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.loadCustomerInfoButton = new System.Windows.Forms.Button();
            this.customerIdTextBox = new System.Windows.Forms.TextBox();
            this.customerIdLabel = new System.Windows.Forms.Label();
            this.productInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.productPriceLlabel = new System.Windows.Forms.Label();
            this.productPriceTextBox = new System.Windows.Forms.TextBox();
            this.productSubcategoryLabel = new System.Windows.Forms.Label();
            this.productSubcategoryTextBox = new System.Windows.Forms.TextBox();
            this.loadProductInfoButton = new System.Windows.Forms.Button();
            this.barcodeLabel = new System.Windows.Forms.Label();
            this.barcodeTextBox = new System.Windows.Forms.TextBox();
            this.TotalLabel = new System.Windows.Forms.Label();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.addToCartButton = new System.Windows.Forms.Button();
            this.paymentInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.dueLabel = new System.Windows.Forms.Label();
            this.ammountDueRichTextBox = new System.Windows.Forms.RichTextBox();
            this.discountLabel = new System.Windows.Forms.Label();
            this.discountRichTextBox = new System.Windows.Forms.RichTextBox();
            this.ammountToBeReturnedLabel = new System.Windows.Forms.Label();
            this.ammountToBeReturnedRichTextBox = new System.Windows.Forms.RichTextBox();
            this.ammountPaidLabel = new System.Windows.Forms.Label();
            this.ammountPaidRichTextBox = new System.Windows.Forms.RichTextBox();
            this.totalAmmoutLabel = new System.Windows.Forms.Label();
            this.totalAmmoutRichTextBox = new System.Windows.Forms.RichTextBox();
            this.paymentTypeGroupBox = new System.Windows.Forms.GroupBox();
            this.bankNamesComboBox = new System.Windows.Forms.ComboBox();
            this.bankNameLabel = new System.Windows.Forms.Label();
            this.checkNoTextBox = new System.Windows.Forms.TextBox();
            this.checkNoLabel = new System.Windows.Forms.Label();
            this.checkRadioButton = new System.Windows.Forms.RadioButton();
            this.cashRadioButton = new System.Windows.Forms.RadioButton();
            this.salesInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.sellingDateTextBox = new System.Windows.Forms.TextBox();
            this.sellingDateLabel = new System.Windows.Forms.Label();
            this.inVoiceNoTextBox = new System.Windows.Forms.TextBox();
            this.sellerTextBox = new System.Windows.Forms.TextBox();
            this.inVoiceNoLabel = new System.Windows.Forms.Label();
            this.sellerLabel = new System.Windows.Forms.Label();
            this.cancelButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.productsListView = new System.Windows.Forms.ListView();
            this.productNameColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.retailPriceColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.wholesalePriceColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.stocksInHandColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.searchProductTextBox = new System.Windows.Forms.TextBox();
            this.searchProductLabel = new System.Windows.Forms.Label();
            this.searchProductGroupBox = new System.Windows.Forms.GroupBox();
            this.productCodeRadioButton = new System.Windows.Forms.RadioButton();
            this.barcodeRadioButton = new System.Windows.Forms.RadioButton();
            this.subcategoryLabel = new System.Windows.Forms.Label();
            this.categoryLabel = new System.Windows.Forms.Label();
            this.subcategoryComboBox = new System.Windows.Forms.ComboBox();
            this.categoryComboBox = new System.Windows.Forms.ComboBox();
            this.reloadProductsButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.purchasedProductsListDataGridView)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.productInfoGroupBox.SuspendLayout();
            this.paymentInfoGroupBox.SuspendLayout();
            this.paymentTypeGroupBox.SuspendLayout();
            this.salesInfoGroupBox.SuspendLayout();
            this.searchProductGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // productQuantityLabel
            // 
            this.productQuantityLabel.AutoSize = true;
            this.productQuantityLabel.Location = new System.Drawing.Point(351, 129);
            this.productQuantityLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.productQuantityLabel.Name = "productQuantityLabel";
            this.productQuantityLabel.Size = new System.Drawing.Size(57, 15);
            this.productQuantityLabel.TabIndex = 4;
            this.productQuantityLabel.Text = "Quantity :";
            // 
            // productQuantityTextBox
            // 
            this.productQuantityTextBox.Location = new System.Drawing.Point(411, 126);
            this.productQuantityTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.productQuantityTextBox.Name = "productQuantityTextBox";
            this.productQuantityTextBox.Size = new System.Drawing.Size(137, 21);
            this.productQuantityTextBox.TabIndex = 5;
            this.productQuantityTextBox.TextChanged += new System.EventHandler(this.productQuantityTextBox_TextChanged);
            // 
            // purchasedProductsListDataGridView
            // 
            this.purchasedProductsListDataGridView.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.purchasedProductsListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.purchasedProductsListDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductName,
            this.UnitPrice,
            this.Quantity,
            this.Total});
            this.purchasedProductsListDataGridView.GridColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.purchasedProductsListDataGridView.Location = new System.Drawing.Point(28, 368);
            this.purchasedProductsListDataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.purchasedProductsListDataGridView.Name = "purchasedProductsListDataGridView";
            this.purchasedProductsListDataGridView.ReadOnly = true;
            this.purchasedProductsListDataGridView.Size = new System.Drawing.Size(591, 360);
            this.purchasedProductsListDataGridView.TabIndex = 6;
            this.purchasedProductsListDataGridView.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.purchasedProductsListDataGridView_RowsAdded);
            this.purchasedProductsListDataGridView.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.purchasedProductsListDataGridView_RowsRemoved);
            // 
            // ProductName
            // 
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ProductName.Width = 250;
            // 
            // UnitPrice
            // 
            this.UnitPrice.HeaderText = "Unit Price";
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.ReadOnly = true;
            this.UnitPrice.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Quantity
            // 
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.ReadOnly = true;
            this.Quantity.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Quantity.Width = 87;
            // 
            // Total
            // 
            this.Total.HeaderText = "Total";
            this.Total.Name = "Total";
            this.Total.ReadOnly = true;
            this.Total.Width = 110;
            // 
            // customerAddressTextBox
            // 
            this.customerAddressTextBox.Location = new System.Drawing.Point(107, 77);
            this.customerAddressTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.customerAddressTextBox.Multiline = true;
            this.customerAddressTextBox.Name = "customerAddressTextBox";
            this.customerAddressTextBox.Size = new System.Drawing.Size(441, 22);
            this.customerAddressTextBox.TabIndex = 2;
            // 
            // customerMobileTextBox
            // 
            this.customerMobileTextBox.Location = new System.Drawing.Point(414, 49);
            this.customerMobileTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.customerMobileTextBox.Name = "customerMobileTextBox";
            this.customerMobileTextBox.Size = new System.Drawing.Size(134, 22);
            this.customerMobileTextBox.TabIndex = 1;
            // 
            // customerMobileLabel
            // 
            this.customerMobileLabel.AutoSize = true;
            this.customerMobileLabel.Location = new System.Drawing.Point(339, 52);
            this.customerMobileLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.customerMobileLabel.Name = "customerMobileLabel";
            this.customerMobileLabel.Size = new System.Drawing.Size(70, 13);
            this.customerMobileLabel.TabIndex = 0;
            this.customerMobileLabel.Text = "Mobile No. :";
            // 
            // customerNameTextBox
            // 
            this.customerNameTextBox.Location = new System.Drawing.Point(107, 50);
            this.customerNameTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.customerNameTextBox.Name = "customerNameTextBox";
            this.customerNameTextBox.Size = new System.Drawing.Size(181, 22);
            this.customerNameTextBox.TabIndex = 0;
            // 
            // customerAddressLabel
            // 
            this.customerAddressLabel.AutoSize = true;
            this.customerAddressLabel.Location = new System.Drawing.Point(45, 81);
            this.customerAddressLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.customerAddressLabel.Name = "customerAddressLabel";
            this.customerAddressLabel.Size = new System.Drawing.Size(54, 13);
            this.customerAddressLabel.TabIndex = 0;
            this.customerAddressLabel.Text = "Address :";
            // 
            // customerNameLabel
            // 
            this.customerNameLabel.AutoSize = true;
            this.customerNameLabel.Location = new System.Drawing.Point(57, 52);
            this.customerNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.customerNameLabel.Name = "customerNameLabel";
            this.customerNameLabel.Size = new System.Drawing.Size(42, 13);
            this.customerNameLabel.TabIndex = 0;
            this.customerNameLabel.Text = "Name :";
            // 
            // productNameLabel
            // 
            this.productNameLabel.AutoSize = true;
            this.productNameLabel.Location = new System.Drawing.Point(53, 69);
            this.productNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.productNameLabel.Name = "productNameLabel";
            this.productNameLabel.Size = new System.Drawing.Size(92, 15);
            this.productNameLabel.TabIndex = 0;
            this.productNameLabel.Text = "Product Name :";
            // 
            // productCategoryLabel
            // 
            this.productCategoryLabel.AutoSize = true;
            this.productCategoryLabel.Location = new System.Drawing.Point(84, 101);
            this.productCategoryLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.productCategoryLabel.Name = "productCategoryLabel";
            this.productCategoryLabel.Size = new System.Drawing.Size(61, 15);
            this.productCategoryLabel.TabIndex = 0;
            this.productCategoryLabel.Text = "Category :";
            // 
            // productCodeLabel
            // 
            this.productCodeLabel.AutoSize = true;
            this.productCodeLabel.Location = new System.Drawing.Point(59, 38);
            this.productCodeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.productCodeLabel.Name = "productCodeLabel";
            this.productCodeLabel.Size = new System.Drawing.Size(87, 15);
            this.productCodeLabel.TabIndex = 0;
            this.productCodeLabel.Text = "Product Code :";
            // 
            // productCategoryTextBox
            // 
            this.productCategoryTextBox.Location = new System.Drawing.Point(154, 98);
            this.productCategoryTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.productCategoryTextBox.Name = "productCategoryTextBox";
            this.productCategoryTextBox.ReadOnly = true;
            this.productCategoryTextBox.Size = new System.Drawing.Size(142, 21);
            this.productCategoryTextBox.TabIndex = 2;
            // 
            // productNameTextBox
            // 
            this.productNameTextBox.Location = new System.Drawing.Point(154, 66);
            this.productNameTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.productNameTextBox.Name = "productNameTextBox";
            this.productNameTextBox.ReadOnly = true;
            this.productNameTextBox.Size = new System.Drawing.Size(394, 21);
            this.productNameTextBox.TabIndex = 1;
            // 
            // productCodeTextBox
            // 
            this.productCodeTextBox.Location = new System.Drawing.Point(154, 35);
            this.productCodeTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.productCodeTextBox.Name = "productCodeTextBox";
            this.productCodeTextBox.Size = new System.Drawing.Size(142, 21);
            this.productCodeTextBox.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox2.Controls.Add(this.loadCustomerInfoButton);
            this.groupBox2.Controls.Add(this.customerIdTextBox);
            this.groupBox2.Controls.Add(this.customerIdLabel);
            this.groupBox2.Controls.Add(this.customerAddressTextBox);
            this.groupBox2.Controls.Add(this.customerNameTextBox);
            this.groupBox2.Controls.Add(this.customerMobileTextBox);
            this.groupBox2.Controls.Add(this.customerNameLabel);
            this.groupBox2.Controls.Add(this.customerAddressLabel);
            this.groupBox2.Controls.Add(this.customerMobileLabel);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(28, 13);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(591, 110);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Customer Info";
            // 
            // loadCustomerInfoButton
            // 
            this.loadCustomerInfoButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.loadCustomerInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loadCustomerInfoButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.loadCustomerInfoButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadCustomerInfoButton.Image = ((System.Drawing.Image)(resources.GetObject("loadCustomerInfoButton.Image")));
            this.loadCustomerInfoButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.loadCustomerInfoButton.Location = new System.Drawing.Point(296, 21);
            this.loadCustomerInfoButton.Margin = new System.Windows.Forms.Padding(4);
            this.loadCustomerInfoButton.Name = "loadCustomerInfoButton";
            this.loadCustomerInfoButton.Size = new System.Drawing.Size(99, 25);
            this.loadCustomerInfoButton.TabIndex = 14;
            this.loadCustomerInfoButton.Text = "&Load Info ";
            this.loadCustomerInfoButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.loadCustomerInfoButton.UseVisualStyleBackColor = false;
            this.loadCustomerInfoButton.Click += new System.EventHandler(this.loadCustomerInfoButton_Click);
            // 
            // customerIdTextBox
            // 
            this.customerIdTextBox.Location = new System.Drawing.Point(107, 25);
            this.customerIdTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.customerIdTextBox.Name = "customerIdTextBox";
            this.customerIdTextBox.Size = new System.Drawing.Size(181, 22);
            this.customerIdTextBox.TabIndex = 3;
            // 
            // customerIdLabel
            // 
            this.customerIdLabel.AutoSize = true;
            this.customerIdLabel.Location = new System.Drawing.Point(24, 28);
            this.customerIdLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.customerIdLabel.Name = "customerIdLabel";
            this.customerIdLabel.Size = new System.Drawing.Size(75, 13);
            this.customerIdLabel.TabIndex = 4;
            this.customerIdLabel.Text = "Customer Id :";
            // 
            // productInfoGroupBox
            // 
            this.productInfoGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.productInfoGroupBox.Controls.Add(this.productPriceLlabel);
            this.productInfoGroupBox.Controls.Add(this.productPriceTextBox);
            this.productInfoGroupBox.Controls.Add(this.productSubcategoryLabel);
            this.productInfoGroupBox.Controls.Add(this.productSubcategoryTextBox);
            this.productInfoGroupBox.Controls.Add(this.loadProductInfoButton);
            this.productInfoGroupBox.Controls.Add(this.barcodeLabel);
            this.productInfoGroupBox.Controls.Add(this.barcodeTextBox);
            this.productInfoGroupBox.Controls.Add(this.TotalLabel);
            this.productInfoGroupBox.Controls.Add(this.totalTextBox);
            this.productInfoGroupBox.Controls.Add(this.clearButton);
            this.productInfoGroupBox.Controls.Add(this.addToCartButton);
            this.productInfoGroupBox.Controls.Add(this.productQuantityLabel);
            this.productInfoGroupBox.Controls.Add(this.productQuantityTextBox);
            this.productInfoGroupBox.Controls.Add(this.productNameLabel);
            this.productInfoGroupBox.Controls.Add(this.productCategoryLabel);
            this.productInfoGroupBox.Controls.Add(this.productCodeLabel);
            this.productInfoGroupBox.Controls.Add(this.productCategoryTextBox);
            this.productInfoGroupBox.Controls.Add(this.productNameTextBox);
            this.productInfoGroupBox.Controls.Add(this.productCodeTextBox);
            this.productInfoGroupBox.ForeColor = System.Drawing.SystemColors.Desktop;
            this.productInfoGroupBox.Location = new System.Drawing.Point(28, 128);
            this.productInfoGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.productInfoGroupBox.Name = "productInfoGroupBox";
            this.productInfoGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.productInfoGroupBox.Size = new System.Drawing.Size(591, 232);
            this.productInfoGroupBox.TabIndex = 9;
            this.productInfoGroupBox.TabStop = false;
            this.productInfoGroupBox.Text = "Product Info";
            // 
            // productPriceLlabel
            // 
            this.productPriceLlabel.AutoSize = true;
            this.productPriceLlabel.Location = new System.Drawing.Point(105, 129);
            this.productPriceLlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.productPriceLlabel.Name = "productPriceLlabel";
            this.productPriceLlabel.Size = new System.Drawing.Size(41, 15);
            this.productPriceLlabel.TabIndex = 20;
            this.productPriceLlabel.Text = "Price :";
            // 
            // productPriceTextBox
            // 
            this.productPriceTextBox.Location = new System.Drawing.Point(154, 127);
            this.productPriceTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.productPriceTextBox.Name = "productPriceTextBox";
            this.productPriceTextBox.Size = new System.Drawing.Size(142, 21);
            this.productPriceTextBox.TabIndex = 21;
            // 
            // productSubcategoryLabel
            // 
            this.productSubcategoryLabel.AutoSize = true;
            this.productSubcategoryLabel.Location = new System.Drawing.Point(327, 98);
            this.productSubcategoryLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.productSubcategoryLabel.Name = "productSubcategoryLabel";
            this.productSubcategoryLabel.Size = new System.Drawing.Size(81, 15);
            this.productSubcategoryLabel.TabIndex = 18;
            this.productSubcategoryLabel.Text = "Subcategory :";
            // 
            // productSubcategoryTextBox
            // 
            this.productSubcategoryTextBox.Location = new System.Drawing.Point(411, 95);
            this.productSubcategoryTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.productSubcategoryTextBox.Name = "productSubcategoryTextBox";
            this.productSubcategoryTextBox.ReadOnly = true;
            this.productSubcategoryTextBox.Size = new System.Drawing.Size(137, 21);
            this.productSubcategoryTextBox.TabIndex = 19;
            // 
            // loadProductInfoButton
            // 
            this.loadProductInfoButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.loadProductInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loadProductInfoButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.loadProductInfoButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadProductInfoButton.Image = ((System.Drawing.Image)(resources.GetObject("loadProductInfoButton.Image")));
            this.loadProductInfoButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.loadProductInfoButton.Location = new System.Drawing.Point(358, 188);
            this.loadProductInfoButton.Margin = new System.Windows.Forms.Padding(4);
            this.loadProductInfoButton.Name = "loadProductInfoButton";
            this.loadProductInfoButton.Size = new System.Drawing.Size(99, 25);
            this.loadProductInfoButton.TabIndex = 13;
            this.loadProductInfoButton.Text = "&Load Info ";
            this.loadProductInfoButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.loadProductInfoButton.UseVisualStyleBackColor = false;
            this.loadProductInfoButton.Click += new System.EventHandler(this.loadProductInfoButton_Click);
            // 
            // barcodeLabel
            // 
            this.barcodeLabel.AutoSize = true;
            this.barcodeLabel.Location = new System.Drawing.Point(345, 35);
            this.barcodeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.barcodeLabel.Name = "barcodeLabel";
            this.barcodeLabel.Size = new System.Drawing.Size(59, 15);
            this.barcodeLabel.TabIndex = 11;
            this.barcodeLabel.Text = "Barcode :";
            // 
            // barcodeTextBox
            // 
            this.barcodeTextBox.Location = new System.Drawing.Point(411, 35);
            this.barcodeTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.barcodeTextBox.Name = "barcodeTextBox";
            this.barcodeTextBox.ReadOnly = true;
            this.barcodeTextBox.Size = new System.Drawing.Size(137, 21);
            this.barcodeTextBox.TabIndex = 12;
            this.barcodeTextBox.TextChanged += new System.EventHandler(this.barcodeTextBox_TextChanged);
            // 
            // TotalLabel
            // 
            this.TotalLabel.AutoSize = true;
            this.TotalLabel.Location = new System.Drawing.Point(106, 159);
            this.TotalLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TotalLabel.Name = "TotalLabel";
            this.TotalLabel.Size = new System.Drawing.Size(40, 15);
            this.TotalLabel.TabIndex = 8;
            this.TotalLabel.Text = "Total :";
            // 
            // totalTextBox
            // 
            this.totalTextBox.Location = new System.Drawing.Point(154, 156);
            this.totalTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.ReadOnly = true;
            this.totalTextBox.Size = new System.Drawing.Size(142, 21);
            this.totalTextBox.TabIndex = 9;
            // 
            // clearButton
            // 
            this.clearButton.Image = global::POSwithIMS.Properties.Resources.edit_clear_24;
            this.clearButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.clearButton.Location = new System.Drawing.Point(277, 188);
            this.clearButton.Margin = new System.Windows.Forms.Padding(4);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(64, 26);
            this.clearButton.TabIndex = 7;
            this.clearButton.Text = "&Clear";
            this.clearButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // addToCartButton
            // 
            this.addToCartButton.Image = global::POSwithIMS.Properties.Resources.shopping_cart_add;
            this.addToCartButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addToCartButton.Location = new System.Drawing.Point(153, 188);
            this.addToCartButton.Margin = new System.Windows.Forms.Padding(4);
            this.addToCartButton.Name = "addToCartButton";
            this.addToCartButton.Size = new System.Drawing.Size(108, 26);
            this.addToCartButton.TabIndex = 6;
            this.addToCartButton.Text = "&Add To Cart";
            this.addToCartButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addToCartButton.UseVisualStyleBackColor = true;
            this.addToCartButton.Click += new System.EventHandler(this.addToCartButton_Click);
            // 
            // paymentInfoGroupBox
            // 
            this.paymentInfoGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.paymentInfoGroupBox.Controls.Add(this.dueLabel);
            this.paymentInfoGroupBox.Controls.Add(this.ammountDueRichTextBox);
            this.paymentInfoGroupBox.Controls.Add(this.discountLabel);
            this.paymentInfoGroupBox.Controls.Add(this.discountRichTextBox);
            this.paymentInfoGroupBox.Controls.Add(this.ammountToBeReturnedLabel);
            this.paymentInfoGroupBox.Controls.Add(this.ammountToBeReturnedRichTextBox);
            this.paymentInfoGroupBox.Controls.Add(this.ammountPaidLabel);
            this.paymentInfoGroupBox.Controls.Add(this.ammountPaidRichTextBox);
            this.paymentInfoGroupBox.Controls.Add(this.totalAmmoutLabel);
            this.paymentInfoGroupBox.Controls.Add(this.totalAmmoutRichTextBox);
            this.paymentInfoGroupBox.Controls.Add(this.paymentTypeGroupBox);
            this.paymentInfoGroupBox.Location = new System.Drawing.Point(984, 128);
            this.paymentInfoGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.paymentInfoGroupBox.Name = "paymentInfoGroupBox";
            this.paymentInfoGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.paymentInfoGroupBox.Size = new System.Drawing.Size(236, 558);
            this.paymentInfoGroupBox.TabIndex = 10;
            this.paymentInfoGroupBox.TabStop = false;
            this.paymentInfoGroupBox.Text = "Payment Info";
            // 
            // dueLabel
            // 
            this.dueLabel.AutoSize = true;
            this.dueLabel.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dueLabel.ForeColor = System.Drawing.Color.Red;
            this.dueLabel.Location = new System.Drawing.Point(96, 479);
            this.dueLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dueLabel.Name = "dueLabel";
            this.dueLabel.Size = new System.Drawing.Size(43, 24);
            this.dueLabel.TabIndex = 35;
            this.dueLabel.Text = "DUE";
            // 
            // ammountDueRichTextBox
            // 
            this.ammountDueRichTextBox.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ammountDueRichTextBox.ForeColor = System.Drawing.Color.Red;
            this.ammountDueRichTextBox.Location = new System.Drawing.Point(11, 507);
            this.ammountDueRichTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.ammountDueRichTextBox.Name = "ammountDueRichTextBox";
            this.ammountDueRichTextBox.Size = new System.Drawing.Size(208, 40);
            this.ammountDueRichTextBox.TabIndex = 34;
            this.ammountDueRichTextBox.Text = "";
            // 
            // discountLabel
            // 
            this.discountLabel.AutoSize = true;
            this.discountLabel.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.discountLabel.ForeColor = System.Drawing.Color.Crimson;
            this.discountLabel.Location = new System.Drawing.Point(69, 254);
            this.discountLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.discountLabel.Name = "discountLabel";
            this.discountLabel.Size = new System.Drawing.Size(80, 24);
            this.discountLabel.TabIndex = 8;
            this.discountLabel.Text = "Discount";
            // 
            // discountRichTextBox
            // 
            this.discountRichTextBox.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.discountRichTextBox.ForeColor = System.Drawing.Color.Black;
            this.discountRichTextBox.Location = new System.Drawing.Point(11, 282);
            this.discountRichTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.discountRichTextBox.Name = "discountRichTextBox";
            this.discountRichTextBox.Size = new System.Drawing.Size(208, 40);
            this.discountRichTextBox.TabIndex = 7;
            this.discountRichTextBox.Text = "";
            this.discountRichTextBox.TextChanged += new System.EventHandler(this.discountRichTextBox_TextChanged);
            // 
            // ammountToBeReturnedLabel
            // 
            this.ammountToBeReturnedLabel.AutoSize = true;
            this.ammountToBeReturnedLabel.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ammountToBeReturnedLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.ammountToBeReturnedLabel.Location = new System.Drawing.Point(51, 407);
            this.ammountToBeReturnedLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ammountToBeReturnedLabel.Name = "ammountToBeReturnedLabel";
            this.ammountToBeReturnedLabel.Size = new System.Drawing.Size(141, 24);
            this.ammountToBeReturnedLabel.TabIndex = 6;
            this.ammountToBeReturnedLabel.Text = "Return Ammount";
            // 
            // ammountToBeReturnedRichTextBox
            // 
            this.ammountToBeReturnedRichTextBox.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ammountToBeReturnedRichTextBox.ForeColor = System.Drawing.Color.Red;
            this.ammountToBeReturnedRichTextBox.Location = new System.Drawing.Point(11, 435);
            this.ammountToBeReturnedRichTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.ammountToBeReturnedRichTextBox.Name = "ammountToBeReturnedRichTextBox";
            this.ammountToBeReturnedRichTextBox.Size = new System.Drawing.Size(208, 40);
            this.ammountToBeReturnedRichTextBox.TabIndex = 5;
            this.ammountToBeReturnedRichTextBox.Text = "";
            // 
            // ammountPaidLabel
            // 
            this.ammountPaidLabel.AutoSize = true;
            this.ammountPaidLabel.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ammountPaidLabel.ForeColor = System.Drawing.Color.Black;
            this.ammountPaidLabel.Location = new System.Drawing.Point(58, 326);
            this.ammountPaidLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ammountPaidLabel.Name = "ammountPaidLabel";
            this.ammountPaidLabel.Size = new System.Drawing.Size(114, 24);
            this.ammountPaidLabel.TabIndex = 4;
            this.ammountPaidLabel.Text = "Ammout Paid";
            // 
            // ammountPaidRichTextBox
            // 
            this.ammountPaidRichTextBox.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ammountPaidRichTextBox.ForeColor = System.Drawing.Color.Black;
            this.ammountPaidRichTextBox.Location = new System.Drawing.Point(11, 354);
            this.ammountPaidRichTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.ammountPaidRichTextBox.Name = "ammountPaidRichTextBox";
            this.ammountPaidRichTextBox.Size = new System.Drawing.Size(208, 40);
            this.ammountPaidRichTextBox.TabIndex = 3;
            this.ammountPaidRichTextBox.Text = "";
            this.ammountPaidRichTextBox.TextChanged += new System.EventHandler(this.ammountPaidRichTextBox_TextChanged);
            // 
            // totalAmmoutLabel
            // 
            this.totalAmmoutLabel.AutoSize = true;
            this.totalAmmoutLabel.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalAmmoutLabel.ForeColor = System.Drawing.Color.MidnightBlue;
            this.totalAmmoutLabel.Location = new System.Drawing.Point(51, 180);
            this.totalAmmoutLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalAmmoutLabel.Name = "totalAmmoutLabel";
            this.totalAmmoutLabel.Size = new System.Drawing.Size(128, 24);
            this.totalAmmoutLabel.TabIndex = 2;
            this.totalAmmoutLabel.Text = "Total Ammount";
            // 
            // totalAmmoutRichTextBox
            // 
            this.totalAmmoutRichTextBox.BackColor = System.Drawing.Color.White;
            this.totalAmmoutRichTextBox.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalAmmoutRichTextBox.ForeColor = System.Drawing.Color.MidnightBlue;
            this.totalAmmoutRichTextBox.Location = new System.Drawing.Point(11, 208);
            this.totalAmmoutRichTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.totalAmmoutRichTextBox.Name = "totalAmmoutRichTextBox";
            this.totalAmmoutRichTextBox.Size = new System.Drawing.Size(208, 42);
            this.totalAmmoutRichTextBox.TabIndex = 1;
            this.totalAmmoutRichTextBox.Text = "";
            this.totalAmmoutRichTextBox.TextChanged += new System.EventHandler(this.totalAmmoutRichTextBox_TextChanged);
            // 
            // paymentTypeGroupBox
            // 
            this.paymentTypeGroupBox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.paymentTypeGroupBox.Controls.Add(this.bankNamesComboBox);
            this.paymentTypeGroupBox.Controls.Add(this.bankNameLabel);
            this.paymentTypeGroupBox.Controls.Add(this.checkNoTextBox);
            this.paymentTypeGroupBox.Controls.Add(this.checkNoLabel);
            this.paymentTypeGroupBox.Controls.Add(this.checkRadioButton);
            this.paymentTypeGroupBox.Controls.Add(this.cashRadioButton);
            this.paymentTypeGroupBox.Location = new System.Drawing.Point(11, 30);
            this.paymentTypeGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.paymentTypeGroupBox.Name = "paymentTypeGroupBox";
            this.paymentTypeGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.paymentTypeGroupBox.Size = new System.Drawing.Size(205, 141);
            this.paymentTypeGroupBox.TabIndex = 0;
            this.paymentTypeGroupBox.TabStop = false;
            this.paymentTypeGroupBox.Text = "Payment Type";
            // 
            // bankNamesComboBox
            // 
            this.bankNamesComboBox.Enabled = false;
            this.bankNamesComboBox.FormattingEnabled = true;
            this.bankNamesComboBox.Location = new System.Drawing.Point(15, 64);
            this.bankNamesComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.bankNamesComboBox.Name = "bankNamesComboBox";
            this.bankNamesComboBox.Size = new System.Drawing.Size(176, 23);
            this.bankNamesComboBox.TabIndex = 5;
            // 
            // bankNameLabel
            // 
            this.bankNameLabel.AutoSize = true;
            this.bankNameLabel.Location = new System.Drawing.Point(62, 45);
            this.bankNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bankNameLabel.Name = "bankNameLabel";
            this.bankNameLabel.Size = new System.Drawing.Size(72, 15);
            this.bankNameLabel.TabIndex = 4;
            this.bankNameLabel.Text = "Bank Name";
            // 
            // checkNoTextBox
            // 
            this.checkNoTextBox.Location = new System.Drawing.Point(15, 110);
            this.checkNoTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.checkNoTextBox.Name = "checkNoTextBox";
            this.checkNoTextBox.ReadOnly = true;
            this.checkNoTextBox.Size = new System.Drawing.Size(176, 21);
            this.checkNoTextBox.TabIndex = 3;
            // 
            // checkNoLabel
            // 
            this.checkNoLabel.AutoSize = true;
            this.checkNoLabel.Location = new System.Drawing.Point(74, 91);
            this.checkNoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkNoLabel.Name = "checkNoLabel";
            this.checkNoLabel.Size = new System.Drawing.Size(60, 15);
            this.checkNoLabel.TabIndex = 2;
            this.checkNoLabel.Text = "Check No";
            // 
            // checkRadioButton
            // 
            this.checkRadioButton.AutoSize = true;
            this.checkRadioButton.Location = new System.Drawing.Point(109, 22);
            this.checkRadioButton.Margin = new System.Windows.Forms.Padding(4);
            this.checkRadioButton.Name = "checkRadioButton";
            this.checkRadioButton.Size = new System.Drawing.Size(59, 19);
            this.checkRadioButton.TabIndex = 1;
            this.checkRadioButton.TabStop = true;
            this.checkRadioButton.Text = "Check";
            this.checkRadioButton.UseVisualStyleBackColor = true;
            this.checkRadioButton.CheckedChanged += new System.EventHandler(this.checkRadioButton_CheckedChanged);
            // 
            // cashRadioButton
            // 
            this.cashRadioButton.AutoSize = true;
            this.cashRadioButton.Location = new System.Drawing.Point(44, 22);
            this.cashRadioButton.Margin = new System.Windows.Forms.Padding(4);
            this.cashRadioButton.Name = "cashRadioButton";
            this.cashRadioButton.Size = new System.Drawing.Size(53, 19);
            this.cashRadioButton.TabIndex = 0;
            this.cashRadioButton.TabStop = true;
            this.cashRadioButton.Text = "Cash";
            this.cashRadioButton.UseVisualStyleBackColor = true;
            this.cashRadioButton.CheckedChanged += new System.EventHandler(this.cashRadioButton_CheckedChanged);
            // 
            // salesInfoGroupBox
            // 
            this.salesInfoGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.salesInfoGroupBox.Controls.Add(this.sellingDateTextBox);
            this.salesInfoGroupBox.Controls.Add(this.sellingDateLabel);
            this.salesInfoGroupBox.Controls.Add(this.inVoiceNoTextBox);
            this.salesInfoGroupBox.Controls.Add(this.sellerTextBox);
            this.salesInfoGroupBox.Controls.Add(this.inVoiceNoLabel);
            this.salesInfoGroupBox.Controls.Add(this.sellerLabel);
            this.salesInfoGroupBox.Location = new System.Drawing.Point(984, 13);
            this.salesInfoGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.salesInfoGroupBox.Name = "salesInfoGroupBox";
            this.salesInfoGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.salesInfoGroupBox.Size = new System.Drawing.Size(236, 107);
            this.salesInfoGroupBox.TabIndex = 11;
            this.salesInfoGroupBox.TabStop = false;
            this.salesInfoGroupBox.Text = "Sales Info";
            // 
            // sellingDateTextBox
            // 
            this.sellingDateTextBox.Location = new System.Drawing.Point(62, 78);
            this.sellingDateTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.sellingDateTextBox.Name = "sellingDateTextBox";
            this.sellingDateTextBox.ReadOnly = true;
            this.sellingDateTextBox.Size = new System.Drawing.Size(154, 21);
            this.sellingDateTextBox.TabIndex = 7;
            // 
            // sellingDateLabel
            // 
            this.sellingDateLabel.AutoSize = true;
            this.sellingDateLabel.Location = new System.Drawing.Point(23, 81);
            this.sellingDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sellingDateLabel.Name = "sellingDateLabel";
            this.sellingDateLabel.Size = new System.Drawing.Size(39, 15);
            this.sellingDateLabel.TabIndex = 6;
            this.sellingDateLabel.Text = "Date :";
            // 
            // inVoiceNoTextBox
            // 
            this.inVoiceNoTextBox.Location = new System.Drawing.Point(100, 25);
            this.inVoiceNoTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.inVoiceNoTextBox.Name = "inVoiceNoTextBox";
            this.inVoiceNoTextBox.ReadOnly = true;
            this.inVoiceNoTextBox.Size = new System.Drawing.Size(116, 21);
            this.inVoiceNoTextBox.TabIndex = 2;
            // 
            // sellerTextBox
            // 
            this.sellerTextBox.Location = new System.Drawing.Point(71, 52);
            this.sellerTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.sellerTextBox.Name = "sellerTextBox";
            this.sellerTextBox.ReadOnly = true;
            this.sellerTextBox.Size = new System.Drawing.Size(145, 21);
            this.sellerTextBox.TabIndex = 5;
            // 
            // inVoiceNoLabel
            // 
            this.inVoiceNoLabel.AutoSize = true;
            this.inVoiceNoLabel.Location = new System.Drawing.Point(23, 28);
            this.inVoiceNoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.inVoiceNoLabel.Name = "inVoiceNoLabel";
            this.inVoiceNoLabel.Size = new System.Drawing.Size(78, 15);
            this.inVoiceNoLabel.TabIndex = 3;
            this.inVoiceNoLabel.Text = "In Voice No. :";
            // 
            // sellerLabel
            // 
            this.sellerLabel.AutoSize = true;
            this.sellerLabel.Location = new System.Drawing.Point(23, 55);
            this.sellerLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sellerLabel.Name = "sellerLabel";
            this.sellerLabel.Size = new System.Drawing.Size(45, 15);
            this.sellerLabel.TabIndex = 4;
            this.sellerLabel.Text = "Seller :";
            // 
            // cancelButton
            // 
            this.cancelButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancelButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Image = ((System.Drawing.Image)(resources.GetObject("cancelButton.Image")));
            this.cancelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancelButton.Location = new System.Drawing.Point(1020, 697);
            this.cancelButton.Margin = new System.Windows.Forms.Padding(4);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(72, 31);
            this.cancelButton.TabIndex = 8;
            this.cancelButton.Text = "&Cancel";
            this.cancelButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cancelButton.UseVisualStyleBackColor = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.saveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.saveButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.saveButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Image = ((System.Drawing.Image)(resources.GetObject("saveButton.Image")));
            this.saveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveButton.Location = new System.Drawing.Point(1105, 697);
            this.saveButton.Margin = new System.Windows.Forms.Padding(4);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(68, 31);
            this.saveButton.TabIndex = 7;
            this.saveButton.Text = "&Save ";
            this.saveButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // productsListView
            // 
            this.productsListView.BackColor = System.Drawing.Color.White;
            this.productsListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.productNameColumnHeader,
            this.retailPriceColumnHeader,
            this.wholesalePriceColumnHeader,
            this.stocksInHandColumnHeader});
            this.productsListView.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productsListView.FullRowSelect = true;
            this.productsListView.GridLines = true;
            this.productsListView.Location = new System.Drawing.Point(627, 207);
            this.productsListView.Margin = new System.Windows.Forms.Padding(4);
            this.productsListView.Name = "productsListView";
            this.productsListView.Size = new System.Drawing.Size(349, 521);
            this.productsListView.TabIndex = 32;
            this.productsListView.UseCompatibleStateImageBehavior = false;
            this.productsListView.View = System.Windows.Forms.View.Details;
            this.productsListView.SelectedIndexChanged += new System.EventHandler(this.productsListView_SelectedIndexChanged);
            // 
            // productNameColumnHeader
            // 
            this.productNameColumnHeader.Text = "Product Name";
            this.productNameColumnHeader.Width = 153;
            // 
            // retailPriceColumnHeader
            // 
            this.retailPriceColumnHeader.Text = "Retail";
            this.retailPriceColumnHeader.Width = 70;
            // 
            // wholesalePriceColumnHeader
            // 
            this.wholesalePriceColumnHeader.Text = "Wholesale";
            this.wholesalePriceColumnHeader.Width = 70;
            // 
            // stocksInHandColumnHeader
            // 
            this.stocksInHandColumnHeader.Text = "Stock";
            this.stocksInHandColumnHeader.Width = 50;
            // 
            // searchProductTextBox
            // 
            this.searchProductTextBox.Location = new System.Drawing.Point(149, 28);
            this.searchProductTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.searchProductTextBox.Name = "searchProductTextBox";
            this.searchProductTextBox.Size = new System.Drawing.Size(158, 21);
            this.searchProductTextBox.TabIndex = 4;
            this.searchProductTextBox.TextChanged += new System.EventHandler(this.searchProductTextBox_TextChanged);
            // 
            // searchProductLabel
            // 
            this.searchProductLabel.AutoSize = true;
            this.searchProductLabel.Location = new System.Drawing.Point(44, 31);
            this.searchProductLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.searchProductLabel.Name = "searchProductLabel";
            this.searchProductLabel.Size = new System.Drawing.Size(97, 15);
            this.searchProductLabel.TabIndex = 3;
            this.searchProductLabel.Text = "Search Product :";
            // 
            // searchProductGroupBox
            // 
            this.searchProductGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.searchProductGroupBox.Controls.Add(this.productCodeRadioButton);
            this.searchProductGroupBox.Controls.Add(this.barcodeRadioButton);
            this.searchProductGroupBox.Controls.Add(this.subcategoryLabel);
            this.searchProductGroupBox.Controls.Add(this.categoryLabel);
            this.searchProductGroupBox.Controls.Add(this.subcategoryComboBox);
            this.searchProductGroupBox.Controls.Add(this.categoryComboBox);
            this.searchProductGroupBox.Controls.Add(this.reloadProductsButton);
            this.searchProductGroupBox.Controls.Add(this.searchProductTextBox);
            this.searchProductGroupBox.Controls.Add(this.searchProductLabel);
            this.searchProductGroupBox.Location = new System.Drawing.Point(627, 13);
            this.searchProductGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.searchProductGroupBox.Name = "searchProductGroupBox";
            this.searchProductGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.searchProductGroupBox.Size = new System.Drawing.Size(349, 188);
            this.searchProductGroupBox.TabIndex = 33;
            this.searchProductGroupBox.TabStop = false;
            this.searchProductGroupBox.Text = "Search Product";
            // 
            // productCodeRadioButton
            // 
            this.productCodeRadioButton.AutoSize = true;
            this.productCodeRadioButton.Location = new System.Drawing.Point(83, 58);
            this.productCodeRadioButton.Name = "productCodeRadioButton";
            this.productCodeRadioButton.Size = new System.Drawing.Size(99, 19);
            this.productCodeRadioButton.TabIndex = 11;
            this.productCodeRadioButton.TabStop = true;
            this.productCodeRadioButton.Text = "Product Code";
            this.productCodeRadioButton.UseVisualStyleBackColor = true;
            // 
            // barcodeRadioButton
            // 
            this.barcodeRadioButton.AutoSize = true;
            this.barcodeRadioButton.Location = new System.Drawing.Point(207, 58);
            this.barcodeRadioButton.Name = "barcodeRadioButton";
            this.barcodeRadioButton.Size = new System.Drawing.Size(71, 19);
            this.barcodeRadioButton.TabIndex = 10;
            this.barcodeRadioButton.TabStop = true;
            this.barcodeRadioButton.Text = "Barcode";
            this.barcodeRadioButton.UseVisualStyleBackColor = true;
            // 
            // subcategoryLabel
            // 
            this.subcategoryLabel.AutoSize = true;
            this.subcategoryLabel.Location = new System.Drawing.Point(60, 118);
            this.subcategoryLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.subcategoryLabel.Name = "subcategoryLabel";
            this.subcategoryLabel.Size = new System.Drawing.Size(81, 15);
            this.subcategoryLabel.TabIndex = 9;
            this.subcategoryLabel.Text = "Subcategory :";
            // 
            // categoryLabel
            // 
            this.categoryLabel.AutoSize = true;
            this.categoryLabel.Location = new System.Drawing.Point(80, 87);
            this.categoryLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.categoryLabel.Name = "categoryLabel";
            this.categoryLabel.Size = new System.Drawing.Size(61, 15);
            this.categoryLabel.TabIndex = 8;
            this.categoryLabel.Text = "Category :";
            // 
            // subcategoryComboBox
            // 
            this.subcategoryComboBox.FormattingEnabled = true;
            this.subcategoryComboBox.Location = new System.Drawing.Point(149, 115);
            this.subcategoryComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.subcategoryComboBox.Name = "subcategoryComboBox";
            this.subcategoryComboBox.Size = new System.Drawing.Size(158, 23);
            this.subcategoryComboBox.TabIndex = 7;
            this.subcategoryComboBox.SelectedIndexChanged += new System.EventHandler(this.subcategoryComboBox_SelectedIndexChanged);
            // 
            // categoryComboBox
            // 
            this.categoryComboBox.FormattingEnabled = true;
            this.categoryComboBox.Location = new System.Drawing.Point(149, 84);
            this.categoryComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.categoryComboBox.Name = "categoryComboBox";
            this.categoryComboBox.Size = new System.Drawing.Size(158, 23);
            this.categoryComboBox.TabIndex = 6;
            this.categoryComboBox.SelectedIndexChanged += new System.EventHandler(this.categoryComboBox_SelectedIndexChanged);
            // 
            // reloadProductsButton
            // 
            this.reloadProductsButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.reloadProductsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reloadProductsButton.ForeColor = System.Drawing.Color.Goldenrod;
            this.reloadProductsButton.Location = new System.Drawing.Point(133, 153);
            this.reloadProductsButton.Margin = new System.Windows.Forms.Padding(4);
            this.reloadProductsButton.Name = "reloadProductsButton";
            this.reloadProductsButton.Size = new System.Drawing.Size(116, 26);
            this.reloadProductsButton.TabIndex = 5;
            this.reloadProductsButton.Text = "Reload Products";
            this.reloadProductsButton.UseVisualStyleBackColor = false;
            this.reloadProductsButton.Click += new System.EventHandler(this.reloadProductsButton_Click);
            // 
            // POSForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1246, 741);
            this.Controls.Add(this.searchProductGroupBox);
            this.Controls.Add(this.productsListView);
            this.Controls.Add(this.salesInfoGroupBox);
            this.Controls.Add(this.paymentInfoGroupBox);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.purchasedProductsListDataGridView);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.productInfoGroupBox);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "POSForm";
            this.Text = "Point On Sale";
            this.Load += new System.EventHandler(this.POSForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.purchasedProductsListDataGridView)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.productInfoGroupBox.ResumeLayout(false);
            this.productInfoGroupBox.PerformLayout();
            this.paymentInfoGroupBox.ResumeLayout(false);
            this.paymentInfoGroupBox.PerformLayout();
            this.paymentTypeGroupBox.ResumeLayout(false);
            this.paymentTypeGroupBox.PerformLayout();
            this.salesInfoGroupBox.ResumeLayout(false);
            this.salesInfoGroupBox.PerformLayout();
            this.searchProductGroupBox.ResumeLayout(false);
            this.searchProductGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button addToCartButton;
        private System.Windows.Forms.Label productQuantityLabel;
        private System.Windows.Forms.TextBox productQuantityTextBox;
        internal System.Windows.Forms.Button cancelButton;
        internal System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.TextBox customerAddressTextBox;
        private System.Windows.Forms.TextBox customerMobileTextBox;
        private System.Windows.Forms.Label customerMobileLabel;
        private System.Windows.Forms.TextBox customerNameTextBox;
        private System.Windows.Forms.Label customerAddressLabel;
        private System.Windows.Forms.Label customerNameLabel;
        private System.Windows.Forms.Label productNameLabel;
        private System.Windows.Forms.Label productCategoryLabel;
        private System.Windows.Forms.Label productCodeLabel;
        private System.Windows.Forms.TextBox productCategoryTextBox;
        private System.Windows.Forms.TextBox productNameTextBox;
        private System.Windows.Forms.TextBox productCodeTextBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox productInfoGroupBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.GroupBox paymentInfoGroupBox;
        private System.Windows.Forms.Label TotalLabel;
        private System.Windows.Forms.TextBox totalTextBox;
        private System.Windows.Forms.GroupBox salesInfoGroupBox;
        private System.Windows.Forms.TextBox inVoiceNoTextBox;
        private System.Windows.Forms.TextBox sellerTextBox;
        private System.Windows.Forms.Label inVoiceNoLabel;
        private System.Windows.Forms.Label sellerLabel;
        private System.Windows.Forms.TextBox sellingDateTextBox;
        private System.Windows.Forms.Label sellingDateLabel;
        private System.Windows.Forms.GroupBox paymentTypeGroupBox;
        private System.Windows.Forms.RadioButton checkRadioButton;
        private System.Windows.Forms.RadioButton cashRadioButton;
        private System.Windows.Forms.Label bankNameLabel;
        private System.Windows.Forms.TextBox checkNoTextBox;
        private System.Windows.Forms.Label checkNoLabel;
        private System.Windows.Forms.ComboBox bankNamesComboBox;
        private System.Windows.Forms.Label totalAmmoutLabel;
        private System.Windows.Forms.RichTextBox totalAmmoutRichTextBox;
        private System.Windows.Forms.Label ammountToBeReturnedLabel;
        private System.Windows.Forms.RichTextBox ammountToBeReturnedRichTextBox;
        private System.Windows.Forms.Label ammountPaidLabel;
        private System.Windows.Forms.RichTextBox ammountPaidRichTextBox;
        internal System.Windows.Forms.ListView productsListView;
        private System.Windows.Forms.ColumnHeader productNameColumnHeader;
        internal System.Windows.Forms.ColumnHeader retailPriceColumnHeader;
        internal System.Windows.Forms.ColumnHeader stocksInHandColumnHeader;
        private System.Windows.Forms.TextBox searchProductTextBox;
        private System.Windows.Forms.Label searchProductLabel;
        private System.Windows.Forms.GroupBox searchProductGroupBox;
        private System.Windows.Forms.Label discountLabel;
        private System.Windows.Forms.RichTextBox discountRichTextBox;
        private System.Windows.Forms.Button reloadProductsButton;
        private System.Windows.Forms.Label barcodeLabel;
        private System.Windows.Forms.TextBox barcodeTextBox;
        private System.Windows.Forms.DataGridView purchasedProductsListDataGridView;
        internal System.Windows.Forms.Button loadProductInfoButton;
        private System.Windows.Forms.Label categoryLabel;
        private System.Windows.Forms.ComboBox subcategoryComboBox;
        private System.Windows.Forms.ComboBox categoryComboBox;
        private System.Windows.Forms.Label subcategoryLabel;
        private System.Windows.Forms.ColumnHeader wholesalePriceColumnHeader;
        private System.Windows.Forms.Label productSubcategoryLabel;
        private System.Windows.Forms.TextBox productSubcategoryTextBox;
        private System.Windows.Forms.RadioButton productCodeRadioButton;
        private System.Windows.Forms.RadioButton barcodeRadioButton;
        private System.Windows.Forms.Label dueLabel;
        private System.Windows.Forms.RichTextBox ammountDueRichTextBox;
        private System.Windows.Forms.Label productPriceLlabel;
        private System.Windows.Forms.TextBox productPriceTextBox;
        internal System.Windows.Forms.Button loadCustomerInfoButton;
        private System.Windows.Forms.TextBox customerIdTextBox;
        private System.Windows.Forms.Label customerIdLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total;
    }
}