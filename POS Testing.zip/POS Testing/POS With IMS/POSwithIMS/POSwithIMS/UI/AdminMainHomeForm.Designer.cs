﻿namespace POSwithIMS
{
    partial class AdminMainHomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminMainHomeForm));
            this.timeLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.ToolStrip = new System.Windows.Forms.ToolStrip();
            this.staffToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.categoryToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.productsListToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.posToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.stocksUpdateToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
            this.activeUserToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.loggedInUserLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.dateToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.dateLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.timeToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.FileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ConfigurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backUpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suppliersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewSuppliersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewEmployeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stocksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stocksUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stocksOutListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usersPasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.ToolStrip.SuspendLayout();
            this.StatusStrip1.SuspendLayout();
            this.MenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timeLabel
            // 
            this.timeLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(71, 17);
            this.timeLabel.Text = "hh:mm:sss";
            // 
            // ToolStrip
            // 
            this.ToolStrip.AutoSize = false;
            this.ToolStrip.BackColor = System.Drawing.Color.SteelBlue;
            this.ToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.staffToolStripButton,
            this.categoryToolStripButton,
            this.productsListToolStripButton,
            this.posToolStripButton,
            this.stocksUpdateToolStripButton});
            this.ToolStrip.Location = new System.Drawing.Point(0, 24);
            this.ToolStrip.Name = "ToolStrip";
            this.ToolStrip.Size = new System.Drawing.Size(886, 75);
            this.ToolStrip.TabIndex = 15;
            this.ToolStrip.Text = "ToolStrip";
            // 
            // staffToolStripButton
            // 
            this.staffToolStripButton.Name = "staffToolStripButton";
            this.staffToolStripButton.Size = new System.Drawing.Size(23, 72);
            // 
            // categoryToolStripButton
            // 
            this.categoryToolStripButton.AutoSize = false;
            this.categoryToolStripButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoryToolStripButton.ForeColor = System.Drawing.Color.White;
            this.categoryToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("categoryToolStripButton.Image")));
            this.categoryToolStripButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.categoryToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.categoryToolStripButton.Name = "categoryToolStripButton";
            this.categoryToolStripButton.Size = new System.Drawing.Size(70, 72);
            this.categoryToolStripButton.Text = "Category";
            this.categoryToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.categoryToolStripButton.ToolTipText = "Product Category";
            this.categoryToolStripButton.Click += new System.EventHandler(this.categoryToolStripButton_Click);
            // 
            // productsListToolStripButton
            // 
            this.productsListToolStripButton.AutoSize = false;
            this.productsListToolStripButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productsListToolStripButton.ForeColor = System.Drawing.Color.White;
            this.productsListToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("productsListToolStripButton.Image")));
            this.productsListToolStripButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.productsListToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.productsListToolStripButton.Name = "productsListToolStripButton";
            this.productsListToolStripButton.Size = new System.Drawing.Size(70, 72);
            this.productsListToolStripButton.Text = "Products";
            this.productsListToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.productsListToolStripButton.Click += new System.EventHandler(this.productToolStripButton_Click);
            // 
            // posToolStripButton
            // 
            this.posToolStripButton.AutoSize = false;
            this.posToolStripButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posToolStripButton.ForeColor = System.Drawing.Color.White;
            this.posToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("posToolStripButton.Image")));
            this.posToolStripButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.posToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.posToolStripButton.Name = "posToolStripButton";
            this.posToolStripButton.Size = new System.Drawing.Size(70, 72);
            this.posToolStripButton.Text = "POS";
            this.posToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.posToolStripButton.Click += new System.EventHandler(this.posToolStripButton_Click);
            // 
            // stocksUpdateToolStripButton
            // 
            this.stocksUpdateToolStripButton.AutoSize = false;
            this.stocksUpdateToolStripButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stocksUpdateToolStripButton.ForeColor = System.Drawing.Color.White;
            this.stocksUpdateToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("stocksUpdateToolStripButton.Image")));
            this.stocksUpdateToolStripButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.stocksUpdateToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stocksUpdateToolStripButton.Name = "stocksUpdateToolStripButton";
            this.stocksUpdateToolStripButton.Size = new System.Drawing.Size(85, 72);
            this.stocksUpdateToolStripButton.Text = "Stock Update";
            this.stocksUpdateToolStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.stocksUpdateToolStripButton.Click += new System.EventHandler(this.stocksInToolStripButton_Click);
            // 
            // StatusStrip1
            // 
            this.StatusStrip1.BackColor = System.Drawing.SystemColors.Info;
            this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.activeUserToolStripStatusLabel,
            this.loggedInUserLabel,
            this.dateToolStripStatusLabel,
            this.dateLabel,
            this.timeToolStripStatusLabel,
            this.timeLabel});
            this.StatusStrip1.Location = new System.Drawing.Point(0, 655);
            this.StatusStrip1.Name = "StatusStrip1";
            this.StatusStrip1.Size = new System.Drawing.Size(886, 22);
            this.StatusStrip1.TabIndex = 16;
            this.StatusStrip1.Text = "StatusStrip1";
            // 
            // activeUserToolStripStatusLabel
            // 
            this.activeUserToolStripStatusLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activeUserToolStripStatusLabel.Name = "activeUserToolStripStatusLabel";
            this.activeUserToolStripStatusLabel.Size = new System.Drawing.Size(81, 17);
            this.activeUserToolStripStatusLabel.Text = "Active User :";
            // 
            // loggedInUserLabel
            // 
            this.loggedInUserLabel.AutoSize = false;
            this.loggedInUserLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loggedInUserLabel.Name = "loggedInUserLabel";
            this.loggedInUserLabel.Size = new System.Drawing.Size(150, 17);
            this.loggedInUserLabel.Text = " ";
            this.loggedInUserLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dateToolStripStatusLabel
            // 
            this.dateToolStripStatusLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateToolStripStatusLabel.Name = "dateToolStripStatusLabel";
            this.dateToolStripStatusLabel.Size = new System.Drawing.Size(43, 17);
            this.dateToolStripStatusLabel.Text = "Date :";
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = false;
            this.dateLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(121, 17);
            this.dateLabel.Text = " mm/dd/yyyy";
            this.dateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // timeToolStripStatusLabel
            // 
            this.timeToolStripStatusLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeToolStripStatusLabel.Name = "timeToolStripStatusLabel";
            this.timeToolStripStatusLabel.Size = new System.Drawing.Size(44, 17);
            this.timeToolStripStatusLabel.Text = "Time :";
            // 
            // Timer1
            // 
            this.Timer1.Enabled = true;
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.BackColor = System.Drawing.Color.White;
            this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FileToolStripMenuItem,
            this.customersToolStripMenuItem,
            this.suppliersToolStripMenuItem,
            this.RecordToolStripMenuItem,
            this.employeesToolStripMenuItem,
            this.stocksToolStripMenuItem,
            this.editToolStripMenuItem});
            this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.Size = new System.Drawing.Size(886, 24);
            this.MenuStrip1.TabIndex = 14;
            this.MenuStrip1.Text = "MenuStrip1";
            // 
            // FileToolStripMenuItem
            // 
            this.FileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConfigurationToolStripMenuItem,
            this.backUpToolStripMenuItem,
            this.ExitToolStripMenuItem});
            this.FileToolStripMenuItem.Name = "FileToolStripMenuItem";
            this.FileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.FileToolStripMenuItem.Text = "File";
            // 
            // ConfigurationToolStripMenuItem
            // 
            this.ConfigurationToolStripMenuItem.Name = "ConfigurationToolStripMenuItem";
            this.ConfigurationToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.ConfigurationToolStripMenuItem.Text = "Configuration";
            // 
            // backUpToolStripMenuItem
            // 
            this.backUpToolStripMenuItem.Name = "backUpToolStripMenuItem";
            this.backUpToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.backUpToolStripMenuItem.Text = "Back Up";
            this.backUpToolStripMenuItem.Click += new System.EventHandler(this.backUpToolStripMenuItem_Click);
            // 
            // ExitToolStripMenuItem
            // 
            this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            this.ExitToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.ExitToolStripMenuItem.Text = "Exit";
            this.ExitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);
            // 
            // customersToolStripMenuItem
            // 
            this.customersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewCustomerToolStripMenuItem,
            this.customerListToolStripMenuItem});
            this.customersToolStripMenuItem.Name = "customersToolStripMenuItem";
            this.customersToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.customersToolStripMenuItem.Text = "Customers";
            // 
            // addNewCustomerToolStripMenuItem
            // 
            this.addNewCustomerToolStripMenuItem.Name = "addNewCustomerToolStripMenuItem";
            this.addNewCustomerToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.addNewCustomerToolStripMenuItem.Text = "Add New Customer";
            this.addNewCustomerToolStripMenuItem.Click += new System.EventHandler(this.addNewCustomerToolStripMenuItem_Click_1);
            // 
            // customerListToolStripMenuItem
            // 
            this.customerListToolStripMenuItem.Name = "customerListToolStripMenuItem";
            this.customerListToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.customerListToolStripMenuItem.Text = "Customer List";
            // 
            // suppliersToolStripMenuItem
            // 
            this.suppliersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewSuppliersToolStripMenuItem});
            this.suppliersToolStripMenuItem.Name = "suppliersToolStripMenuItem";
            this.suppliersToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.suppliersToolStripMenuItem.Text = "Suppliers";
            // 
            // addNewSuppliersToolStripMenuItem
            // 
            this.addNewSuppliersToolStripMenuItem.Name = "addNewSuppliersToolStripMenuItem";
            this.addNewSuppliersToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.addNewSuppliersToolStripMenuItem.Text = "Add New Supplier";
            this.addNewSuppliersToolStripMenuItem.Click += new System.EventHandler(this.addNewSuppliersToolStripMenuItem_Click);
            // 
            // RecordToolStripMenuItem
            // 
            this.RecordToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewProductToolStripMenuItem,
            this.productListToolStripMenuItem});
            this.RecordToolStripMenuItem.Name = "RecordToolStripMenuItem";
            this.RecordToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.RecordToolStripMenuItem.Text = "Products";
            // 
            // addNewProductToolStripMenuItem
            // 
            this.addNewProductToolStripMenuItem.Name = "addNewProductToolStripMenuItem";
            this.addNewProductToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.addNewProductToolStripMenuItem.Text = "Add New Product";
            this.addNewProductToolStripMenuItem.Click += new System.EventHandler(this.addNewProductToolStripMenuItem_Click);
            // 
            // productListToolStripMenuItem
            // 
            this.productListToolStripMenuItem.Name = "productListToolStripMenuItem";
            this.productListToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.productListToolStripMenuItem.Text = "Product List";
            this.productListToolStripMenuItem.Click += new System.EventHandler(this.productListToolStripMenuItem_Click);
            // 
            // employeesToolStripMenuItem
            // 
            this.employeesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewEmployeesToolStripMenuItem,
            this.employeeListToolStripMenuItem});
            this.employeesToolStripMenuItem.Name = "employeesToolStripMenuItem";
            this.employeesToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.employeesToolStripMenuItem.Text = "Employees";
            // 
            // addNewEmployeesToolStripMenuItem
            // 
            this.addNewEmployeesToolStripMenuItem.Name = "addNewEmployeesToolStripMenuItem";
            this.addNewEmployeesToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.addNewEmployeesToolStripMenuItem.Text = "Add New Employees";
            this.addNewEmployeesToolStripMenuItem.Click += new System.EventHandler(this.addNewEmployeesToolStripMenuItem_Click);
            // 
            // employeeListToolStripMenuItem
            // 
            this.employeeListToolStripMenuItem.Name = "employeeListToolStripMenuItem";
            this.employeeListToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.employeeListToolStripMenuItem.Text = "Employee List";
            this.employeeListToolStripMenuItem.Click += new System.EventHandler(this.employeeListToolStripMenuItem_Click);
            // 
            // stocksToolStripMenuItem
            // 
            this.stocksToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stocksUpdateToolStripMenuItem,
            this.stocksOutListToolStripMenuItem});
            this.stocksToolStripMenuItem.Name = "stocksToolStripMenuItem";
            this.stocksToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.stocksToolStripMenuItem.Text = "Stocks";
            // 
            // stocksUpdateToolStripMenuItem
            // 
            this.stocksUpdateToolStripMenuItem.Name = "stocksUpdateToolStripMenuItem";
            this.stocksUpdateToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.stocksUpdateToolStripMenuItem.Text = "Stocks Update";
            this.stocksUpdateToolStripMenuItem.Click += new System.EventHandler(this.stocksUpdateToolStripMenuItem_Click);
            // 
            // stocksOutListToolStripMenuItem
            // 
            this.stocksOutListToolStripMenuItem.Name = "stocksOutListToolStripMenuItem";
            this.stocksOutListToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.stocksOutListToolStripMenuItem.Text = "Stocks Out List";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usersPasswordToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // usersPasswordToolStripMenuItem
            // 
            this.usersPasswordToolStripMenuItem.Name = "usersPasswordToolStripMenuItem";
            this.usersPasswordToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.usersPasswordToolStripMenuItem.Text = "User\'s Password";
            this.usersPasswordToolStripMenuItem.Click += new System.EventHandler(this.usersPasswordToolStripMenuItem_Click);
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabControl.Location = new System.Drawing.Point(0, 102);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(886, 550);
            this.tabControl.TabIndex = 17;
            this.tabControl.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl_DrawItem);
            this.tabControl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tabControl_MouseDown);
            // 
            // AdminMainHomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(886, 677);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.ToolStrip);
            this.Controls.Add(this.StatusStrip1);
            this.Controls.Add(this.MenuStrip1);
            this.Name = "AdminMainHomeForm";
            this.Text = "Inventory Management System With POS";
            this.Load += new System.EventHandler(this.MainHomeForm_Load);
            this.ToolStrip.ResumeLayout(false);
            this.ToolStrip.PerformLayout();
            this.StatusStrip1.ResumeLayout(false);
            this.StatusStrip1.PerformLayout();
            this.MenuStrip1.ResumeLayout(false);
            this.MenuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.ToolStripStatusLabel timeLabel;
        internal System.Windows.Forms.ToolStrip ToolStrip;
        internal System.Windows.Forms.ToolStripButton staffToolStripButton;
        internal System.Windows.Forms.ToolStripButton categoryToolStripButton;
        internal System.Windows.Forms.ToolStripButton productsListToolStripButton;
        internal System.Windows.Forms.ToolStripButton posToolStripButton;
        internal System.Windows.Forms.ToolStripButton stocksUpdateToolStripButton;
        internal System.Windows.Forms.StatusStrip StatusStrip1;
        internal System.Windows.Forms.ToolStripStatusLabel activeUserToolStripStatusLabel;
        internal System.Windows.Forms.ToolStripStatusLabel loggedInUserLabel;
        internal System.Windows.Forms.ToolStripStatusLabel dateToolStripStatusLabel;
        internal System.Windows.Forms.ToolStripStatusLabel dateLabel;
        internal System.Windows.Forms.ToolStripStatusLabel timeToolStripStatusLabel;
        internal System.Windows.Forms.Timer Timer1;
        internal System.Windows.Forms.MenuStrip MenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem FileToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ConfigurationToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem RecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productListToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.ToolStripMenuItem addNewProductToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usersPasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stocksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stocksUpdateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stocksOutListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suppliersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewSuppliersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backUpToolStripMenuItem;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.ToolStripMenuItem customersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewEmployeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeListToolStripMenuItem;
    }
}