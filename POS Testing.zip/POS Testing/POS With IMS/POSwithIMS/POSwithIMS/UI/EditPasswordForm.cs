﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS.UI
{
    public partial class EditPasswordForm : Form
    {
        EmployeeGateway userGateway = new EmployeeGateway();

        public UserInfo loggedInUserInfo = null;

        public EditPasswordForm(UserInfo userInfo)
        {
            loggedInUserInfo = userInfo;
            
            InitializeComponent();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            string result = "";

            UserInfo userInfo = null;

            string userName = userNameTextBox.Text;
            string currentPassword = currentPasswordTextBox.Text;
            string newPassword = newPasswordTextBox.Text;
            string confirmPassword = confirmPasswordTextBox.Text;

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("New password doesn't match. Confirm new password.");
            }
            else
            {
                userInfo = userGateway.CheckIfUserExistsByUserNameAndPassword(userName, currentPassword);

                if (userInfo != null)
                {
                    result = userGateway.ChangeUsersPassword(userName, newPassword);
                    MessageBox.Show(result);
                }
                else
                {
                    result = "Username or password doesn't exists.";
                    MessageBox.Show(result);
                }

                ClearAll();
            }
        }

        private void showNewPasswordButton_Click(object sender, EventArgs e)
        {
            newPasswordTextBox.PasswordChar = '\0';
            confirmPasswordTextBox.PasswordChar = '\0';
        }

        private void hideNewPasswordButton_Click(object sender, EventArgs e)
        {
            newPasswordTextBox.PasswordChar = '*';
            confirmPasswordTextBox.PasswordChar = '*';
        }

        public void ClearAll()
        {
            userNameTextBox.Text = "";
            currentPasswordTextBox.Text = "";
            newPasswordTextBox.Text = "";
            confirmPasswordTextBox.Text = "";
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
