﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS
{
    public partial class EmployeeListForm : Form
    {
        EmployeeGateway userGateway = new EmployeeGateway();

        public UserInfo loggedInUserInfo = null;

        public EmployeeListForm(UserInfo userInfo)
        {
            loggedInUserInfo = userInfo;

            InitializeComponent();
        }

        public void LoadEmployeesList()
        {
            List<Employee> employeeList = userGateway.GetAllEmployees();
            
            employeesListView.Items.Clear();

            foreach (Employee value in employeeList)
            {
                ListViewItem item = new ListViewItem(value.EmployeeId);
                string fullName = value.FirstName;
                if (value.MiddleName != "")
                {
                    fullName += " " + value.MiddleName;
                }
                if (value.LastName != "")
                {
                    fullName += " " + value.LastName;
                }
                item.SubItems.Add(fullName);
                item.SubItems.Add(value.DateOfBirth);
                item.SubItems.Add(value.Gender);
                item.SubItems.Add(value.Address);
                item.SubItems.Add(value.ContactNo);
                item.SubItems.Add(value.Email);
                item.SubItems.Add(value.NID);
                item.SubItems.Add(value.UserName);
                item.SubItems.Add(value.Role);
                item.SubItems.Add(value.Password);

                employeesListView.Items.Add(item);
            }
        } 

        private void EmployeeListForm_Load(object sender, EventArgs e)
        {
            LoadEmployeesList();
        }

        private void searchToolStripTextBox_TextChanged(object sender, EventArgs e)
        {
            string searchSpecificEmployee = searchToolStripTextBox.Text;
            List<Employee> employeeList = userGateway.GetSpecificEmployee(searchSpecificEmployee);

            employeesListView.Items.Clear();

            foreach (Employee value in employeeList)
            {
                ListViewItem item = new ListViewItem(value.EmployeeId);
                string fullName = value.FirstName;
                if (value.MiddleName != "")
                {
                    fullName += " " + value.MiddleName;
                }
                if (value.LastName != "")
                {
                    fullName += " " + value.LastName;
                }
                item.SubItems.Add(fullName);
                item.SubItems.Add(value.DateOfBirth);
                item.SubItems.Add(value.Gender);
                item.SubItems.Add(value.Address);
                item.SubItems.Add(value.ContactNo);
                item.SubItems.Add(value.Email);
                item.SubItems.Add(value.NID);
                item.SubItems.Add(value.UserName);
                item.SubItems.Add(value.Role);
                item.SubItems.Add(value.Password);

                employeesListView.Items.Add(item);
            }
        }

        private void reloadToolStripButton_Click(object sender, EventArgs e)
        {
            LoadEmployeesList();
        }
    }
}
