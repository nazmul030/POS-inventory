﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS
{
    public partial class CategoryForm : Form
    {
        public UserInfo loggedInUserInfo = null;
        
        ProductsGateway productsGateway = new ProductsGateway();

        public CategoryForm(UserInfo userInfo)
        {
            InitializeComponent();

            loggedInUserInfo = userInfo;
        }


        private void CategoryForm_Load(object sender, EventArgs e)
        {
            List<string> categoryList = productsGateway.LoadCategory();
            List<CategorySubcategory> categorySubcategoryList = productsGateway.LoadCategoryWithSubcategory();

            foreach (string category in categoryList)
            {
                TreeNode treeNode = new TreeNode(category);
                treeView.Nodes.Add(treeNode);
            }

            foreach (CategorySubcategory category in categorySubcategoryList)
            {
                foreach (TreeNode treeNodes in treeView.Nodes)
                {
                    if (category.CategoryName == treeNodes.Text)
                    {
                        treeView.SelectedNode = treeNodes;
                        if (category.SubcategoryName != "")
                        {
                            if (treeView.SelectedNode.Text == category.CategoryName)
                            {
                                treeView.SelectedNode.Nodes.Add(category.SubcategoryName);
                            }
                        }
                    }
                }
            }

            categoryNameTextBox.Text = "";
        }


        public void ReloadCategoryList()
        {
            treeView.Nodes.Clear();

            List<string> categoryList = productsGateway.LoadCategory();
            List<CategorySubcategory> categorySubcategoryList = productsGateway.LoadCategoryWithSubcategory();

            foreach (string category in categoryList)
            {
                TreeNode treeNode = new TreeNode(category);
                treeView.Nodes.Add(treeNode);
            }

            foreach (CategorySubcategory category in categorySubcategoryList)
            {
                foreach (TreeNode treeNodes in treeView.Nodes)
                {
                    if (category.CategoryName == treeNodes.Text)
                    {
                        treeView.SelectedNode = treeNodes;
                        if (category.SubcategoryName != "")
                        {
                            if (treeView.SelectedNode.Text == category.CategoryName)
                            {
                                treeView.SelectedNode.Nodes.Add(category.SubcategoryName);
                            }
                        }
                    }
                }
            }

            categoryNameTextBox.Text = "";
        }

        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Parent != null && e.Node.Parent.GetType() == typeof(TreeNode))
            {
                subcategoryNameTextBox.Text = treeView.SelectedNode.Text;
                categoryNameTextBox.Text = treeView.SelectedNode.Parent.Text;
            }
            else
            {
                categoryNameTextBox.Text = treeView.SelectedNode.Text;
                subcategoryNameTextBox.Text = "";
            }
        }


        private void addCategoryButton_Click(object sender, EventArgs e)
        {
            string result = "";

            string newCategoryName = categoryNameTextBox.Text;
            
            string newCategoryCode = "CC-";
            string code = "";
            code += newCategoryName[0];
            for (int i = 1; i < newCategoryName.Length; i++)
            {
                if (newCategoryName[i - 1] == ' ')
                {
                    code += newCategoryName[i];
                }    
            }
            newCategoryCode += code;
            //newCategoryCode.Split(' ').ToList().ForEach(i => Console.Write(i[0] + " "));
            newCategoryCode.ToUpper();

            if (newCategoryName == null && newCategoryCode == null)
            {
                MessageBox.Show("Please first write the name of the category you want to add.");
            }
            else
            {
                bool isCategoryExists = productsGateway.IsCategoryExists(newCategoryName);
                if (isCategoryExists == true)
                {
                    MessageBox.Show("Category already exists.");
                }
                else
                {
                    DialogResult dr = MessageBox.Show("Do you want to add new category?", "Confirm it.", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                    if (dr == DialogResult.Yes)
                    {
                        result = productsGateway.AddNewCategory(newCategoryCode,newCategoryName);
                        MessageBox.Show(result);
                    }    
                }
            }
            categoryNameTextBox.Text = null;
            ReloadCategoryList();
        }


        private void removeCategoryButton_Click(object sender, EventArgs e)
        {
            string result = "";

            string categoryName = categoryNameTextBox.Text;
            string categoryCode = productsGateway.GetCategoryCodeByCategoryName(categoryName);
            if (categoryName == null)
            {
                MessageBox.Show("Please first select the category you want to delete.");
            }
            else
            {
                bool isCategoryExists = productsGateway.IsCategoryExists(categoryName);
                if (isCategoryExists == false)
                {
                    MessageBox.Show("Category does not exists.");
                }
                else
                {
                    DialogResult dr = MessageBox.Show("Do you want to delete this category?", "Confirm it.", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                    if (dr == DialogResult.Yes)
                    {
                        result = productsGateway.DeleteCategory(categoryCode,categoryName);
                        MessageBox.Show(result);
                    }
                }
            }
            categoryNameTextBox.Text = null;
            ReloadCategoryList();
        }

        private void addSubcategoryButton_Click(object sender, EventArgs e)
        {
            string result = "";
            string categoryName = categoryNameTextBox.Text;
            string categoryCode = productsGateway.GetCategoryCodeByCategoryName(categoryName);
            string newSubcategoryName = subcategoryNameTextBox.Text;

            string code = "";
            for (int i = 1; i < categoryCode.Length; i++)
            {
                if (categoryCode[i - 1] == '-')
                {
                    for (int j = i; j < categoryCode.Length; j++)
                    {
                        code += categoryCode[j];
                    }
                }
            }

            string newSubcategoryCode = "";
            newSubcategoryCode += code;
            code = "";
            
            for (int i = 1; i < newSubcategoryName.Length; i++)
            {
                if (newSubcategoryName[i - 1] == ' ')
                {
                    code += newSubcategoryName[i];
                }
            }

            newSubcategoryCode += code;

            //newSubcategoryCode.Split(' ').ToList().ForEach(i => Console.Write(i[0] + " "));
            newSubcategoryCode = newSubcategoryCode.ToUpper();

            if (newSubcategoryName == null && newSubcategoryCode == null)
            {
                MessageBox.Show("Please first write the name of the category you want to add.");
            }
            else
            {
                bool isSubcategoryExists = productsGateway.IsSubcategoryExists(categoryCode,newSubcategoryName);
                if (isSubcategoryExists == true)
                {
                    MessageBox.Show("Subcategory already exists.");
                }
                else
                {
                    DialogResult dr = MessageBox.Show("Do you want to add new subcategory?", "Confirm it.", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                    if (dr == DialogResult.Yes)
                    {
                        result = productsGateway.AddNewSubcategory(categoryCode, newSubcategoryCode, newSubcategoryName);
                        MessageBox.Show(result);
                    }
                }
            }
            categoryNameTextBox.Text = null;
            ReloadCategoryList();
        }


        private void removeSubcategoryButton_Click(object sender, EventArgs e)
        {
            string result = "";

            string categoryName = categoryNameTextBox.Text;
            string categoryCode = productsGateway.GetCategoryCodeByCategoryName(categoryName);
            string subcategoryName = subcategoryNameTextBox.Text;
            if (subcategoryName == null)
            {
                MessageBox.Show("Please first select the category you want to delete.");
            }
            else
            {
                bool isSubcategoryExists = productsGateway.IsSubcategoryExists(categoryCode,subcategoryName);
                if (isSubcategoryExists == false)
                {
                    MessageBox.Show("Subcategory does not exists.");
                }
                else
                {
                    DialogResult dr = MessageBox.Show("Do you want to delete this subcategory?", "Confirm it.", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                    if (dr == DialogResult.Yes)
                    {
                        result = productsGateway.DeleteSubcategory(subcategoryName);
                        MessageBox.Show(result);
                    }
                }
            }
            categoryNameTextBox.Text = null;
            ReloadCategoryList();
        }

        

    }
}
