﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSwithIMS.Core.Model
{
    public class Sales
    {
        public string InVoiceNo { get; set; }
        public string Date { get; set; }
        public string Seller { get; set; }
        public string CustomerIdName { get; set; }
        public string ContactNo { get; set; }
        public string ProductName { get; set; }
        public int UnitPrice { get; set; }
        public int PurchasedQuantity { get; set; }
        public int Ammount { get; set; }
        public string CheckNo { get; set; }
        public string BankName { get; set; }

        public Sales(string inVoiceNo, string date, string seller, string customerIdName, 
                  string productName, int unitPrice, int purchasedQuantity, int ammount, string checkNo, string bankName)
        {
            InVoiceNo = inVoiceNo;
            Date = date;
            Seller = seller;
            CustomerIdName = customerIdName;
            ProductName = productName;
            UnitPrice = unitPrice;
            PurchasedQuantity = purchasedQuantity;
            Ammount = ammount;
            CheckNo = checkNo;
            BankName = bankName;
        }


        public Sales(string inVoiceNo, string date, string seller, string customerId, string contactNo,
            string productName,
            int unitPrice, int purchasedQuantity, int ammount, string checkNo, string bankName)
            : this(inVoiceNo, date, seller,
                customerId, productName, unitPrice, purchasedQuantity, ammount, checkNo, bankName)
        {
            ContactNo = contactNo;
        }
    }
}
