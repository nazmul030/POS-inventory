﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSwithIMS.Core.Model
{
    public class PurchaseInfo
    {
        public string InVoiceNo { get; set; }
        public string Date { get; set; }
        public string Seller { get; set; }
        public string CustomerName { get; set; }
        public string ContactNo { get; set; }
        public string Address { get; set; }
        public string CheckNo { get; set; }
        public string BankName { get; set; }
        public string Discount { get; set; }
        public string TotalAmmount { get; set; }
        public string AmmountPaid { get; set; }
        public string AmmountReturned { get; set; }
        public string AmmountDue { get; set; }


        public PurchaseInfo()
        {
            
        }

        public PurchaseInfo(string inVoiceNo, string date, string seller, string customerName, string contactNo, string address, string checkNo,
            string bankName, string discount, string totalAmmount, string ammountPaid, string ammountReturned, string ammountDue)
        {
            InVoiceNo = inVoiceNo;
            Date = date;
            Seller = seller;
            CustomerName = customerName;
            ContactNo = contactNo;
            Address = address;
            CheckNo = checkNo;
            BankName = bankName;
            Discount = discount;
            TotalAmmount = totalAmmount;
            AmmountPaid = ammountPaid;
            AmmountReturned = ammountReturned;
            AmmountDue = ammountDue;
        }
    }
}
