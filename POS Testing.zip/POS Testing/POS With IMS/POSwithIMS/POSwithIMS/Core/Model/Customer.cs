﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSwithIMS.Core.Model
{
    class Customer
    {
        public string CustomerId { get; set; }

        public string CustomerName { get; set; }

        public string Address { get; set; }

        public string ContactNo1 { get; set; }

        public string ContactNo2 { get; set; }

        public string Email { get; set; }

        public double DueAmmount { get; set; }

        public Customer(string customerId, string customerName, string address, string contactNo1, string contactNo2, string email, double dueAmmount)
        {
            CustomerId = customerId;
            CustomerName = customerName;
            Address = address;
            ContactNo1 = contactNo1;
            ContactNo2 = contactNo2;
            Email = email;
            DueAmmount = dueAmmount;
        }
    }
}
