﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSwithIMS.Core.Model
{
    public class PurchasedProduct
    {
        public string ProductName { get; set; }
        public string UnitPrice { get; set; }
        public string PurchasedQuantity { get; set; }
        public string Ammount { get; set; }

        public PurchasedProduct()
        {
            
        }

        public PurchasedProduct(string productName, string unitPrice, string purchasedQuantity, string ammount)
        {
            ProductName = productName;
            UnitPrice = unitPrice;
            PurchasedQuantity = purchasedQuantity;
            Ammount = ammount;
        }

    }
}
