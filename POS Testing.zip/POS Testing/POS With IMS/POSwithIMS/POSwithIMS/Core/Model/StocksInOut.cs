﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSwithIMS.Core.Model
{
    public class StocksInOut
    {
        public string EmployeeId { get; set; }
        public string Date { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public string Subcategory { get; set; }
        public string Description { get; set; }
        public string CompanyName { get; set; }
        public int Costing { get; set; }
        public int RetailPrice { get; set; }
        public int WholeSalePrice { get; set; }
        public int StocksCameInOut { get; set; }

        public StocksInOut(string employeeId, string date, string productName, string category, string subcategory, string description, string companyName, int costing, int retailPrice, int wholeSalePrice, int stocksCameInOut)
        {
            EmployeeId = employeeId;
            Date = date;
            ProductName = productName;
            Category = category;
            Subcategory = subcategory;
            Description = description;
            CompanyName = companyName;
            Costing = costing;
            RetailPrice = retailPrice;
            WholeSalePrice = wholeSalePrice; 
            StocksCameInOut = stocksCameInOut;
        } 
    }
}
