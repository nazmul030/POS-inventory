﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSwithIMS.Core.Model
{
    public class Employee
    {
        public string EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string ContactNo { get; set; }
        public string ImagePath { get; set; }
        public string Email { get; set; }
        public string NID { get; set; }
        public string Role { get; set; }
        public string JoiningDate { get; set; }
        public int Salary { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }

        public Employee()
        {

        }

        public Employee(string employeeId, string firstName, string middleName, string lastName, string dateOfBirth, string gender, string address, string contactNo,
            string imagePath, string email, string nid, string role, string joiningDate, int salary, string userName, string password)
        {
            EmployeeId = employeeId;
            FirstName = firstName;
            MiddleName = middleName;
            LastName = lastName;
            DateOfBirth = dateOfBirth;
            Gender = gender;
            Address = address;
            ContactNo = contactNo;
            ImagePath = imagePath;
            Email = email;
            NID = nid;
            Role = role;
            JoiningDate = joiningDate;
            Salary = salary;
            UserName = userName;
            Password = password;
        }
    }
}
