﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSwithIMS.Core.Model
{
    public class CategorySubcategory
    {
        public string CategoryCode { get; set; }

        public string CategoryName { get; set; }

        public string SubcategoryCode { get; set; }

        public string SubcategoryName { get; set; }

        public CategorySubcategory()
        {

        }

        public CategorySubcategory(string categoryCode, string categoryName, string subcategoryCode, string subcategoryName)
            : this()
        {
            CategoryCode = categoryCode;
            CategoryName = categoryName;
            SubcategoryCode = subcategoryCode;
            SubcategoryName = subcategoryName;
        }
    }
}
