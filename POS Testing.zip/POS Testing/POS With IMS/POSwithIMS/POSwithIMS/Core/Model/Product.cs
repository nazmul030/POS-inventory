﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSwithIMS.Core.Model
{
    public class Product
    {
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public string Subcategory { get; set; }
        public string Description { get; set; }
        public string Supplier { get; set; }
        public string Barcode { get; set; }
        public int Costing { get; set; }
        public int RetailPrice { get; set; }
        public int WholeSalePrice { get; set; }
        public int StocksInHand { get; set; }


        public Product()
        {

        }

        public Product(string productCode, string productName, string category, string subcategory, string description, string supplier, string barcode, int costing, int retailPrice, int wholeSalePrice, int stocksInHand)
            : this()
        {
            ProductCode = productCode;
            ProductName = productName;
            Category = category;
            Subcategory = subcategory;
            Description = description;
            Supplier = supplier;
            Barcode = barcode;
            Costing = costing;
            RetailPrice = retailPrice;
            WholeSalePrice = wholeSalePrice;
            StocksInHand = stocksInHand;
        }
    }
}
