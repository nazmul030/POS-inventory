﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSwithIMS.Core.Model
{
    public class Supplier
    {
        public string SupplierId { get; set; }

        public string CompanyName { get; set; }

        public string PersonOfContact { get; set; }

        public string Address { get; set; }

        public string ContactNo1 { get; set; }

        public string ContactNo2 { get; set; }

        public string Email { get; set; }

        public double Balance { get; set; }

        public Supplier(string supplierId, string companyName, string personOfContact, string address, string contactNo1, string contactNo2, string email, double balance)
        {
            SupplierId = supplierId;
            CompanyName = companyName;
            PersonOfContact = personOfContact;
            Address = address;
            ContactNo1 = contactNo1;
            ContactNo2 = contactNo2;
            Email = email;
            Balance = balance;
        }
    }
}
