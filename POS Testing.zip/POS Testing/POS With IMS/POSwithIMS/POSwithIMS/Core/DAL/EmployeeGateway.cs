﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.Model;

namespace POSwithIMS.Core.DAL
{
    public class EmployeeGateway : DBGateWay
    {
        public UserInfo CheckIfUserExistsByUserNameAndPassword(string userName, string password)
        {
            UserInfo loggedInUserInfo = null;
            string query = @"SELECT * FROM Users WHERE UserName='" + userName + "' AND Password='" + password + "';";
            string employeeId = "";
            string userType = "";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    employeeId = reader["EmployeeId"].ToString();
                    userType = reader["UserType"].ToString();

                    loggedInUserInfo = new UserInfo(employeeId, userName, password, userType);
                }
                else
                {
                    string errorResult = "Wrong User Name and Password.";
                    MessageBox.Show(errorResult);
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot check if user exists.");
            }

            return loggedInUserInfo;
        }


        public bool CheckIfUserExistsByEmployeeId(string employeeId)
        {
            bool result = false;
            string employeesId = "";
            string query = @"SELECT * FROM Users WHERE EmployeeId='" + employeeId + "';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    employeesId = reader["EmployeeId"].ToString();
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot check if user name exists.");
            }
            if (employeesId == employeeId)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }


        public bool CheckIfUserNameExists(string userName)
        {
            bool result = false;
            string usersName = "";
            string query = @"SELECT * FROM Users WHERE UserName='" + userName + "';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    usersName = reader["UserName"].ToString();
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot check if user name exists.");
            }
            if (usersName == userName)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }


        public string GetPassword(string userName)
        {
            string result = "";

            string query = @"SELECT * FROM Users WHERE UserName='" + userName + "';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    result = reader["Password"].ToString();
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot check if user name exists.");
            }
            
            return result;
        }


        public int GetMaxEmployeeNoByUserType(string userType)
        {
            int result = 0;
            string query = @"SELECT COUNT(UserType) AS NoOfUserType FROM Users WHERE UserType='"+userType+"';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    result = Convert.ToInt32(reader["NoOfUserType"].ToString());
                }
                else
                {
                    
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database!");
            }

            return result;
        }


        public Employee GetUsersAllInfoByEmployeeId(string employeeId)
        {
            Employee employee = null;
            string query = @"SELECT * FROM Employees WHERE EmployeeId='" + employeeId + "';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    string firstName = reader["FirstName"].ToString();
                    string middleName = reader["MiddleName"].ToString();
                    string lastName = reader["LastName"].ToString();
                    string dateOfBirth = reader["DateOfBirth"].ToString();
                    string gender = reader["Gender"].ToString();
                    string address = reader["Address"].ToString();
                    string contactNo = reader["ContactNo"].ToString();
                    string imagePath = reader["ImagePath"].ToString();
                    string email = reader["Email"].ToString();
                    string nidNo = reader["NID"].ToString();
                    string postRole = reader["Role"].ToString();
                    string joiningDate = reader["JoiningDate"].ToString();
                    int salary = Convert.ToInt32(reader["Salary"].ToString());
                    string userName = reader["UserName"].ToString();
                    string password = reader["Password"].ToString();

                    employee = new Employee(employeeId, firstName, middleName, lastName, dateOfBirth, gender, address,
                        contactNo, imagePath, email, nidNo, postRole, joiningDate, salary, userName, password);
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot load user info.");
            }

            return employee;
        }


        public string CreateNewEmployee(Employee employee)
        {
            string result = "";
            int employeeRowsEffected = 0; 
            int usersRowsEffected = 0;
            
            string employeeQuery = @"INSERT INTO Employees VALUES('"+employee.EmployeeId+"','"+employee.FirstName+"','"+employee.MiddleName+"','"+employee.LastName+"','"+
                           employee.DateOfBirth+"','"+employee.Gender+"','"+employee.Address+"','"+employee.ContactNo+"','"+employee.ImagePath+"','"+
                           employee.Email+"','"+employee.NID+"','"+employee.Role+"','"+employee.JoiningDate+"','"+employee.Salary+"','"+employee.UserName+"','"+employee.Password+"');";

            string usersQuery = @"INSERT INTO Users VALUES('"+employee.EmployeeId+"','"+employee.UserName+"','"+employee.Password+"','"+employee.Role+"');";

            try
            {
                connection.Open();
                command.CommandText = employeeQuery;
                employeeRowsEffected = command.ExecuteNonQuery();

                if (employeeRowsEffected > 0)
                {
                    result = "New employee profile has been successfully created.";
                }
                else
                {
                    result = "ERROR! Could not create new employee profile.";
                }

                command.CommandText = usersQuery;
                usersRowsEffected = command.ExecuteNonQuery();
                
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot create new user.\n"+ex.ToString());
            }

            return result;
        }


        public string CreateNewUser(string employeeId, string userName, string password, string role)
        {
            string result = "";
            int employeeRowsEffected = 0;
            int usersRowsEffected = 0;

            string employeeQuery = @"UPDATE Employees SET UserName='" + userName + "', Password='" + password+ "', Role='" + role + "' WHERE EmployeeId='" + employeeId + "';";

            string usersQuery = @"INSERT INTO Users VALUES('" + employeeId + "','" + userName + "','" + password + "','" + role + "');";

            try
            {
                connection.Open();

                command.CommandText = employeeQuery;
                employeeRowsEffected = command.ExecuteNonQuery();
                if (employeeRowsEffected > 0)
                {
                    result = "New user has been successfully created.";
                }
                else
                {
                    result = "ERROR! Could not create new user.";
                }

                command.CommandText = usersQuery;
                usersRowsEffected = command.ExecuteNonQuery();

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot create new user.\n" + ex.ToString());
            }

            return result;
        }


        public string UpdateExistingUserInfo(Employee employee)
        {
            string result = "";
            int employeeRowsEffected = 0;
            int userRowsEffected = 0;
            string employeeQuery = "";
            string userQuery = @"Update Users SET UserName='" + employee.UserName + "' WHERE EmployeeId='" + employee.EmployeeId + "'";
            
            if (employee.ImagePath == null)
            {
                employeeQuery = @"UPDATE Employees SET FirstName='" + employee.FirstName + "',MiddleName='" + employee.MiddleName + "',LastName='" + employee.LastName + "',DateOfBirth='" +
                           employee.DateOfBirth + "',Gender='" + employee.Gender + "',Address='" + employee.Address + "',ContactNo='" + employee.ContactNo + "',Email='" +
                           employee.Email + "',NID='" + employee.NID + "', Role='" + employee.Role + "', JoiningDate='" + employee.JoiningDate + "', Salary='" + employee.Salary + "', UserName='" + employee.UserName + "',Password='" + employee.Password + "' WHERE EmployeeId='" + employee.EmployeeId + "'";
            }
            else
            {
                employeeQuery = @"UPDATE Employees SET FirstName='" + employee.FirstName + "',MiddleName='" + employee.MiddleName + "',LastName='" + employee.LastName + "',DateOfBirth='" +
                           employee.DateOfBirth + "',Gender='" + employee.Gender + "',Address='" + employee.Address + "',ContactNo='" + employee.ContactNo + "',ImagePath='" + employee.ImagePath + "'," +
                           "Email='" + employee.Email + "',NID='" + employee.NID + "', Role='" + employee.Role + "', JoiningDate='" + employee.JoiningDate + "', Salary='" + employee.Salary + "', UserName='" + employee.UserName + "',Password='" + employee.Password + "' WHERE EmployeeId='" + employee.EmployeeId + "'";
            }

            try
            {
                connection.Open();
                command.CommandText = employeeQuery;
                employeeRowsEffected = command.ExecuteNonQuery();
                command.CommandText = userQuery;
                userRowsEffected = command.ExecuteNonQuery();
                if (employeeRowsEffected > 0 && userRowsEffected > 0)
                {
                    result = "User information has been successfully updated.";
                }
                else
                {
                    result = "ERROR! Could not update user information.";
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot update user information.");
            }

            return result;
        }

        public string ChangeUsersPassword(string userName, string newPassword)
        {
            string result = "";
            int employeesRowsEffected = 0;
            int usersRowsEffected = 0;

            string employeesQuery = @"UPDATE Employees SET Password='" + newPassword + "' WHERE UserName = '" + userName + "'";
            string usersQuery = @"UPDATE Users SET Password='" + newPassword + "' WHERE UserName = '" + userName + "'";

            try
            {
                connection.Open();
                
                command.CommandText = employeesQuery;
                employeesRowsEffected = command.ExecuteNonQuery();

                command.CommandText = usersQuery;
                usersRowsEffected = command.ExecuteNonQuery();

                connection.Close();

                if (employeesRowsEffected > 0 && usersRowsEffected > 0)
                {
                    result = "'" + userName + "' user's password has been successfully changed.";
                }
                else
                {
                    result = "ERROR! Could not change '" + userName + "' user's password.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot change '" + userName + "' user's password.\n" + ex.ToString());
            }

            return result;
        }

        
        public List<Employee> GetAllEmployees()
        {
            List<Employee> employeeList = new List<Employee>();

            string query = @"SELECT * FROM Employees Order By Id ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string employeeId = reader["EmployeeId"].ToString();
                        string firstName = reader["FirstName"].ToString();
                        string middleName = reader["MiddleName"].ToString();
                        string lastName = reader["LastName"].ToString();
                        string dateOfBirth = reader["DateOfBirth"].ToString();
                        string gender = reader["Gender"].ToString();
                        string address = reader["Address"].ToString();
                        string contactNo = reader["ContactNo"].ToString();
                        string imagePath = reader["ImagePath"].ToString();
                        string email = reader["Email"].ToString();
                        string nidNo = reader["NID"].ToString();
                        string postRole = reader["Role"].ToString();
                        string joiningDate = reader["JoiningDate"].ToString();
                        int salary = Convert.ToInt32(reader["Salary"].ToString());
                        string userName = reader["UserName"].ToString();
                        string password = reader["Password"].ToString();

                        Employee employee = new Employee(employeeId, firstName, middleName, lastName, dateOfBirth, gender,
                                            address, contactNo, imagePath, email, nidNo, postRole, joiningDate, salary, userName, password);

                        employeeList.Add(employee);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot load employee list.");
            }

            return employeeList;
        }


        public List<Employee> GetSpecificEmployee(string searchThisEmployee)
        {
            List<Employee> employeeList = new List<Employee>();

            string query = @"SELECT * FROM Employees WHERE FirstName LIKE '%" + searchThisEmployee + "%' Order By Id ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string employeeId = reader["EmployeeId"].ToString();
                        string firstName = reader["FirstName"].ToString();
                        string middleName = reader["MiddleName"].ToString();
                        string lastName = reader["LastName"].ToString();
                        string dateOfBirth = reader["DateOfBirth"].ToString();
                        string gender = reader["Gender"].ToString();
                        string address = reader["Address"].ToString();
                        string contactNo = reader["ContactNo"].ToString();
                        string imagePath = reader["ImagePath"].ToString();
                        string email = reader["Email"].ToString();
                        string nidNo = reader["NID"].ToString();
                        string postRole = reader["Role"].ToString();
                        string joiningDate = reader["JoiningDate"].ToString();
                        int salary = Convert.ToInt32(reader["Salary"].ToString());
                        string userName = reader["UserName"].ToString();
                        string password = reader["Password"].ToString();

                        Employee employee = new Employee(employeeId, firstName, middleName, lastName, dateOfBirth, gender,
                                            address, contactNo, imagePath, email, nidNo, postRole, joiningDate, salary, userName, password);

                        employeeList.Add(employee);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot load employee list.");
            }

            return employeeList;
        }  
    }
}
