﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.Model;

namespace POSwithIMS.Core.DAL
{
    public class ProductsGateway:DBGateWay
    {
        public bool IsCategoryExists(string categoryName)
        {
            string query = @"SELECT * FROM Category WHERE CategoryName='" + categoryName + "';";
            command.CommandText = query;
            bool result = false;

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    result = true;
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not check if product exists.");
            }

            return result;
        }

        public bool IsSubcategoryExists(string categoryCode, string subcategoryName)
        {
            string query = @"SELECT * FROM SubCategory WHERE CategoryCode='"+categoryCode+"' AND SubCategoryName='" + subcategoryName + "';";
            command.CommandText = query;
            bool result = false;

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    result = true;
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not check if product exists.");
            }

            return result;
        }
        
        public List<string> LoadCategory()
        {
            string query = @"SELECT * FROM Category Order By CategoryName ASC";
            command.CommandText = query;
            List<string> result = new List<string>();

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result.Add(reader["CategoryName"].ToString());
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not load category.");
            }

            return result;
        }

        public List<string> GetSubcategoriesByCategoryCode(string selectedCategoryCode)
        {
            string query = @"SELECT * FROM SubCategory WHERE CategoryCode='" + selectedCategoryCode + "' Order By SubCategoryName ASC";
            command.CommandText = query;
            List<string> result = new List<string>();

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result.Add(reader["SubCategoryName"].ToString());
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not load category.");
            }

            return result;
        }


        public string GetCategoryCodeByCategoryName(string categoryName)
        {
            string query = @"SELECT * FROM Category WHERE CategoryName = '" + categoryName + "'";

            string categoryCode = "";

            command.CommandText = query;
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        categoryCode = reader["CategoryCode"].ToString();
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not load category code.");
            }

            return categoryCode;
        }


        public List<CategorySubcategory> LoadCategoryWithSubcategory()
        {
            string query = @"SELECT Category.CategoryCode, Category.CategoryName, SubCategory.SubCategoryCode, 
                            SubCategory.SubCategoryName From Category LEFT OUTER JOIN SubCategory 
                            ON Category.CategoryCode = SubCategory.CategoryCode Order By Category.CategoryName ASC;";

            command.CommandText = query;
            List<CategorySubcategory> result = new List<CategorySubcategory>();

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string categoryCode = reader["CategoryCode"].ToString();
                        string categoryName = reader["CategoryName"].ToString();
                        string subcategoryCode = reader["SubcategoryCode"].ToString();
                        string subcategoryName = reader["SubcategoryName"].ToString();

                        CategorySubcategory categorySubcategory = new CategorySubcategory(categoryCode, categoryName,
                            subcategoryCode, subcategoryName);

                        result.Add(categorySubcategory);
                    }
                }
                else
                {
                    MessageBox.Show("Cannot read row.");
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not load category.");
            }

            return result;
        }

        public string AddNewCategory(string newCategoryCode, string categoryName)
        {
            string result = "";
            string query = @"INSERT INTO Category VALUES('" + newCategoryCode + "', '" + categoryName + "');";
            int isRowsEffected = 0;
            command.CommandText = query;

            try
            {
                connection.Open();
                isRowsEffected = command.ExecuteNonQuery();
                connection.Close();

                if (isRowsEffected > 0)
                {
                    result = "'" + categoryName + "' has been successfully added to the category list.";
                }
                else
                {
                    result = "Error! Couldn't add '" + categoryName + "' to the category list.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not add new category.");
            }

            return result;
        }


        public string AddNewSubcategory(string categoryCode, string newSubcategoryCode, string newSubcategoryName)
        {
            string result = "";
            string query = @"INSERT INTO SubCategory VALUES('" + categoryCode + "', '" + newSubcategoryCode + "', '" + newSubcategoryName + "');";
            int isRowsEffected = 0;
            command.CommandText = query;

            try
            {
                connection.Open();
                isRowsEffected = command.ExecuteNonQuery();
                connection.Close();

                if (isRowsEffected > 0)
                {
                    result = "'" + newSubcategoryName + "' has been successfully added to the category list.";
                }
                else
                {
                    result = "Error! Couldn't add '" + newSubcategoryName + "' to the category list.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not add new subcategory.");
            }

            return result;
        }
        

        public string DeleteCategory(string categoryCode, string categoryName)
        {
            string result = "";
            
            string categoryQuery = @"DELETE FROM Category WHERE CategoryName='" + categoryName + "';";
            string subcategoryQuery = @"DELETE FROM SubCategory WHERE CategoryCode='" + categoryCode + "';";
            
            int isCategoryRowsEffected = 0;
            int isSubcategoryRowsEffected = 0;
            
            command.CommandText = categoryQuery;

            try
            {
                connection.Open();
                
                isCategoryRowsEffected = command.ExecuteNonQuery();

                command.CommandText = subcategoryQuery;
                isSubcategoryRowsEffected = command.ExecuteNonQuery();

                connection.Close();

                if (isCategoryRowsEffected > 0 && isSubcategoryRowsEffected > 0)
                {
                    result = "'" + categoryName + "' has been successfully deleted from the category list.";
                }
                else
                {
                    result = "Error! Couldn't delete '" + categoryName + "' from the category list.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not delete category.");
            }

            return result;
        }


        public string DeleteSubcategory(string subcategoryName)
        {
            string result = "";
            string query = @"DELETE FROM SubCategory WHERE SubCategoryName='" + subcategoryName + "';";
            int isRowsEffected = 0;
            command.CommandText = query;

            try
            {
                connection.Open();
                isRowsEffected = command.ExecuteNonQuery();
                connection.Close();

                if (isRowsEffected > 0)
                {
                    result = "'" + subcategoryName + "' has been successfully deleted from the category list.";
                }
                else
                {
                    result = "Error! Couldn't delete '" + subcategoryName + "' from the category list.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not delete category.");
            }

            return result;
        }


        public bool IsProductExists(Product aProduct)
        {
            bool result = false;
            string query = @"SELECT * FROM Products WHERE ProductCode='" + aProduct.ProductCode + "' AND ProductName='" + aProduct.ProductName + "' AND Category='" + aProduct.Category + "'";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    result = true;
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not check if product exists.");
            }

            return result;
        }

        public string AddProduct(Product aProduct)
        {
            string result = "";
            int isRowsEffected = 0;
            string query = @"INSERT INTO Products VALUES('" + aProduct.ProductCode + "', '" + aProduct.ProductName + "', '" + aProduct.Category + "', '" + 
                           aProduct.Subcategory + "', '" + aProduct.Description + "', '" + aProduct.Supplier + "', '" + aProduct.Barcode + "', '" + aProduct.Costing + 
                           "', '" + aProduct.RetailPrice + "', '" + aProduct.WholeSalePrice + "', '" + aProduct.StocksInHand + "')";

            try
            {
                connection.Open();
                command.CommandText = query;
                isRowsEffected = command.ExecuteNonQuery();
                connection.Close();

                if (isRowsEffected > 0)
                {
                    result = "New product has been successfully added!";
                }
                else
                {
                    result = "ERROR occured! Couldn't add new product!";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not add new product.");
            }

            return result;
        }


        public string UpdateExistingProduct(Product aProduct, string newProductCode)
        {
            string result = "";
            int isRowsEffected = 0;
            string query = @"UPDATE Products SET ProductCode='" + newProductCode + "', ProductName='" +
                           aProduct.ProductName + "', Category='" + aProduct.Category + "', SubCategory='" + aProduct.Subcategory +
                           "', Description='" + aProduct.Description + "', Supplier='" + aProduct.Supplier + "', Barcode='" + aProduct.Barcode + "', Costing='" + aProduct.Costing + "', RetailPrice='" +
                           aProduct.RetailPrice + "', WholeSalePrice='" + aProduct.WholeSalePrice + "' WHERE ProductCode='" + aProduct.ProductCode + "';";

            try
            {
                connection.Open();
                command.CommandText = query;
                isRowsEffected = command.ExecuteNonQuery();
                connection.Close();

                if (isRowsEffected > 0)
                {
                    result = "Product has been successfully updated!";
                }
                else
                {
                    result = "ERROR occured! Couldn't update product!";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not update existing product.");
            }

            return result;
        }

        public string DeleteExistingProduct(string productCode)
        {
            string result = "";
            string query = @"DELETE FROM Products WHERE ProductCode='" + productCode + "';";
            int isRowsEffected = 0;

            try
            {
                connection.Open();
                command.CommandText = query;
                isRowsEffected = command.ExecuteNonQuery();
                connection.Close();

                if (isRowsEffected > 0)
                {
                    result = "Product with product code='" + productCode + "' has been successfully deleted.";
                }
                else
                {
                    result = "Error occured! Couldn't delete product with product code='" + productCode + "'";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not delete existing product.");
            }

            return result;
        }

        public string SingleStockInUpdate(Product aProduct, UserInfo userInfo, string date)
        {
            string result = "";
            int isRowsEffectedInProducts = 0;
            int isRowsEffectedInStocksIn = 0;
            string productQuery = @"UPDATE Products SET StocksInHand+='" + aProduct.StocksInHand + "' WHERE ProductCode='" + aProduct.ProductCode + "' AND ProductName='" + aProduct.ProductName + "'";
            string stocksInQuery = @"INSERT INTO StocksIn VALUES('" + userInfo.EmployeeId + "','" + date + "','" + aProduct.ProductCode + "','" + aProduct.Supplier + "','" + aProduct.Costing + "','" + aProduct.StocksInHand + "');";

            try
            {
                connection.Open();
                command.CommandText = productQuery;
                isRowsEffectedInProducts = command.ExecuteNonQuery();

                command.CommandText = stocksInQuery;
                isRowsEffectedInStocksIn = command.ExecuteNonQuery();
                connection.Close();

                if (isRowsEffectedInProducts > 0)
                {
                    result = "Product stock has been successfully updated!";
                }
                else
                {
                    result = "ERROR occured! Couldn't update product information!";
                }
                if (isRowsEffectedInStocksIn > 0)
                {
                    result += " Stocks In info has been successfully updated!";
                }
                else
                {
                    result += " ERROR occured! Couldn't update Stocks In information!";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not update stocks in.");
            }

            return result;
        }


        public string MultipleStocksInUpdate(DataTable productTable, UserInfo userInfo, string date)
        {
            string result = "";
            int isRowsEffectedInProducts = 0;
            int isRowsEffectedInStocksIn = 0;
            string productQuery = "";
            string stocksInQuery = "";
            string checkQuery = "";

            try
            {
                connection.Open();
                foreach (DataRow rows in productTable.Rows)
                {
                    checkQuery = @"SELECT * FROM Products WHERE ProductCode='" + rows["ProductCode"] + "';";
                    command.CommandText = checkQuery;
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Close();

                        productQuery = @"UPDATE Products SET StocksInHand+=" + rows["StocksInHand"] + " WHERE ProductCode='" + 
                                       rows["ProductCode"] + "';";
                        command.CommandText = productQuery;
                        isRowsEffectedInProducts = command.ExecuteNonQuery();
                        if (isRowsEffectedInProducts == 0)
                        {
                            result = "Error! Could not update Products.";
                            break;
                        }

                        stocksInQuery = @"INSERT INTO StocksIn VALUES('" + userInfo.EmployeeId + "','" + date + "','" +
                                        rows["ProductCode"] + "','" + rows["Supplier"] + "','" + rows["Costing"] + "','" + rows["StocksInHand"] + "');";
                        command.CommandText = stocksInQuery;
                        isRowsEffectedInStocksIn = command.ExecuteNonQuery();
                        if (isRowsEffectedInStocksIn == 0)
                        {
                            result = "Error! Could not update Stocks In.";
                            break;
                        }
                    }
                    else
                    {
                        reader.Close();

                        productQuery = @"INSERT INTO Products VALUES('" + rows["ProductCode"] + "', '" + rows["ProductName"] + "', '" + 
                                       rows["Category"] + "', '" + rows["SubCategory"] + "', '" + rows["Description"] + "', '" + rows["Costing"] + 
                                       "','" + rows["RetailPrice"] + "', WholeSalePrice='" + rows["WholeSalePrice"] + "', '" + rows["StocksInHand"] + "');";
                        command.CommandText = productQuery;
                        isRowsEffectedInProducts = command.ExecuteNonQuery();
                        if (isRowsEffectedInProducts == 0)
                        {
                            result = "Error! Could not insert Products.";
                            break;
                        }

                        stocksInQuery = @"INSERT INTO StocksIn VALUES('" + userInfo.EmployeeId + "','" + date + "','" + rows["ProductCode"] + "','" + rows["Supplier"] + "','" + rows["Costing"] + "','" + rows["StocksInHand"] + "');";
                        command.CommandText = stocksInQuery;
                        isRowsEffectedInStocksIn = command.ExecuteNonQuery();
                        if (isRowsEffectedInStocksIn == 0)
                        {
                            result = "Error! Could not update Stocks In.";
                            break;
                        }
                    }
                }
                connection.Close();

                if (isRowsEffectedInProducts > 0)
                {
                    result = "Product stock has been successfully updated!";
                }

                if (isRowsEffectedInStocksIn > 0)
                {
                    result += " Stocks In info has been successfully updated!";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not update stocks in.");
            }

            return result;
        }


        public string SingleStockOutUpdate(Product aProduct, UserInfo userInfo, string date)
        {
            string result = "";
            int isRowsEffectedInProducts = 0;
            int isRowsEffectedInStocksOut = 0;
            int stockInHand;
            string checkQuery = @"SELECT * FROM Products WHERE ProductCode='" + aProduct.ProductCode + "' AND ProductName='" + aProduct.ProductName + "';";
            string productQuery = @"UPDATE Products SET StocksInHand-='" + aProduct.StocksInHand + "' WHERE ProductCode='" + aProduct.ProductCode + "' AND ProductName='" + aProduct.ProductName + "'";
            string stocksOutQuery = @"INSERT INTO StocksOut VALUES('" + userInfo.EmployeeId + "','" + date + "','" + aProduct.ProductCode + "','" + aProduct.Supplier + "','" + aProduct.Costing + "','" + aProduct.StocksInHand + "');";

            try
            {
                connection.Open();
                command.CommandText = checkQuery;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    stockInHand = Convert.ToInt32(reader["StocksInHand"]);
                    reader.Close();
                    if (stockInHand > aProduct.StocksInHand)
                    {
                        command.CommandText = productQuery;
                        isRowsEffectedInProducts = command.ExecuteNonQuery();
                        command.CommandText = stocksOutQuery;
                        isRowsEffectedInStocksOut = command.ExecuteNonQuery();

                    }
                    else
                    {
                        result = aProduct.ProductCode + " - " + aProduct.ProductName + " is less in stock.";
                    }
                }
                reader.Close();
                connection.Close();

                if (isRowsEffectedInProducts > 0)
                {
                    result = "Product stock has been successfully updated!";
                }
                else
                {
                    result = "ERROR occured! Couldn't update product information!";
                }
                if (isRowsEffectedInStocksOut > 0)
                {
                    result += " Stocks out info has been successfully updated!";
                }
                else
                {
                    result += " ERROR occured! Couldn't update Stocks out information!";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not update stocks out.");    
            }

            return result;
        }


        public string MultipleStocksOutUpdate(DataTable productTable, UserInfo userInfo, string date)
        {
            string result = "";
            int isRowsEffectedInProducts = 0;
            int isRowsEffectedInStocksOut = 0;
            string productQuery = "";
            string stocksOutQuery = "";
            string checkQuery = "";
            string checkResult = "";
            int stocksInHand;

            try
            {
                connection.Open();
                foreach (DataRow rows in productTable.Rows)
                {
                    checkQuery = @"SELECT * FROM Products WHERE ProductCode='" + rows["ProductCode"] + "';";
                    command.CommandText = checkQuery;
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        stocksInHand = Convert.ToInt32(reader["StocksInHand"]);
                        reader.Close();
                        if (stocksInHand > Convert.ToInt32(rows["StocksInHand"]))
                        {
                            productQuery = @"UPDATE Products SET StocksInHand-=" + rows["StocksInHand"] +
                                           " WHERE ProductCode='" + rows["ProductCode"] + "';";
                            command.CommandText = productQuery;
                            isRowsEffectedInProducts = command.ExecuteNonQuery();

                            stocksOutQuery = @"INSERT INTO StocksOut VALUES('" + userInfo.EmployeeId + "','" + date + "','" + rows["ProductCode"] + "','" + rows["Supplier"] + "','" + rows["StocksInHand"] + "');";
                            command.CommandText = stocksOutQuery;
                            isRowsEffectedInStocksOut = command.ExecuteNonQuery();
                            if (isRowsEffectedInProducts == 0)
                            {
                                result = "Error! Could not update Products.";
                                break;
                            }
                        }
                        else
                        {
                            checkResult = rows["ProductCode"] + " - " + rows["ProductName"] + " is less in stock.";
                            MessageBox.Show(checkResult);
                            checkResult = "";
                        }
                        reader.Close();
                    }
                    else
                    {
                        checkResult += rows["ProductCode"] + " - " + rows["ProductName"] + " is not in the stock.\n";
                    }
                }
                connection.Close();

                if (checkResult != "")
                {
                    MessageBox.Show(checkResult);
                }

                if (isRowsEffectedInProducts > 0)
                {
                    result = "Product stock has been successfully updated!";
                }

                if (isRowsEffectedInStocksOut > 0)
                {
                    result += " Stocks out info has been successfully updated!";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not update stocks out.");    
            }

            return result;
        }

        public Product GetProductByProductCode(string productCode)
        {
            string query = @"SELECT * FROM Products WHERE ProductCode='"+productCode+"'";
            string result = "";
            Product product = new Product();
            
            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string productName = reader["ProductName"].ToString();
                        string category = reader["Category"].ToString();
                        string subcategory = reader["SubCategory"].ToString();
                        string description = reader["Description"].ToString();
                        string supplier = reader["Supplier"].ToString();
                        string barcode = reader["Barcode"].ToString();
                        int costing = Convert.ToInt32(reader["Costing"].ToString());
                        int retailPrice = Convert.ToInt32(reader["RetailPrice"].ToString());
                        int wholeSalePrice = Convert.ToInt32(reader["WholeSalePrice"].ToString());
                        int stocksInHand = Convert.ToInt32(reader["StocksInHand"].ToString());

                        product = new Product(productCode, productName, category, subcategory, description, supplier,
                                          barcode, costing, retailPrice, wholeSalePrice, stocksInHand);
                    }
                }
                else
                {
                    result = "Product with '" + productCode + "' product code does not exsits.";
                    MessageBox.Show(result);
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get product info by product code.");
            }

            return product;
        }


        public Product GetProductByProductName(string productName)
        {
            string query = @"SELECT * FROM Products WHERE ProductName='" + productName + "'";
            string result = "";
            Product product = new Product();

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string productCode = reader["productCode"].ToString();
                        string category = reader["Category"].ToString();
                        string subcategory = reader["SubCategory"].ToString();
                        string description = reader["Description"].ToString();
                        string supplier = reader["Supplier"].ToString();
                        string barcode = reader["Barcode"].ToString();
                        int costing = Convert.ToInt32(reader["Costing"].ToString());
                        int retailPrice = Convert.ToInt32(reader["RetailPrice"].ToString());
                        int wholeSalePrice = Convert.ToInt32(reader["WholeSalePrice"].ToString());
                        int stocksInHand = Convert.ToInt32(reader["StocksInHand"].ToString());

                        product = new Product(productCode, productName, category, subcategory, description, supplier,
                                          barcode, costing, retailPrice, wholeSalePrice, stocksInHand);
                    }
                }
                else
                {
                    result = "Product with '" + productName + "' product name does not exsits.";
                    MessageBox.Show(result);
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get product info by product name.");
            }

            return product;
        }


        public Product GetProductByBarcode(string barcode)
        {
            string query = @"SELECT * FROM Products WHERE Barcode='" + barcode + "'";
            string result = "";
            Product product = new Product();

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string productCode = reader["productCode"].ToString();
                        string productName = reader["ProductName"].ToString();
                        string category = reader["Category"].ToString();
                        string subcategory = reader["SubCategory"].ToString();
                        string description = reader["Description"].ToString();
                        string supplier = reader["Supplier"].ToString();
                        int costing = Convert.ToInt32(reader["Costing"].ToString());
                        int retailPrice = Convert.ToInt32(reader["RetailPrice"].ToString());
                        int wholeSalePrice = Convert.ToInt32(reader["WholeSalePrice"].ToString());
                        int stocksInHand = Convert.ToInt32(reader["StocksInHand"].ToString());

                        product = new Product(productCode, productName, category, subcategory, description, supplier,
                                          barcode, costing, retailPrice, wholeSalePrice, stocksInHand);
                    }
                }
                else
                {
                    result = "Product with '" + barcode + "' barcode does not exsits.";
                    MessageBox.Show(result);
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get product info by product name.");
            }

            return product;
        }


        public List<Product> GetSpecificProduct(string searchThisProduct)
        {
            List<Product> productList = new List<Product>();
            string query = @"SELECT * FROM Products WHERE ProductName LIKE '%" + searchThisProduct + "%'";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string productCode = reader["ProductCode"].ToString();
                        string productName = reader["ProductName"].ToString();
                        string category = reader["Category"].ToString();
                        string subcategory = reader["SubCategory"].ToString();
                        string description = reader["Description"].ToString();
                        string supplier = reader["Supplier"].ToString();
                        string barcode = reader["Barcode"].ToString();
                        int costing = Convert.ToInt32(reader["Costing"].ToString());
                        int retailPrice = Convert.ToInt32(reader["RetailPrice"].ToString());
                        int wholeSalePrice = Convert.ToInt32(reader["WholeSalePrice"].ToString());
                        int stocksInHand = Convert.ToInt32(reader["StocksInHand"].ToString());

                        Product product = new Product(productCode, productName, category, subcategory, description, supplier,
                                          barcode, costing, retailPrice, wholeSalePrice, stocksInHand);
                        productList.Add(product);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get products.");    
            }

            return productList;
        }


        public List<Product> GetProductsByCategory(string selectedCategory)
        {
            List<Product> productList = new List<Product>();
            string query = @"SELECT * FROM Products WHERE Category='" + selectedCategory + "' Order By ProductName ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string productCode = reader["ProductCode"].ToString();
                        string productName = reader["ProductName"].ToString();
                        string category = reader["Category"].ToString();
                        string subcategory = reader["SubCategory"].ToString();
                        string description = reader["Description"].ToString();
                        string supplier = reader["Supplier"].ToString();
                        string barcode = reader["Barcode"].ToString();
                        int costing = Convert.ToInt32(reader["Costing"].ToString());
                        int retailPrice = Convert.ToInt32(reader["RetailPrice"].ToString());
                        int wholeSalePrice = Convert.ToInt32(reader["WholeSalePrice"].ToString());
                        int stocksInHand = Convert.ToInt32(reader["StocksInHand"].ToString());

                        Product product = new Product(productCode, productName, category, subcategory, description, supplier,
                                          barcode, costing, retailPrice, wholeSalePrice, stocksInHand);
                        productList.Add(product);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get products.");
            }

            return productList;
        }


        public List<Product> GetProductsByCategorySubcategory(string selectedCategory, string selectedSubcategory)
        {
            List<Product> productList = new List<Product>();
            string query = @"SELECT * FROM Products WHERE Category='" + selectedCategory + "' AND SubCategory='" + selectedSubcategory + "' Order By ProductName ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string productCode = reader["ProductCode"].ToString();
                        string productName = reader["ProductName"].ToString();
                        string category = reader["Category"].ToString();
                        string subcategory = reader["SubCategory"].ToString();
                        string description = reader["Description"].ToString();
                        string supplier = reader["Supplier"].ToString();
                        string barcode = reader["Barcode"].ToString();
                        int costing = Convert.ToInt32(reader["Costing"].ToString());
                        int retailPrice = Convert.ToInt32(reader["RetailPrice"].ToString());
                        int wholeSalePrice = Convert.ToInt32(reader["WholeSalePrice"].ToString());
                        int stocksInHand = Convert.ToInt32(reader["StocksInHand"].ToString());

                        Product product = new Product(productCode, productName, category, subcategory, description, supplier,
                                          barcode, costing, retailPrice, wholeSalePrice, stocksInHand);
                        productList.Add(product);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get products.");
            }

            return productList;
        }

        public List<Product> GetAllProducts()
        {
            List<Product> productList = new List<Product>();
            string query = @"SELECT * FROM Products Order By ProductName ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string productCode = reader["ProductCode"].ToString();
                        string productName = reader["ProductName"].ToString();
                        string category = reader["Category"].ToString();
                        string subcategory = reader["SubCategory"].ToString();
                        string description = reader["Description"].ToString();
                        string supplier = reader["Supplier"].ToString();
                        string barcode = reader["Barcode"].ToString();
                        int costing = Convert.ToInt32(reader["Costing"].ToString());
                        int retailPrice = Convert.ToInt32(reader["RetailPrice"].ToString());
                        int wholeSalePrice = Convert.ToInt32(reader["WholeSalePrice"].ToString());
                        int stocksInHand = Convert.ToInt32(reader["StocksInHand"].ToString());

                        Product product = new Product(productCode, productName, category, subcategory, description, supplier,
                                          barcode, costing, retailPrice, wholeSalePrice, stocksInHand);
                        productList.Add(product);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get products.");    
            }

            return productList;
        }

        public int GetInvoiceNumber()
        {
            int result = 0;
            string query = @"SELECT MAX(InVoiceNo)+1 AS MaxInVoiceNo FROM Sales;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    result = Convert.ToInt32(reader["MaxInVoiceNo"]);
                }
                else
                {
                    MessageBox.Show("Error occured. Could not find in voice number.");
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get in voice number.");    
            }

            return result;
        }

        public List<string> GetAllBanks()
        {
            List<string> bankList = new List<string>();
            string query = @"SELECT * FROM Banks ORDER BY BankName ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        bankList.Add(reader["BankName"].ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Error occured. Could not load bank names.");
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get load bank's names.");    
            }

            return bankList;
        }

        public string AddSales(List<Sales> sales)
        {
            string result = "";
            int salesRowsEffected = 0;
            int productsRowsEffected = 0;
            
            try
            {
                connection.Open();
                foreach (Sales sale in sales)
                {
                    string salesQuery = @"INSERT INTO Sales VALUES('" + sale.InVoiceNo + "','" + sale.Date + "','" +
                                        sale.Seller + "','" + sale.CustomerIdName + "','" + sale.ProductName + "','" +
                                        sale.UnitPrice + "','" + sale.PurchasedQuantity + "','" + sale.Ammount + "','" +
                                        sale.CheckNo + "','" + sale.BankName + "');";
                    
                    string productsQuery = @"UPDATE Products SET StocksInHand-=" + sale.PurchasedQuantity +
                                           " WHERE ProductName='" + sale.ProductName + "';";

                    command.CommandText = salesQuery;
                    salesRowsEffected = command.ExecuteNonQuery();
                    command.CommandText = productsQuery;
                    productsRowsEffected = command.ExecuteNonQuery();

                    if (salesRowsEffected > 0 && productsRowsEffected > 0)
                    {
                        result = "Sales and inventory has been successfully updated.";
                    }
                    else
                    {
                        result = "Error! Could not connect to the database and update sales and inventory.";
                        break;
                    }
                }
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not update sales and inventory.");
            }

            return result;
        }

        public List<StocksInOut> StocksInList(string fromDate, string toDate)
        {
            List<StocksInOut> stocksInList = new List<StocksInOut>();
            string query = @"SELECT StocksIn.EmployeeId, StocksIn.Date, Products.ProductName, Products.Category,  
                            Products.SubCategory, Products.Description, Suppliers.CompanyName, StocksIn.Costing, 
                            Products.RetailPrice, Products.WholeSalePrice, StocksIn.StocksIn FROM 
                            ((StocksIn INNER JOIN Suppliers ON StocksIn.Supplier=Suppliers.CompanyName) 
                            LEFT OUTER JOIN Products ON Products.ProductCode = StocksIn.ProductCode) 
                            WHERE StocksIn.Date >= '" + fromDate + "' AND StocksIn.Date <= '" + toDate + "' ORDER BY StocksIn.Id;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string employeeId = reader["EmployeeId"].ToString();
                        string date = reader["Date"].ToString();
                        string productName = reader["ProductName"].ToString();
                        string category = reader["Category"].ToString();
                        string subcategory = reader["Subcategory"].ToString();
                        string description = reader["Description"].ToString();
                        string companyName = reader["CompanyName"].ToString();
                        int costing = Convert.ToInt32(reader["Costing"].ToString());
                        int retailPrice = Convert.ToInt32(reader["RetailPrice"].ToString());
                        int wholeSalePrice = Convert.ToInt32(reader["WholeSalePrice"].ToString());
                        int stocksCameIn = Convert.ToInt32(reader["StocksIn"].ToString());

                        StocksInOut stocksIn = new StocksInOut(employeeId, date, productName, category, subcategory, 
                                               description, companyName, costing, retailPrice, wholeSalePrice, stocksCameIn);
                        stocksInList.Add(stocksIn);
                    }

                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get stocks in info.");    
            }

            return stocksInList;
        }

        public List<StocksInOut> StocksOutList(string fromDate, string toDate)
        {
            List<StocksInOut> stocksOutList = new List<StocksInOut>();
            string query = @"SELECT StocksOut.EmployeeId, StocksOut.Date, Products.ProductName, Products.Category, 
                            Products.SubCategory, Products.Description, Suppliers.CompanyName, StocksOut.Costing, 
                            Products.RetailPrice, Products.WholeSalePrice, StocksOut.StocksOut FROM 
                            ((StocksOut INNER JOIN Suppliers ON StocksOut.Supplier=Suppliers.CompanyName) 
                            LEFT OUTER JOIN Products ON Products.ProductCode = StocksOut.ProductCode) 
                            WHERE StocksOut.Date >= '" + fromDate + "' AND StocksOut.Date <= '" + toDate + "' ORDER BY StocksOut.Id;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string employeeId = reader["EmployeeId"].ToString();
                        string date = reader["Date"].ToString();
                        string productName = reader["ProductName"].ToString();
                        string category = reader["Category"].ToString();
                        string subcategory = reader["Subcategory"].ToString();
                        string description = reader["Description"].ToString();
                        string companyName = reader["CompanyName"].ToString();
                        int costing = Convert.ToInt32(reader["Costing"].ToString());
                        int retailPrice = Convert.ToInt32(reader["RetailPrice"].ToString());
                        int wholeSalePrice = Convert.ToInt32(reader["WholeSalePrice"].ToString());
                        int stocksCameOut = Convert.ToInt32(reader["StocksOut"].ToString());

                        StocksInOut stocksOut = new StocksInOut(employeeId, date, productName, category, subcategory,
                                               description, companyName, costing, retailPrice, wholeSalePrice, stocksCameOut);
                        stocksOutList.Add(stocksOut);
                    }

                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get stocks out info.");    
            }
            
            return stocksOutList;
        }

        public List<Sales> SalesList(string fromDate, string toDate)
        {
            List<Sales> salesList = new List<Sales>();
            string query = @"SELECT * FROM Sales WHERE Date >= '" + fromDate + "' AND Date <= '" + toDate +"';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string inVoiceNo = reader["InVoiceNo"].ToString();
                        string date = reader["Date"].ToString();
                        string seller = reader["Seller"].ToString();
                        string customerId = reader["CustomerId"].ToString();
                        //string mobileNo = reader["MobileNo"].ToString();
                        //string address = reader["Address"].ToString();
                        string productName = reader["ProductName"].ToString();
                        int unitPrice = Convert.ToInt32(reader["UnitPrice"].ToString());
                        int purchasedQuantity = Convert.ToInt32(reader["PurchasedQuantity"].ToString());
                        int ammount = Convert.ToInt32(reader["Ammount"].ToString());
                        string checkNo = reader["CheckNo"].ToString();
                        string bankName = reader["BankName"].ToString();

                        Sales sales = new Sales(inVoiceNo, date, seller, customerId, productName,
                            unitPrice, purchasedQuantity, ammount, checkNo, bankName);
                        salesList.Add(sales);
                    }

                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get sales list info.");
            }

            return salesList;
        }


        public List<Sales> SalesReport(string fromDate, string toDate)
        {
            List<Sales> salesList = new List<Sales>();
            string query = @"SELECT Sales.Id, Sales.InVoiceNo, Sales.Date, Sales.Seller, Customers.CustomerName, Customers.ContactNo1,  
                            Sales.ProductName, Sales.UnitPrice, Sales.PurchasedQuantity, Sales.Ammount, Sales.CheckNo, Sales.BankName 
                            FROM Sales LEFT OUTER JOIN Customers ON Sales.CustomerId=Customers.CustomerId 
                            WHERE Date >= '" + fromDate + "' AND Date <= '" + toDate + "';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string inVoiceNo = reader["InVoiceNo"].ToString();
                        string date = reader["Date"].ToString();
                        string seller = reader["Seller"].ToString();
                        string customerName = reader["CustomerName"].ToString();
                        string contactNo = reader["ContactNo1"].ToString();
                        //string address = reader["Address"].ToString();
                        string productName = reader["ProductName"].ToString();
                        int unitPrice = Convert.ToInt32(reader["UnitPrice"].ToString());
                        int purchasedQuantity = Convert.ToInt32(reader["PurchasedQuantity"].ToString());
                        int ammount = Convert.ToInt32(reader["Ammount"].ToString());
                        string checkNo = reader["CheckNo"].ToString();
                        string bankName = reader["BankName"].ToString();

                        Sales sales = new Sales(inVoiceNo, date, seller, customerName, contactNo, productName,
                            unitPrice, purchasedQuantity, ammount, checkNo, bankName);
                        salesList.Add(sales);
                    }

                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get sales list info.");
            }

            return salesList;
        }


        public DataSet LoadSpecificBarcode(string productCode, int noOfCopy)
        {
            DataSet dataSet = new DataSet();
            string query = @"SELECT * FROM Products WHERE ProductCode='" + productCode + "'";
            for (int i = 1; i < noOfCopy; i++)
            {
                query += @"UNION ALL SELECT * FROM Products WHERE ProductCode='" + productCode + "'";
            }

            try
            {
                connection.Open();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                dataAdapter.Fill(dataSet, "Products");
                connection.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error! Cannot open connection! Cannot load barcode.");
            }

            return dataSet;
        }


        public DataSet LoadAllBarcode()
        {
            DataSet dataSet = new DataSet();
            string query = @"SELECT * FROM Products;";

            try
            {
                connection.Open();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                dataAdapter.Fill(dataSet, "Products");
                connection.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error! Cannot open connection! Cannot load barcode.");
            }

            return dataSet;
        }

        public DataSet TopSale()
        {
            DataSet topList=new DataSet();
            string query = @"SELECT TOP(5) * FROM Sales ORDER BY PurchasedQuantity DESC, UnitPrice DESC";
            try
            {
                connection.Open();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                dataAdapter.Fill(topList);
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get sales list info.");
            }
            return topList;
        }
    }
}
