﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.Model;

namespace POSwithIMS.Core.DAL
{
    class CustomerGateway : DBGateWay
    {
        public bool CheckIfCustomerExistsByCustomerId(string customerId)
        {
            bool result = false;
            string query = @"SELECT * FROM Customers WHERE CustomerId='" + customerId + "';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    result = true;
                }
                else
                {
                    result = false;
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot check if user name exists.");
            }
            
            return result;
        }


        public string AddNewCustomer(Customer aCustomer)
        {
            string result = "";
            string query = @"INSERT INTO Customers VALUES('" + aCustomer.CustomerId + "', '" + aCustomer.CustomerName + "','" + aCustomer.Address + 
                           "','" + aCustomer.ContactNo1 + "','" + aCustomer.ContactNo2 + "','" + aCustomer.Email + "','" + aCustomer.DueAmmount + "');";
            int rowsEffected = 0;
            try
            {
                connection.Open();
                command.CommandText = query;
                rowsEffected = command.ExecuteNonQuery();
                if (rowsEffected > 0)
                {
                    result = "New customer profile has been successfully created.";
                }
                else
                {
                    result = "ERROR! Could not create new customer profile.";
                }
            }
            catch (Exception ex)
            {
                result = ex.ToString();
            }

            return result;
        }


        public string UpdateCustomerInfo(Customer aCustomer)
        {
            string result = "";
            string query = @"UPDATE Customers SET CustomerId='" + aCustomer.CustomerId + "', CustomerName='" + aCustomer.CustomerName + "', Address='" + aCustomer.Address + "', ContactNo1='" +
                           aCustomer.ContactNo1 + "', ContactNo2='" + aCustomer.ContactNo2 + "', Email='" + aCustomer.Email + "', Balance='" + aCustomer.DueAmmount + "' WHERE CustomerId='" + aCustomer.CustomerId + "';";
            int rowsEffected = 0;
            try
            {
                connection.Open();
                command.CommandText = query;
                rowsEffected = command.ExecuteNonQuery();
                if (rowsEffected > 0)
                {
                    result = "Customer profile has been successfully updated.";
                }
                else
                {
                    result = "ERROR! Could not update customer profile.";
                }
            }
            catch (Exception ex)
            {
                result = ex.ToString();
            }

            return result;
        }


        public string UpdateCustomerAccountAddDue(string customerId, double ammountDue)
        {
            string result = "";
            string query = @"UPDATE Customers SET DueAmmount+=" + ammountDue + "WHERE CustomerId='" + customerId + "';";
            int customerRowsEffected = 0;

            try
            {
                connection.Open();
                command.CommandText = query;
                customerRowsEffected = command.ExecuteNonQuery();
                connection.Close();

                if (customerRowsEffected > 0)
                {
                    result = "Due ammount has been added to the customer account.";
                }
            }
            catch (Exception ex)
            {
                result = "Error! Could not update customer's account.";
            }

            return result;
        }


        public string UpdateCustomerAccountDuePaid(string customerId, double ammountPaid)
        {
            string result = "";
            string query = @"UPDATE Customers SET DueAmmount-=" + ammountPaid + "WHERE CustomerId='" + customerId + "';";
            int customerRowsEffected = 0;

            try
            {
                connection.Open();
                command.CommandText = query;
                customerRowsEffected = command.ExecuteNonQuery();
                connection.Close();

                if (customerRowsEffected > 0)
                {
                    result = "Paid ammount has been redused from the customer account.";
                }
            }
            catch (Exception ex)
            {
                result = "Error! Could not update customer's account.";
            }

            return result;
        }


        public Customer GetCustomerInfoByCustomerId(string customerId)
        {
            Customer aCustomer = null;
            string query = @"SELECT * FROM Customers WHERE CustomerId = '" + customerId + "';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string customerName = reader["CustomerName"].ToString();
                        string address = reader["Address"].ToString();
                        string contactNo1 = reader["ContactNo1"].ToString();
                        string contactNo2 = reader["ContactNo2"].ToString();
                        string email = reader["Email"].ToString();
                        double dueAmmount = Convert.ToDouble(reader["DueAmmount"].ToString());

                        aCustomer = new Customer(customerId, customerName, address, contactNo1, contactNo2,
                                             email, dueAmmount);
                    }
                }
                else
                {
                    MessageBox.Show("Customer with Customer Id:'" + customerId + "' does not exists.");
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot load customer information.");
            }

            return aCustomer;
        }


        public List<Customer> GetAllCustomers()
        {
            List<Customer> customerList = new List<Customer>();
            Customer aCustomer = null;

            string query = @"SELECT * FROM Customers Order By CustomerId ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string customerId = reader["CustomerId"].ToString();
                        string customerName = reader["CustomerName"].ToString();
                        string address = reader["Address"].ToString();
                        string contactNo1 = reader["ContactNo1"].ToString();
                        string contactNo2 = reader["ContactNo2"].ToString();
                        string email = reader["Email"].ToString();
                        double dueAmmount = Convert.ToDouble(reader["DueAmmount"].ToString());

                        aCustomer = new Customer(customerId, customerName, address, contactNo1, contactNo2,
                                             email, dueAmmount);

                        customerList.Add(aCustomer);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot load customer's list.");
            }

            return customerList;
        }


        public List<Customer> GetSpecificCustomers(string searchThisCustomer)
        {
            List<Customer> customerList = new List<Customer>();
            Customer aCustomer = null;

            string query = @"SELECT * FROM Customers WHERE CustomerName LIKE '%" + searchThisCustomer + "%' Order By Id ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string customerId = reader["CustomerId"].ToString();
                        string customerName = reader["CustomerName"].ToString();
                        string address = reader["Address"].ToString();
                        string contactNo1 = reader["ContactNo1"].ToString();
                        string contactNo2 = reader["ContactNo2"].ToString();
                        string email = reader["Email"].ToString();
                        double dueAmmount = Convert.ToDouble(reader["DueAmmount"].ToString());

                        aCustomer = new Customer(customerId, customerName, address, contactNo1, contactNo2,
                                             email, dueAmmount);

                        customerList.Add(aCustomer);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot load customer's list.");
            }

            return customerList;
        }


        public int GetNumbersOfCustomers()
        {
            string result = "";
            int noOfCustomers = 0;
            string query = @"SELECT MAX(Id) AS NoOfCustomers FROM Customers;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result = reader["NoOfCustomers"].ToString();
                    }
                }
                reader.Close();
                connection.Close();

                if (result != "" || result != null || result != "NULL")
                {
                    noOfCustomers = Convert.ToInt32(result);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Could not get the number of customer.\n" + ex.ToString());
            }

            return noOfCustomers;
        }
    }
}
