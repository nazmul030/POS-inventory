﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POSwithIMS.Core.DAL
{
    public class DBGateWay
    {
        public SqlConnection connection { get; set; }
        public SqlCommand command { get; set; }

        public string connectionString =
            ConfigurationManager.ConnectionStrings["IMSwithPOSConnectionString"].ConnectionString;

        public DBGateWay()
        {
            connection = new SqlConnection(connectionString);
            command = new SqlCommand();
            command.Connection = connection;
        }

        public string BackUpDB(string path, string date)
        {
            string result = "";
            string query = @"BACKUP DATABASE POSWithIMS TO DISK = '" + path + "\\" + date + "_Backupfile.bak'";
            
            //string restoreQuery = @"RESTORE DATABASE TestDB FROM DISK = 'H:\\backupfile.bak';";

            connection.Open();
            command.CommandText = query;
            command.ExecuteNonQuery();
            connection.Close();

            result = "Backup of database has been successfully created.";

            return result;
        }
    }
}
