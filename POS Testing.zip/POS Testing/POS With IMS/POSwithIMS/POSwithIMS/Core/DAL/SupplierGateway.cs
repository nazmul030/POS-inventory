﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POSwithIMS.Core.Model;

namespace POSwithIMS.Core.DAL
{
    public class SupplierGateway : DBGateWay
    {
        public bool CheckIfSupplierExistsBySupplierId(string supplierId)
        {
            bool result = false;
            string query = @"SELECT * FROM Suppliers WHERE SupplierId='" + supplierId + "';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    result = true;
                }
                else
                {
                    result = false;
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot check if supplier exists.");
            }

            return result;
        }


        public string AddNewSupplier(Supplier aSupplier)
        {
            string result = "";
            string query = @"INSERT INTO Suppliers VALUES('" + aSupplier.SupplierId + "', '" + aSupplier.CompanyName + "','" + aSupplier.PersonOfContact + "', '" + aSupplier.Address +
                           "','" + aSupplier.ContactNo1 + "','" + aSupplier.ContactNo2 + "','" + aSupplier.Email + "','" + aSupplier.Balance + "');";
            int rowsEffected = 0;
            try
            {
                connection.Open();
                command.CommandText = query;
                rowsEffected = command.ExecuteNonQuery();
                if (rowsEffected > 0)
                {
                    result = "New supplier profile has been successfully created.";
                }
                else
                {
                    result = "ERROR! Could not create new supplier profile.";
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                result = ex.ToString();
            }

            return result;
        }


        public Supplier GetSpecificSuppliersInfo(string supplierId)
        {
            Supplier aSupplier = null;
            string query = @"SELECT * FROM Suppliers WHERE SupplierId = '" + supplierId + "';";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string companyName = reader["CompanyName"].ToString();
                        string personOfContact = reader["PersonOfContact"].ToString();
                        string address = reader["Address"].ToString();
                        string contactNo1 = reader["ContactNo1"].ToString();
                        string contactNo2 = reader["ContactNo2"].ToString();
                        string email = reader["Email"].ToString();
                        double balance = Convert.ToDouble(reader["balance"].ToString());

                        aSupplier = new Supplier(supplierId, companyName, personOfContact, address, contactNo1, contactNo2,
                                             email, balance);
                    }
                }
                else
                {
                    MessageBox.Show("Supplier with Supplier Id:'" + supplierId + "' does not exists.");
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot load supplier information.");
            }

            return aSupplier;
        }


        public List<Supplier> GetAllSuppliers()
        {
            List<Supplier> supplierList = new List<Supplier>();
            Supplier aSupplier = null;

            string query = @"SELECT * FROM Suppliers Order By SupplierId ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string supplierId = reader["SupplierId"].ToString();
                        string companyName = reader["CompanyName"].ToString();
                        string personOfContact = reader["PersonOfContact"].ToString();
                        string address = reader["Address"].ToString();
                        string contactNo1 = reader["ContactNo1"].ToString();
                        string contactNo2 = reader["ContactNo2"].ToString();
                        string email = reader["Email"].ToString();
                        double balance = Convert.ToDouble(reader["balance"].ToString());

                        aSupplier = new Supplier(supplierId, companyName, personOfContact, address, contactNo1, contactNo2,
                                             email, balance);

                        supplierList.Add(aSupplier);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot load supplier's list.");
            }

            return supplierList;
        }


        public List<string> GetAllSuppliersCompanyName()
        {
            List<string> supplierList = new List<string>();
            
            string query = @"SELECT CompanyName FROM Suppliers Order By SupplierId ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string companyName = reader["CompanyName"].ToString();

                        supplierList.Add(companyName);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot load supplier's names.");
            }

            return supplierList;
        }


        public List<Supplier> GetSpecificSuppliers(string searchThisSupplier)
        {
            List<Supplier> supplierList = new List<Supplier>();
            Supplier aSupplier = null;

            string query = @"SELECT * FROM Suppliers WHERE CompanyName LIKE '%" + searchThisSupplier + "%' Order By Id ASC;";

            try
            {
                connection.Open();
                command.CommandText = query;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        string supplierId = reader["SupplierId"].ToString();
                        string companyName = reader["CompanyName"].ToString();
                        string personOfContact = reader["PersonOfContact"].ToString();
                        string address = reader["Address"].ToString();
                        string contactNo1 = reader["ContactNo1"].ToString();
                        string contactNo2 = reader["ContactNo2"].ToString();
                        string email = reader["Email"].ToString();
                        double balance = Convert.ToDouble(reader["balance"].ToString());

                        aSupplier = new Supplier(supplierId, companyName, personOfContact, address, contactNo1, contactNo2,
                                             email, balance);

                        supplierList.Add(aSupplier);
                    }
                }
                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Cannot connect to database! Cannot load customer's list.");
            }

            return supplierList;
        }


        public string UpdateSupplierInfo(Supplier aSupplier)
        {
            string result = "";
            string query = @"UPDATE Suppliers SET SupplierId='" + aSupplier.SupplierId + "', CompanyName='" + aSupplier.CompanyName + "', PersonOfContact='" + aSupplier.PersonOfContact + "', Address='" + aSupplier.Address + "', ContactNo1='" +
                           aSupplier.ContactNo1 + "', ContactNo2='" + aSupplier.ContactNo2 + "', Email='" + aSupplier.Email + "', Balance='" + aSupplier.Balance + "' WHERE SupplierId='" + aSupplier.SupplierId + "';";
            int rowsEffected = 0;
            try
            {
                connection.Open();
                command.CommandText = query;
                rowsEffected = command.ExecuteNonQuery();
                if (rowsEffected > 0)
                {
                    result = "Supplier profile has been successfully updated.";
                }
                else
                {
                    result = "ERROR! Could not update supplier profile.";
                }
            }
            catch (Exception ex)
            {
                result = ex.ToString();
            }

            return result;
        }
    }
}
