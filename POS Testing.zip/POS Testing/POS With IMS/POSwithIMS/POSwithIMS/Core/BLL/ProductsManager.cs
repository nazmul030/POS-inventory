﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POSwithIMS.Core.DAL;
using POSwithIMS.Core.Model;

namespace POSwithIMS.Core.BLL
{
    public class ProductsManager
    {
        ProductsGateway productsGateway = new ProductsGateway();

        public List<string> LoadCategory()
        {
            return productsGateway.LoadCategory();
        }

        public string AddProduct(Product product)
        {
            bool isProductExists;
            string result;

            isProductExists = productsGateway.IsProductExists(product.ProductCode, product.ProductName, product.Category);
            if (isProductExists == false)
            {
                result = productsGateway.AddProduct(product);
            }
            else
            {
                result = "Product already exists!";
            }
            return result;
        }

        public string UpdateProduct(Product aProduct)
        {
            return productsGateway.UpdateProduct(aProduct);
        }

        public string UpdateStock(string productCode, string productName, string newTotalStock)
        {
            return productsGateway.UpdateStock(productCode, productName, newTotalStock);
        }

        public List<Product> GetAllProducts()
        {
            return productsGateway.GetAllProducts();
        }

        public Product GetProductByCode(string productCode)
        {
            return productsGateway.GetProductByCode(productCode);
        }

    }
}
