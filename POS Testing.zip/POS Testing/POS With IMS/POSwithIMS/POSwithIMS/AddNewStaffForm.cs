﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POSwithIMS
{
    public partial class AddNewStaffForm : Form
    {
        public AddNewStaffForm()
        {
            InitializeComponent();
        }

        private void AddNewStaffForm_Load(object sender, EventArgs e)
        {
            string[] months = new[]
            {
                "January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
                "November", "December"
            };
            foreach (string value in months)
            {
                monthComboBox.Items.Add(value);
            }
            for (int year = 1950; year <= 2009; year++)
            {
                yearComboBox.Items.Add(year);
            }
        }

        private void monthComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (monthComboBox.SelectedItem.ToString() == "January" || monthComboBox.SelectedItem.ToString() == "March" ||
                monthComboBox.SelectedItem.ToString() == "May" || monthComboBox.SelectedItem.ToString() == "July" ||
                monthComboBox.SelectedItem.ToString() == "August" || monthComboBox.SelectedItem.ToString() == "October" ||
                monthComboBox.SelectedItem.ToString() == "December")
            {
                dayComboBox.Items.Clear();
                for (int day = 1; day <= 31; day++)
                {
                    dayComboBox.Items.Add(day);
                }
            }
            else if (monthComboBox.SelectedItem.ToString() == "February")
            {
                dayComboBox.Items.Clear();
                for (int day = 1; day <= 29; day++)
                {
                    dayComboBox.Items.Add(day);
                }
            }
            else
            {
                dayComboBox.Items.Clear();
                for (int day = 1; day <= 30; day++)
                {
                    dayComboBox.Items.Add(day);
                }
            }
        }

        private void browseFolderButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Images|*.bmp;*.jpg;*.gif|All files|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                var image = Bitmap.FromFile(openFileDialog.FileName);
                var resizedImage = ScaleImage(image, 107, 142);
                pictureBox.Image = resizedImage;
            }
        }

        public static Image ScaleImage(Image image, int maxWidth, int maxHeight)
        {
            var ratioX = (double)maxWidth / image.Width;
            var ratioY = (double)maxHeight / image.Height;
            var ratio = Math.Min(ratioX, ratioY);

            var newWidth = (int)(image.Width * ratio);
            var newHeight = (int)(image.Height * ratio);

            var newImage = new Bitmap(newWidth, newHeight);
            Graphics.FromImage(newImage).DrawImage(image, 0, 0, newWidth, newHeight);
            return newImage;
        }

            
    }
}
