﻿namespace POSwithIMS
{
    partial class AddNewStaffForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewStaffForm));
            this.Panel1 = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cityLabel = new System.Windows.Forms.Label();
            this.streetNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.divissionLabel = new System.Windows.Forms.Label();
            this.streetNoLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtContractNo = new System.Windows.Forms.TextBox();
            this.contactNoLabel = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtBarangay = new System.Windows.Forms.TextBox();
            this.txtProvince = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.staffInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.postRoleTextBox = new System.Windows.Forms.TextBox();
            this.postRoleLabel = new System.Windows.Forms.Label();
            this.countryLabel = new System.Windows.Forms.Label();
            this.countryTextBox = new System.Windows.Forms.TextBox();
            this.femaleRadioButton = new System.Windows.Forms.RadioButton();
            this.maleRadioButton = new System.Windows.Forms.RadioButton();
            this.genderLabel = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.yearLabel = new System.Windows.Forms.Label();
            this.yearComboBox = new System.Windows.Forms.ComboBox();
            this.monthLabel = new System.Windows.Forms.Label();
            this.monthComboBox = new System.Windows.Forms.ComboBox();
            this.dayLabel = new System.Windows.Forms.Label();
            this.dayComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.browseFolderButton = new System.Windows.Forms.Button();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.nidNoLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.Button2 = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            this.staffInformationGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.LightSlateGray;
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel1.Controls.Add(this.lblTitle);
            this.Panel1.Location = new System.Drawing.Point(23, 24);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(651, 57);
            this.Panel1.TabIndex = 8;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(22, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(199, 42);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Add New Staff";
            // 
            // cityLabel
            // 
            this.cityLabel.AutoSize = true;
            this.cityLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cityLabel.Location = new System.Drawing.Point(365, 150);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(26, 12);
            this.cityLabel.TabIndex = 8;
            this.cityLabel.Text = "City";
            // 
            // streetNameLabel
            // 
            this.streetNameLabel.AutoSize = true;
            this.streetNameLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.streetNameLabel.Location = new System.Drawing.Point(177, 150);
            this.streetNameLabel.Name = "streetNameLabel";
            this.streetNameLabel.Size = new System.Drawing.Size(68, 12);
            this.streetNameLabel.TabIndex = 8;
            this.streetNameLabel.Text = "Street Name";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameLabel.Location = new System.Drawing.Point(367, 50);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(59, 12);
            this.lastNameLabel.TabIndex = 8;
            this.lastNameLabel.Text = "Last Name";
            // 
            // divissionLabel
            // 
            this.divissionLabel.AutoSize = true;
            this.divissionLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.divissionLabel.Location = new System.Drawing.Point(101, 189);
            this.divissionLabel.Name = "divissionLabel";
            this.divissionLabel.Size = new System.Drawing.Size(46, 12);
            this.divissionLabel.TabIndex = 8;
            this.divissionLabel.Text = "Division";
            // 
            // streetNoLabel
            // 
            this.streetNoLabel.AutoSize = true;
            this.streetNoLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.streetNoLabel.Location = new System.Drawing.Point(101, 150);
            this.streetNoLabel.Name = "streetNoLabel";
            this.streetNoLabel.Size = new System.Drawing.Size(53, 12);
            this.streetNoLabel.TabIndex = 8;
            this.streetNoLabel.Text = "Street No";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameLabel.Location = new System.Drawing.Point(101, 50);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(60, 12);
            this.firstNameLabel.TabIndex = 8;
            this.firstNameLabel.Text = "First Name";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(18, 168);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(55, 15);
            this.Label2.TabIndex = 4;
            this.Label2.Text = "Address :";
            // 
            // txtContractNo
            // 
            this.txtContractNo.BackColor = System.Drawing.Color.White;
            this.txtContractNo.Location = new System.Drawing.Point(103, 240);
            this.txtContractNo.Name = "txtContractNo";
            this.txtContractNo.Size = new System.Drawing.Size(137, 23);
            this.txtContractNo.TabIndex = 7;
            // 
            // contactNoLabel
            // 
            this.contactNoLabel.AutoSize = true;
            this.contactNoLabel.Location = new System.Drawing.Point(18, 243);
            this.contactNoLabel.Name = "contactNoLabel";
            this.contactNoLabel.Size = new System.Drawing.Size(77, 15);
            this.contactNoLabel.TabIndex = 4;
            this.contactNoLabel.Text = "Contact No. :";
            // 
            // txtCity
            // 
            this.txtCity.BackColor = System.Drawing.Color.White;
            this.txtCity.Location = new System.Drawing.Point(365, 165);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(141, 23);
            this.txtCity.TabIndex = 5;
            // 
            // txtBarangay
            // 
            this.txtBarangay.BackColor = System.Drawing.Color.White;
            this.txtBarangay.Location = new System.Drawing.Point(179, 165);
            this.txtBarangay.Name = "txtBarangay";
            this.txtBarangay.Size = new System.Drawing.Size(180, 23);
            this.txtBarangay.TabIndex = 4;
            // 
            // txtProvince
            // 
            this.txtProvince.BackColor = System.Drawing.Color.White;
            this.txtProvince.Location = new System.Drawing.Point(103, 204);
            this.txtProvince.Name = "txtProvince";
            this.txtProvince.Size = new System.Drawing.Size(194, 23);
            this.txtProvince.TabIndex = 6;
            // 
            // txtStreet
            // 
            this.txtStreet.BackColor = System.Drawing.Color.White;
            this.txtStreet.Location = new System.Drawing.Point(103, 165);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(70, 23);
            this.txtStreet.TabIndex = 3;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.BackColor = System.Drawing.Color.White;
            this.lastNameTextBox.Location = new System.Drawing.Point(369, 65);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(137, 23);
            this.lastNameTextBox.TabIndex = 1;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(18, 68);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(45, 15);
            this.Label3.TabIndex = 4;
            this.Label3.Text = "Name :";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.BackColor = System.Drawing.Color.White;
            this.firstNameTextBox.Location = new System.Drawing.Point(103, 65);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(127, 23);
            this.firstNameTextBox.TabIndex = 0;
            // 
            // staffInformationGroupBox
            // 
            this.staffInformationGroupBox.Controls.Add(this.postRoleTextBox);
            this.staffInformationGroupBox.Controls.Add(this.postRoleLabel);
            this.staffInformationGroupBox.Controls.Add(this.countryLabel);
            this.staffInformationGroupBox.Controls.Add(this.countryTextBox);
            this.staffInformationGroupBox.Controls.Add(this.femaleRadioButton);
            this.staffInformationGroupBox.Controls.Add(this.maleRadioButton);
            this.staffInformationGroupBox.Controls.Add(this.genderLabel);
            this.staffInformationGroupBox.Controls.Add(this.textBox2);
            this.staffInformationGroupBox.Controls.Add(this.emailLabel);
            this.staffInformationGroupBox.Controls.Add(this.yearLabel);
            this.staffInformationGroupBox.Controls.Add(this.yearComboBox);
            this.staffInformationGroupBox.Controls.Add(this.monthLabel);
            this.staffInformationGroupBox.Controls.Add(this.monthComboBox);
            this.staffInformationGroupBox.Controls.Add(this.dayLabel);
            this.staffInformationGroupBox.Controls.Add(this.dayComboBox);
            this.staffInformationGroupBox.Controls.Add(this.label1);
            this.staffInformationGroupBox.Controls.Add(this.browseFolderButton);
            this.staffInformationGroupBox.Controls.Add(this.pictureBox);
            this.staffInformationGroupBox.Controls.Add(this.textBox1);
            this.staffInformationGroupBox.Controls.Add(this.nidNoLabel);
            this.staffInformationGroupBox.Controls.Add(this.middleNameLabel);
            this.staffInformationGroupBox.Controls.Add(this.middleNameTextBox);
            this.staffInformationGroupBox.Controls.Add(this.Button2);
            this.staffInformationGroupBox.Controls.Add(this.Button1);
            this.staffInformationGroupBox.Controls.Add(this.cityLabel);
            this.staffInformationGroupBox.Controls.Add(this.streetNameLabel);
            this.staffInformationGroupBox.Controls.Add(this.lastNameLabel);
            this.staffInformationGroupBox.Controls.Add(this.divissionLabel);
            this.staffInformationGroupBox.Controls.Add(this.streetNoLabel);
            this.staffInformationGroupBox.Controls.Add(this.firstNameLabel);
            this.staffInformationGroupBox.Controls.Add(this.Label2);
            this.staffInformationGroupBox.Controls.Add(this.txtContractNo);
            this.staffInformationGroupBox.Controls.Add(this.contactNoLabel);
            this.staffInformationGroupBox.Controls.Add(this.txtCity);
            this.staffInformationGroupBox.Controls.Add(this.txtBarangay);
            this.staffInformationGroupBox.Controls.Add(this.txtProvince);
            this.staffInformationGroupBox.Controls.Add(this.txtStreet);
            this.staffInformationGroupBox.Controls.Add(this.lastNameTextBox);
            this.staffInformationGroupBox.Controls.Add(this.firstNameTextBox);
            this.staffInformationGroupBox.Controls.Add(this.Label3);
            this.staffInformationGroupBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.staffInformationGroupBox.Location = new System.Drawing.Point(23, 108);
            this.staffInformationGroupBox.Name = "staffInformationGroupBox";
            this.staffInformationGroupBox.Size = new System.Drawing.Size(651, 408);
            this.staffInformationGroupBox.TabIndex = 6;
            this.staffInformationGroupBox.TabStop = false;
            this.staffInformationGroupBox.Text = "Staff Information";
            // 
            // postRoleTextBox
            // 
            this.postRoleTextBox.BackColor = System.Drawing.Color.White;
            this.postRoleTextBox.Location = new System.Drawing.Point(345, 278);
            this.postRoleTextBox.Name = "postRoleTextBox";
            this.postRoleTextBox.Size = new System.Drawing.Size(161, 23);
            this.postRoleTextBox.TabIndex = 32;
            // 
            // postRoleLabel
            // 
            this.postRoleLabel.AutoSize = true;
            this.postRoleLabel.Location = new System.Drawing.Point(278, 281);
            this.postRoleLabel.Name = "postRoleLabel";
            this.postRoleLabel.Size = new System.Drawing.Size(61, 15);
            this.postRoleLabel.TabIndex = 31;
            this.postRoleLabel.Text = "Post/Role:";
            // 
            // countryLabel
            // 
            this.countryLabel.AutoSize = true;
            this.countryLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.countryLabel.Location = new System.Drawing.Point(301, 191);
            this.countryLabel.Name = "countryLabel";
            this.countryLabel.Size = new System.Drawing.Size(45, 12);
            this.countryLabel.TabIndex = 30;
            this.countryLabel.Text = "Country";
            // 
            // countryTextBox
            // 
            this.countryTextBox.BackColor = System.Drawing.Color.White;
            this.countryTextBox.Location = new System.Drawing.Point(303, 204);
            this.countryTextBox.Name = "countryTextBox";
            this.countryTextBox.Size = new System.Drawing.Size(203, 23);
            this.countryTextBox.TabIndex = 29;
            // 
            // femaleRadioButton
            // 
            this.femaleRadioButton.AutoSize = true;
            this.femaleRadioButton.Location = new System.Drawing.Point(443, 113);
            this.femaleRadioButton.Name = "femaleRadioButton";
            this.femaleRadioButton.Size = new System.Drawing.Size(63, 19);
            this.femaleRadioButton.TabIndex = 28;
            this.femaleRadioButton.TabStop = true;
            this.femaleRadioButton.Text = "Female";
            this.femaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // maleRadioButton
            // 
            this.maleRadioButton.AutoSize = true;
            this.maleRadioButton.Location = new System.Drawing.Point(386, 113);
            this.maleRadioButton.Name = "maleRadioButton";
            this.maleRadioButton.Size = new System.Drawing.Size(51, 19);
            this.maleRadioButton.TabIndex = 27;
            this.maleRadioButton.TabStop = true;
            this.maleRadioButton.Text = "Male";
            this.maleRadioButton.UseVisualStyleBackColor = true;
            // 
            // genderLabel
            // 
            this.genderLabel.AutoSize = true;
            this.genderLabel.Location = new System.Drawing.Point(331, 115);
            this.genderLabel.Name = "genderLabel";
            this.genderLabel.Size = new System.Drawing.Size(48, 15);
            this.genderLabel.TabIndex = 26;
            this.genderLabel.Text = "Gender:";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.Location = new System.Drawing.Point(345, 240);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(161, 23);
            this.textBox2.TabIndex = 25;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(300, 243);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(39, 15);
            this.emailLabel.TabIndex = 24;
            this.emailLabel.Text = "Email:";
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearLabel.Location = new System.Drawing.Point(244, 100);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(27, 12);
            this.yearLabel.TabIndex = 23;
            this.yearLabel.Text = "Year";
            // 
            // yearComboBox
            // 
            this.yearComboBox.FormattingEnabled = true;
            this.yearComboBox.Location = new System.Drawing.Point(246, 115);
            this.yearComboBox.Name = "yearComboBox";
            this.yearComboBox.Size = new System.Drawing.Size(58, 23);
            this.yearComboBox.TabIndex = 22;
            // 
            // monthLabel
            // 
            this.monthLabel.AutoSize = true;
            this.monthLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monthLabel.Location = new System.Drawing.Point(101, 100);
            this.monthLabel.Name = "monthLabel";
            this.monthLabel.Size = new System.Drawing.Size(36, 12);
            this.monthLabel.TabIndex = 21;
            this.monthLabel.Text = "Month";
            // 
            // monthComboBox
            // 
            this.monthComboBox.FormattingEnabled = true;
            this.monthComboBox.Location = new System.Drawing.Point(103, 115);
            this.monthComboBox.Name = "monthComboBox";
            this.monthComboBox.Size = new System.Drawing.Size(75, 23);
            this.monthComboBox.TabIndex = 20;
            this.monthComboBox.SelectedIndexChanged += new System.EventHandler(this.monthComboBox_SelectedIndexChanged);
            // 
            // dayLabel
            // 
            this.dayLabel.AutoSize = true;
            this.dayLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dayLabel.Location = new System.Drawing.Point(182, 100);
            this.dayLabel.Name = "dayLabel";
            this.dayLabel.Size = new System.Drawing.Size(25, 12);
            this.dayLabel.TabIndex = 19;
            this.dayLabel.Text = "Day";
            // 
            // dayComboBox
            // 
            this.dayComboBox.FormattingEnabled = true;
            this.dayComboBox.Location = new System.Drawing.Point(184, 115);
            this.dayComboBox.Name = "dayComboBox";
            this.dayComboBox.Size = new System.Drawing.Size(56, 23);
            this.dayComboBox.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 15);
            this.label1.TabIndex = 17;
            this.label1.Text = "Date of Birth:";
            // 
            // browseFolderButton
            // 
            this.browseFolderButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.browseFolderButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.browseFolderButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.browseFolderButton.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.browseFolderButton.Image = ((System.Drawing.Image)(resources.GetObject("browseFolderButton.Image")));
            this.browseFolderButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.browseFolderButton.Location = new System.Drawing.Point(536, 213);
            this.browseFolderButton.Name = "browseFolderButton";
            this.browseFolderButton.Size = new System.Drawing.Size(80, 24);
            this.browseFolderButton.TabIndex = 16;
            this.browseFolderButton.Text = "&Browse";
            this.browseFolderButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.browseFolderButton.UseVisualStyleBackColor = false;
            this.browseFolderButton.Click += new System.EventHandler(this.browseFolderButton_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox.Location = new System.Drawing.Point(521, 65);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(107, 142);
            this.pictureBox.TabIndex = 15;
            this.pictureBox.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(103, 278);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(137, 23);
            this.textBox1.TabIndex = 14;
            // 
            // nidNoLabel
            // 
            this.nidNoLabel.AutoSize = true;
            this.nidNoLabel.Location = new System.Drawing.Point(18, 281);
            this.nidNoLabel.Name = "nidNoLabel";
            this.nidNoLabel.Size = new System.Drawing.Size(55, 15);
            this.nidNoLabel.TabIndex = 13;
            this.nidNoLabel.Text = "NID No. :";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middleNameLabel.Location = new System.Drawing.Point(234, 50);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(70, 12);
            this.middleNameLabel.TabIndex = 12;
            this.middleNameLabel.Text = "Middle Name";
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.BackColor = System.Drawing.Color.White;
            this.middleNameTextBox.Location = new System.Drawing.Point(236, 65);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(127, 23);
            this.middleNameTextBox.TabIndex = 11;
            // 
            // Button2
            // 
            this.Button2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Button2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button2.Image = ((System.Drawing.Image)(resources.GetObject("Button2.Image")));
            this.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button2.Location = new System.Drawing.Point(415, 361);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(75, 24);
            this.Button2.TabIndex = 10;
            this.Button2.Text = "&Cancel";
            this.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Button2.UseVisualStyleBackColor = false;
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Button1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button1.Image = ((System.Drawing.Image)(resources.GetObject("Button1.Image")));
            this.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button1.Location = new System.Drawing.Point(334, 361);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(75, 24);
            this.Button1.TabIndex = 9;
            this.Button1.Text = "&Save ";
            this.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Button1.UseVisualStyleBackColor = false;
            // 
            // AddNewStaffForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 545);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.staffInformationGroupBox);
            this.Name = "AddNewStaffForm";
            this.Text = "Inventory Management System With POS";
            this.Load += new System.EventHandler(this.AddNewStaffForm_Load);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.staffInformationGroupBox.ResumeLayout(false);
            this.staffInformationGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label lblTitle;
        internal System.Windows.Forms.Label cityLabel;
        internal System.Windows.Forms.Label streetNameLabel;
        internal System.Windows.Forms.Label lastNameLabel;
        internal System.Windows.Forms.Label divissionLabel;
        internal System.Windows.Forms.Label streetNoLabel;
        internal System.Windows.Forms.Label firstNameLabel;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtContractNo;
        internal System.Windows.Forms.Label contactNoLabel;
        internal System.Windows.Forms.TextBox txtCity;
        internal System.Windows.Forms.TextBox txtBarangay;
        internal System.Windows.Forms.TextBox txtProvince;
        internal System.Windows.Forms.TextBox txtStreet;
        internal System.Windows.Forms.TextBox lastNameTextBox;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox firstNameTextBox;
        internal System.Windows.Forms.GroupBox staffInformationGroupBox;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.Label middleNameLabel;
        internal System.Windows.Forms.TextBox middleNameTextBox;
        internal System.Windows.Forms.TextBox textBox1;
        internal System.Windows.Forms.Label nidNoLabel;
        private System.Windows.Forms.PictureBox pictureBox;
        internal System.Windows.Forms.Button browseFolderButton;
        internal System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.ComboBox yearComboBox;
        internal System.Windows.Forms.Label monthLabel;
        private System.Windows.Forms.ComboBox monthComboBox;
        internal System.Windows.Forms.Label dayLabel;
        private System.Windows.Forms.ComboBox dayComboBox;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox textBox2;
        internal System.Windows.Forms.Label emailLabel;
        internal System.Windows.Forms.Label genderLabel;
        private System.Windows.Forms.RadioButton femaleRadioButton;
        private System.Windows.Forms.RadioButton maleRadioButton;
        internal System.Windows.Forms.Label countryLabel;
        internal System.Windows.Forms.TextBox countryTextBox;
        internal System.Windows.Forms.TextBox postRoleTextBox;
        internal System.Windows.Forms.Label postRoleLabel;
    }
}