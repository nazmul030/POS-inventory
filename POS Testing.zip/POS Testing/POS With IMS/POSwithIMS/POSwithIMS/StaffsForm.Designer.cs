﻿namespace POSwithIMS
{
    partial class StaffsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StaffsForm));
            this.ListView1 = new System.Windows.Forms.ListView();
            this.staffIdColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.nameColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dobColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.genderColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.addressColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contactNoColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.emailColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.nidColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.userNameColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.roleColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.closeToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.updateToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.searchToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lblSearch = new System.Windows.Forms.Label();
            this.ToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ListView1
            // 
            this.ListView1.BackColor = System.Drawing.Color.White;
            this.ListView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.staffIdColumn,
            this.nameColumn,
            this.dobColumn,
            this.genderColumn,
            this.addressColumn,
            this.contactNoColumn,
            this.emailColumn,
            this.nidColumn,
            this.userNameColumn,
            this.roleColumn});
            this.ListView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ListView1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListView1.FullRowSelect = true;
            this.ListView1.GridLines = true;
            this.ListView1.Location = new System.Drawing.Point(0, 40);
            this.ListView1.Name = "ListView1";
            this.ListView1.Size = new System.Drawing.Size(916, 351);
            this.ListView1.TabIndex = 32;
            this.ListView1.UseCompatibleStateImageBehavior = false;
            this.ListView1.View = System.Windows.Forms.View.Details;
            // 
            // staffIdColumn
            // 
            this.staffIdColumn.Text = "Staff ID";
            this.staffIdColumn.Width = 64;
            // 
            // nameColumn
            // 
            this.nameColumn.Text = "Name ";
            this.nameColumn.Width = 119;
            // 
            // dobColumn
            // 
            this.dobColumn.Text = "Date of Birth";
            this.dobColumn.Width = 78;
            // 
            // genderColumn
            // 
            this.genderColumn.Text = "Gender";
            this.genderColumn.Width = 50;
            // 
            // addressColumn
            // 
            this.addressColumn.Text = "Address";
            this.addressColumn.Width = 155;
            // 
            // contactNoColumn
            // 
            this.contactNoColumn.Text = "Contact No.";
            this.contactNoColumn.Width = 101;
            // 
            // emailColumn
            // 
            this.emailColumn.Text = "Email";
            this.emailColumn.Width = 87;
            // 
            // nidColumn
            // 
            this.nidColumn.Text = "NID";
            this.nidColumn.Width = 90;
            // 
            // userNameColumn
            // 
            this.userNameColumn.Text = "Username";
            this.userNameColumn.Width = 83;
            // 
            // roleColumn
            // 
            this.roleColumn.Text = "Role";
            this.roleColumn.Width = 87;
            // 
            // closeToolStripButton
            // 
            this.closeToolStripButton.AutoSize = false;
            this.closeToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("closeToolStripButton.Image")));
            this.closeToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.closeToolStripButton.Name = "closeToolStripButton";
            this.closeToolStripButton.Size = new System.Drawing.Size(65, 40);
            this.closeToolStripButton.Text = "Clos&e";
            // 
            // ToolStrip1
            // 
            this.ToolStrip1.AutoSize = false;
            this.ToolStrip1.BackColor = System.Drawing.Color.LightGray;
            this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripLabel1,
            this.newToolStripButton,
            this.updateToolStripButton,
            this.searchToolStripButton,
            this.closeToolStripButton});
            this.ToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.ToolStrip1.Name = "ToolStrip1";
            this.ToolStrip1.Size = new System.Drawing.Size(916, 40);
            this.ToolStrip1.TabIndex = 31;
            this.ToolStrip1.Text = "ToolStrip1";
            // 
            // ToolStripLabel1
            // 
            this.ToolStripLabel1.Name = "ToolStripLabel1";
            this.ToolStripLabel1.Size = new System.Drawing.Size(16, 37);
            this.ToolStripLabel1.Text = "   ";
            // 
            // newToolStripButton
            // 
            this.newToolStripButton.AutoSize = false;
            this.newToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripButton.Image")));
            this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripButton.Name = "newToolStripButton";
            this.newToolStripButton.Size = new System.Drawing.Size(65, 40);
            this.newToolStripButton.Text = "&New";
            // 
            // updateToolStripButton
            // 
            this.updateToolStripButton.AutoSize = false;
            this.updateToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("updateToolStripButton.Image")));
            this.updateToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.updateToolStripButton.Name = "updateToolStripButton";
            this.updateToolStripButton.Size = new System.Drawing.Size(65, 40);
            this.updateToolStripButton.Text = "&Update";
            // 
            // searchToolStripButton
            // 
            this.searchToolStripButton.AutoSize = false;
            this.searchToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("searchToolStripButton.Image")));
            this.searchToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.searchToolStripButton.Name = "searchToolStripButton";
            this.searchToolStripButton.Size = new System.Drawing.Size(65, 40);
            this.searchToolStripButton.Text = "&Search";
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(531, 9);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(41, 13);
            this.lblSearch.TabIndex = 33;
            this.lblSearch.Text = "Search";
            this.lblSearch.Visible = false;
            // 
            // StaffsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 391);
            this.Controls.Add(this.ListView1);
            this.Controls.Add(this.ToolStrip1);
            this.Controls.Add(this.lblSearch);
            this.Name = "StaffsForm";
            this.Text = "Inventory Management System With POS";
            this.ToolStrip1.ResumeLayout(false);
            this.ToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.ListView ListView1;
        internal System.Windows.Forms.ColumnHeader staffIdColumn;
        internal System.Windows.Forms.ColumnHeader nameColumn;
        internal System.Windows.Forms.ColumnHeader contactNoColumn;
        internal System.Windows.Forms.ColumnHeader addressColumn;
        internal System.Windows.Forms.ColumnHeader userNameColumn;
        internal System.Windows.Forms.ColumnHeader roleColumn;
        internal System.Windows.Forms.ToolStripButton closeToolStripButton;
        internal System.Windows.Forms.ToolStrip ToolStrip1;
        internal System.Windows.Forms.ToolStripLabel ToolStripLabel1;
        internal System.Windows.Forms.ToolStripButton newToolStripButton;
        internal System.Windows.Forms.ToolStripButton updateToolStripButton;
        internal System.Windows.Forms.ToolStripButton searchToolStripButton;
        internal System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.ColumnHeader dobColumn;
        private System.Windows.Forms.ColumnHeader genderColumn;
        private System.Windows.Forms.ColumnHeader emailColumn;
        private System.Windows.Forms.ColumnHeader nidColumn;
    }
}